import json
import time
import threading
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta
from src.models.user import db, Token, Transaction, Wallet
from src.services.blockchain_service import BlockchainService
from src.services.ai_service import AIService
from src.utils.logger import logger
from src.utils.solana_client import SolanaClient
import uuid

@dataclass
class StopLossConfig:
    """止损配置"""
    enabled: bool = True
    percentage: float = 0.2  # 20%止损
    trailing: bool = False  # 移动止损
    trailing_distance: float = 0.1  # 移动止损距离
    time_based: bool = False  # 时间止损
    max_hold_time: int = 3600  # 最大持有时间（秒）

@dataclass
class TakeProfitConfig:
    """止盈配置"""
    enabled: bool = True
    percentage: float = 0.5  # 50%止盈
    partial: bool = True  # 分批止盈
    levels: List[Dict] = None  # 多级止盈 [{"percentage": 0.3, "sell_ratio": 0.3}]
    auto_adjust: bool = True  # 自动调整止盈点

@dataclass
class Position:
    """持仓信息"""
    id: str
    mint_address: str
    symbol: str
    name: str
    wallet_address: str
    
    # 买入信息
    buy_price: float
    buy_amount_sol: float
    token_amount: float
    buy_time: int
    buy_signature: str
    
    # 当前状态
    current_price: float = 0.0
    unrealized_pnl: float = 0.0
    unrealized_pnl_percentage: float = 0.0
    
    # 止盈止损配置
    stop_loss_config: StopLossConfig = None
    take_profit_config: TakeProfitConfig = None
    
    # 状态
    status: str = "holding"  # holding, partial_sold, sold, stop_loss, take_profit
    
    # 卖出信息
    sell_transactions: List[Dict] = None
    total_sold_amount: float = 0.0
    total_received_sol: float = 0.0
    realized_pnl: float = 0.0
    
    # 其他
    notes: str = ""
    created_at: int = 0
    updated_at: int = 0

class PositionManagerService:
    """持仓管理服务"""
    
    def __init__(self):
        self.blockchain_service = BlockchainService()
        self.ai_service = AIService()
        self.solana_client = SolanaClient()
        
        self.positions = {}  # position_id -> Position
        self.is_running = False
        self.monitor_thread = None
        
        # 配置
        self.config = {
            'monitor_interval': 10,  # 监控间隔（秒）
            'price_update_interval': 5,  # 价格更新间隔（秒）
            'auto_execute': True,  # 自动执行止盈止损
            'slippage_tolerance': 0.1,  # 滑点容忍度
            'max_retries': 3,  # 最大重试次数
        }
        
        # 统计数据
        self.stats = {
            'total_positions': 0,
            'active_positions': 0,
            'total_realized_pnl': 0.0,
            'total_unrealized_pnl': 0.0,
            'win_rate': 0.0,
            'avg_hold_time': 0.0,
            'stop_loss_triggered': 0,
            'take_profit_triggered': 0
        }
    
    def start_monitoring(self):
        """启动持仓监控"""
        if self.is_running:
            logger.warning("持仓监控已在运行", "PositionManager")
            return False
        
        self.is_running = True
        self.monitor_thread = threading.Thread(target=self._monitoring_loop, daemon=True)
        self.monitor_thread.start()
        
        logger.info("持仓监控已启动", "PositionManager")
        return True
    
    def stop_monitoring(self):
        """停止持仓监控"""
        self.is_running = False
        if self.monitor_thread:
            self.monitor_thread.join(timeout=5)
        
        logger.info("持仓监控已停止", "PositionManager")
    
    def add_position(self, position_data: Dict, 
                    stop_loss_config: Optional[StopLossConfig] = None,
                    take_profit_config: Optional[TakeProfitConfig] = None) -> str:
        """添加持仓"""
        try:
            position_id = str(uuid.uuid4())
            current_time = int(time.time())
            
            # 创建默认配置
            if stop_loss_config is None:
                stop_loss_config = StopLossConfig()
            if take_profit_config is None:
                take_profit_config = TakeProfitConfig(
                    levels=[
                        {"percentage": 0.3, "sell_ratio": 0.3},
                        {"percentage": 0.5, "sell_ratio": 0.5},
                        {"percentage": 1.0, "sell_ratio": 1.0}
                    ]
                )
            
            position = Position(
                id=position_id,
                mint_address=position_data['mint_address'],
                symbol=position_data.get('symbol', 'UNKNOWN'),
                name=position_data.get('name', 'Unknown Token'),
                wallet_address=position_data['wallet_address'],
                buy_price=position_data['buy_price'],
                buy_amount_sol=position_data['buy_amount_sol'],
                token_amount=position_data['token_amount'],
                buy_time=position_data.get('buy_time', current_time),
                buy_signature=position_data.get('buy_signature', ''),
                stop_loss_config=stop_loss_config,
                take_profit_config=take_profit_config,
                sell_transactions=[],
                created_at=current_time,
                updated_at=current_time
            )
            
            self.positions[position_id] = position
            self.stats['total_positions'] += 1
            self.stats['active_positions'] += 1
            
            logger.info(f"添加持仓: {position.symbol} - {position_id}", "PositionManager")
            return position_id
            
        except Exception as e:
            logger.error(f"添加持仓失败: {str(e)}", "PositionManager", exc_info=True)
            return ""
    
    def update_position_config(self, position_id: str, 
                             stop_loss_config: Optional[StopLossConfig] = None,
                             take_profit_config: Optional[TakeProfitConfig] = None) -> bool:
        """更新持仓配置"""
        try:
            if position_id not in self.positions:
                logger.error(f"持仓不存在: {position_id}", "PositionManager")
                return False
            
            position = self.positions[position_id]
            
            if stop_loss_config:
                position.stop_loss_config = stop_loss_config
                logger.info(f"更新止损配置: {position.symbol}", "PositionManager")
            
            if take_profit_config:
                position.take_profit_config = take_profit_config
                logger.info(f"更新止盈配置: {position.symbol}", "PositionManager")
            
            position.updated_at = int(time.time())
            return True
            
        except Exception as e:
            logger.error(f"更新持仓配置失败: {str(e)}", "PositionManager")
            return False
    
    def manual_sell(self, position_id: str, sell_ratio: float = 1.0, 
                   reason: str = "manual") -> Dict:
        """手动卖出"""
        try:
            if position_id not in self.positions:
                return {'success': False, 'error': '持仓不存在'}
            
            position = self.positions[position_id]
            if position.status not in ['holding', 'partial_sold']:
                return {'success': False, 'error': '持仓状态不允许卖出'}
            
            # 计算卖出数量
            remaining_amount = position.token_amount - position.total_sold_amount
            sell_amount = remaining_amount * sell_ratio
            
            if sell_amount <= 0:
                return {'success': False, 'error': '卖出数量无效'}
            
            # 执行卖出
            result = self._execute_sell(position, sell_amount, reason)
            
            if result['success']:
                logger.info(f"手动卖出成功: {position.symbol} - {sell_ratio*100}%", "PositionManager")
            
            return result
            
        except Exception as e:
            logger.error(f"手动卖出失败: {str(e)}", "PositionManager", exc_info=True)
            return {'success': False, 'error': str(e)}
    
    def close_position(self, position_id: str, reason: str = "manual_close") -> Dict:
        """关闭持仓"""
        return self.manual_sell(position_id, 1.0, reason)
    
    def get_position(self, position_id: str) -> Optional[Dict]:
        """获取持仓信息"""
        if position_id in self.positions:
            position = self.positions[position_id]
            self._update_position_metrics(position)
            return asdict(position)
        return None
    
    def get_all_positions(self, status_filter: Optional[str] = None) -> List[Dict]:
        """获取所有持仓"""
        positions = []
        for position in self.positions.values():
            if status_filter is None or position.status == status_filter:
                self._update_position_metrics(position)
                positions.append(asdict(position))
        
        # 按创建时间倒序排列
        positions.sort(key=lambda x: x['created_at'], reverse=True)
        return positions
    
    def get_active_positions(self) -> List[Dict]:
        """获取活跃持仓"""
        return self.get_all_positions('holding') + self.get_all_positions('partial_sold')
    
    def get_position_stats(self) -> Dict:
        """获取持仓统计"""
        try:
            # 更新统计数据
            self._update_stats()
            
            # 计算额外指标
            active_positions = self.get_active_positions()
            total_unrealized = sum(pos['unrealized_pnl'] for pos in active_positions)
            
            return {
                **self.stats,
                'current_unrealized_pnl': total_unrealized,
                'positions_by_status': self._get_positions_by_status(),
                'top_performers': self._get_top_performers(),
                'worst_performers': self._get_worst_performers(),
                'avg_unrealized_pnl': total_unrealized / len(active_positions) if active_positions else 0
            }
            
        except Exception as e:
            logger.error(f"获取持仓统计失败: {str(e)}", "PositionManager")
            return {}
    
    def get_pnl_report(self, days: int = 7) -> Dict:
        """获取盈亏报告"""
        try:
            cutoff_time = int(time.time()) - (days * 24 * 3600)
            
            # 筛选时间范围内的持仓
            recent_positions = [
                pos for pos in self.positions.values()
                if pos.created_at >= cutoff_time
            ]
            
            if not recent_positions:
                return {'message': f'过去{days}天没有持仓数据'}
            
            # 计算各种指标
            total_invested = sum(pos.buy_amount_sol for pos in recent_positions)
            total_realized = sum(pos.realized_pnl for pos in recent_positions if pos.realized_pnl)
            total_unrealized = sum(self._calculate_unrealized_pnl(pos) for pos in recent_positions if pos.status in ['holding', 'partial_sold'])
            
            winning_positions = [pos for pos in recent_positions if (pos.realized_pnl or 0) > 0 or self._calculate_unrealized_pnl(pos) > 0]
            losing_positions = [pos for pos in recent_positions if (pos.realized_pnl or 0) < 0 or self._calculate_unrealized_pnl(pos) < 0]
            
            return {
                'period_days': days,
                'total_positions': len(recent_positions),
                'total_invested': total_invested,
                'total_realized_pnl': total_realized,
                'total_unrealized_pnl': total_unrealized,
                'total_pnl': total_realized + total_unrealized,
                'roi_percentage': ((total_realized + total_unrealized) / total_invested * 100) if total_invested > 0 else 0,
                'win_rate': len(winning_positions) / len(recent_positions) * 100 if recent_positions else 0,
                'winning_positions': len(winning_positions),
                'losing_positions': len(losing_positions),
                'avg_win': sum((pos.realized_pnl or 0) + self._calculate_unrealized_pnl(pos) for pos in winning_positions) / len(winning_positions) if winning_positions else 0,
                'avg_loss': sum((pos.realized_pnl or 0) + self._calculate_unrealized_pnl(pos) for pos in losing_positions) / len(losing_positions) if losing_positions else 0,
                'best_position': self._get_best_position(recent_positions),
                'worst_position': self._get_worst_position(recent_positions)
            }
            
        except Exception as e:
            logger.error(f"获取盈亏报告失败: {str(e)}", "PositionManager")
            return {'error': str(e)}
    
    def _monitoring_loop(self):
        """监控主循环"""
        logger.info("启动持仓监控循环", "PositionManager")
        
        while self.is_running:
            try:
                # 更新所有活跃持仓的价格
                self._update_all_prices()
                
                # 检查止盈止损条件
                if self.config['auto_execute']:
                    self._check_stop_loss_take_profit()
                
                # 更新统计数据
                self._update_stats()
                
                time.sleep(self.config['monitor_interval'])
                
            except Exception as e:
                logger.error(f"持仓监控循环异常: {str(e)}", "PositionManager", exc_info=True)
                time.sleep(30)
    
    def _update_all_prices(self):
        """更新所有持仓价格"""
        active_positions = [pos for pos in self.positions.values() if pos.status in ['holding', 'partial_sold']]
        
        for position in active_positions:
            try:
                # 获取当前价格
                current_price = self._get_current_price(position.mint_address)
                if current_price > 0:
                    position.current_price = current_price
                    position.updated_at = int(time.time())
                    
                    # 更新盈亏指标
                    self._update_position_metrics(position)
                    
            except Exception as e:
                logger.error(f"更新价格失败 {position.symbol}: {str(e)}", "PositionManager")
    
    def _check_stop_loss_take_profit(self):
        """检查止盈止损条件"""
        active_positions = [pos for pos in self.positions.values() if pos.status in ['holding', 'partial_sold']]
        
        for position in active_positions:
            try:
                # 检查止损
                if self._should_stop_loss(position):
                    self._execute_stop_loss(position)
                
                # 检查止盈
                elif self._should_take_profit(position):
                    self._execute_take_profit(position)
                
                # 检查移动止损
                elif position.stop_loss_config.trailing:
                    self._update_trailing_stop(position)
                
            except Exception as e:
                logger.error(f"检查止盈止损失败 {position.symbol}: {str(e)}", "PositionManager")
    
    def _should_stop_loss(self, position: Position) -> bool:
        """判断是否应该止损"""
        if not position.stop_loss_config.enabled:
            return False
        
        # 价格止损
        if position.current_price > 0:
            price_change = (position.current_price - position.buy_price) / position.buy_price
            if price_change <= -position.stop_loss_config.percentage:
                logger.info(f"触发价格止损: {position.symbol} 跌幅 {price_change:.2%}", "PositionManager")
                return True
        
        # 时间止损
        if position.stop_loss_config.time_based:
            hold_time = int(time.time()) - position.buy_time
            if hold_time >= position.stop_loss_config.max_hold_time:
                logger.info(f"触发时间止损: {position.symbol} 持有 {hold_time}秒", "PositionManager")
                return True
        
        return False
    
    def _should_take_profit(self, position: Position) -> bool:
        """判断是否应该止盈"""
        if not position.take_profit_config.enabled or position.current_price <= 0:
            return False
        
        price_change = (position.current_price - position.buy_price) / position.buy_price
        
        if position.take_profit_config.partial and position.take_profit_config.levels:
            # 检查分级止盈
            for level in position.take_profit_config.levels:
                if price_change >= level['percentage'] and not self._level_already_executed(position, level):
                    logger.info(f"触发分级止盈: {position.symbol} 涨幅 {price_change:.2%} 级别 {level['percentage']:.2%}", "PositionManager")
                    return True
        else:
            # 简单止盈
            if price_change >= position.take_profit_config.percentage:
                logger.info(f"触发止盈: {position.symbol} 涨幅 {price_change:.2%}", "PositionManager")
                return True
        
        return False
    
    def _execute_stop_loss(self, position: Position):
        """执行止损"""
        try:
            remaining_amount = position.token_amount - position.total_sold_amount
            result = self._execute_sell(position, remaining_amount, "stop_loss")
            
            if result['success']:
                position.status = "stop_loss"
                self.stats['stop_loss_triggered'] += 1
                logger.info(f"止损执行成功: {position.symbol}", "PositionManager")
            else:
                logger.error(f"止损执行失败: {position.symbol} - {result.get('error')}", "PositionManager")
                
        except Exception as e:
            logger.error(f"执行止损异常: {str(e)}", "PositionManager", exc_info=True)
    
    def _execute_take_profit(self, position: Position):
        """执行止盈"""
        try:
            if position.take_profit_config.partial and position.take_profit_config.levels:
                # 分级止盈
                price_change = (position.current_price - position.buy_price) / position.buy_price
                
                for level in position.take_profit_config.levels:
                    if price_change >= level['percentage'] and not self._level_already_executed(position, level):
                        remaining_amount = position.token_amount - position.total_sold_amount
                        sell_amount = remaining_amount * level['sell_ratio']
                        
                        result = self._execute_sell(position, sell_amount, f"take_profit_level_{level['percentage']}")
                        
                        if result['success']:
                            # 标记该级别已执行
                            level['executed'] = True
                            
                            # 检查是否完全卖出
                            if position.total_sold_amount >= position.token_amount * 0.99:  # 99%以上认为完全卖出
                                position.status = "take_profit"
                            else:
                                position.status = "partial_sold"
                            
                            self.stats['take_profit_triggered'] += 1
                            logger.info(f"分级止盈执行成功: {position.symbol} 级别 {level['percentage']:.2%}", "PositionManager")
                        break
            else:
                # 简单止盈
                remaining_amount = position.token_amount - position.total_sold_amount
                result = self._execute_sell(position, remaining_amount, "take_profit")
                
                if result['success']:
                    position.status = "take_profit"
                    self.stats['take_profit_triggered'] += 1
                    logger.info(f"止盈执行成功: {position.symbol}", "PositionManager")
                    
        except Exception as e:
            logger.error(f"执行止盈异常: {str(e)}", "PositionManager", exc_info=True)
    
    def _execute_sell(self, position: Position, sell_amount: float, reason: str) -> Dict:
        """执行卖出"""
        try:
            logger.info(f"执行卖出: {position.symbol} 数量 {sell_amount} 原因 {reason}", "PositionManager")
            
            # 调用区块链服务执行卖出
            result = self.blockchain_service.sell_token(
                mint_address=position.mint_address,
                seller_wallet={'public_key': position.wallet_address},
                token_amount=sell_amount,
                max_slippage=self.config['slippage_tolerance']
            )
            
            if result['success']:
                # 记录卖出交易
                sell_transaction = {
                    'timestamp': int(time.time()),
                    'amount': sell_amount,
                    'price': result.get('price', position.current_price),
                    'sol_received': result.get('sol_received', 0),
                    'signature': result.get('transaction_signature', ''),
                    'reason': reason
                }
                
                position.sell_transactions.append(sell_transaction)
                position.total_sold_amount += sell_amount
                position.total_received_sol += sell_transaction['sol_received']
                
                # 计算已实现盈亏
                cost_basis = (sell_amount / position.token_amount) * position.buy_amount_sol
                position.realized_pnl += sell_transaction['sol_received'] - cost_basis
                
                # 更新状态
                if position.total_sold_amount >= position.token_amount * 0.99:
                    if position.status not in ['stop_loss', 'take_profit']:
                        position.status = 'sold'
                    self.stats['active_positions'] -= 1
                
                position.updated_at = int(time.time())
                
                # 记录到数据库
                self._record_sell_transaction(position, sell_transaction)
                
                logger.info(f"卖出成功: {position.symbol} 获得 {sell_transaction['sol_received']:.4f} SOL", "PositionManager")
                
            return result
            
        except Exception as e:
            logger.error(f"执行卖出失败: {str(e)}", "PositionManager", exc_info=True)
            return {'success': False, 'error': str(e)}
    
    def _update_trailing_stop(self, position: Position):
        """更新移动止损"""
        try:
            if position.current_price <= 0:
                return
            
            price_change = (position.current_price - position.buy_price) / position.buy_price
            
            # 只有在盈利时才启用移动止损
            if price_change > 0:
                # 计算新的止损点
                new_stop_loss = position.current_price * (1 - position.stop_loss_config.trailing_distance)
                current_stop_loss = position.buy_price * (1 - position.stop_loss_config.percentage)
                
                # 如果新止损点更高，则更新
                if new_stop_loss > current_stop_loss:
                    # 更新止损百分比
                    new_percentage = 1 - (new_stop_loss / position.buy_price)
                    position.stop_loss_config.percentage = new_percentage
                    
                    logger.debug(f"更新移动止损: {position.symbol} 新止损点 {new_percentage:.2%}", "PositionManager")
                    
        except Exception as e:
            logger.error(f"更新移动止损失败: {str(e)}", "PositionManager")
    
    def _update_position_metrics(self, position: Position):
        """更新持仓指标"""
        try:
            if position.current_price > 0:
                # 计算未实现盈亏
                remaining_amount = position.token_amount - position.total_sold_amount
                current_value = remaining_amount * position.current_price
                remaining_cost = (remaining_amount / position.token_amount) * position.buy_amount_sol
                
                position.unrealized_pnl = current_value - remaining_cost
                position.unrealized_pnl_percentage = (position.current_price - position.buy_price) / position.buy_price
                
        except Exception as e:
            logger.error(f"更新持仓指标失败: {str(e)}", "PositionManager")
    
    def _calculate_unrealized_pnl(self, position: Position) -> float:
        """计算未实现盈亏"""
        if position.current_price <= 0:
            return 0.0
        
        remaining_amount = position.token_amount - position.total_sold_amount
        current_value = remaining_amount * position.current_price
        remaining_cost = (remaining_amount / position.token_amount) * position.buy_amount_sol
        
        return current_value - remaining_cost
    
    def _get_current_price(self, mint_address: str) -> float:
        """获取当前价格"""
        try:
            # 这里应该调用实际的价格API
            # 现在返回模拟价格
            import random
            return random.uniform(0.0001, 0.01)
        except Exception as e:
            logger.error(f"获取价格失败: {str(e)}", "PositionManager")
            return 0.0
    
    def _level_already_executed(self, position: Position, level: Dict) -> bool:
        """检查止盈级别是否已执行"""
        return level.get('executed', False)
    
    def _record_sell_transaction(self, position: Position, sell_transaction: Dict):
        """记录卖出交易到数据库"""
        try:
            transaction = Transaction(
                signature=sell_transaction['signature'],
                transaction_type='sell',
                wallet_address=position.wallet_address,
                token_mint=position.mint_address,
                amount=sell_transaction['amount'],
                sol_amount=sell_transaction['sol_received'],
                status='confirmed',
                notes=sell_transaction['reason']
            )
            
            db.session.add(transaction)
            db.session.commit()
            
        except Exception as e:
            logger.error(f"记录卖出交易失败: {str(e)}", "PositionManager")
    
    def _update_stats(self):
        """更新统计数据"""
        try:
            active_count = len([pos for pos in self.positions.values() if pos.status in ['holding', 'partial_sold']])
            self.stats['active_positions'] = active_count
            
            # 计算总已实现盈亏
            total_realized = sum(pos.realized_pnl for pos in self.positions.values() if pos.realized_pnl)
            self.stats['total_realized_pnl'] = total_realized
            
            # 计算总未实现盈亏
            total_unrealized = sum(self._calculate_unrealized_pnl(pos) for pos in self.positions.values() if pos.status in ['holding', 'partial_sold'])
            self.stats['total_unrealized_pnl'] = total_unrealized
            
            # 计算胜率
            closed_positions = [pos for pos in self.positions.values() if pos.status in ['sold', 'stop_loss', 'take_profit']]
            if closed_positions:
                winning_positions = [pos for pos in closed_positions if pos.realized_pnl > 0]
                self.stats['win_rate'] = len(winning_positions) / len(closed_positions)
            
            # 计算平均持有时间
            if closed_positions:
                total_hold_time = sum(pos.updated_at - pos.buy_time for pos in closed_positions)
                self.stats['avg_hold_time'] = total_hold_time / len(closed_positions)
            
        except Exception as e:
            logger.error(f"更新统计数据失败: {str(e)}", "PositionManager")
    
    def _get_positions_by_status(self) -> Dict:
        """按状态分组持仓"""
        status_count = {}
        for position in self.positions.values():
            status = position.status
            status_count[status] = status_count.get(status, 0) + 1
        return status_count
    
    def _get_top_performers(self, limit: int = 5) -> List[Dict]:
        """获取表现最佳的持仓"""
        positions = []
        for pos in self.positions.values():
            total_pnl = (pos.realized_pnl or 0) + self._calculate_unrealized_pnl(pos)
            positions.append({
                'symbol': pos.symbol,
                'pnl': total_pnl,
                'pnl_percentage': total_pnl / pos.buy_amount_sol if pos.buy_amount_sol > 0 else 0,
                'status': pos.status
            })
        
        positions.sort(key=lambda x: x['pnl'], reverse=True)
        return positions[:limit]
    
    def _get_worst_performers(self, limit: int = 5) -> List[Dict]:
        """获取表现最差的持仓"""
        positions = []
        for pos in self.positions.values():
            total_pnl = (pos.realized_pnl or 0) + self._calculate_unrealized_pnl(pos)
            positions.append({
                'symbol': pos.symbol,
                'pnl': total_pnl,
                'pnl_percentage': total_pnl / pos.buy_amount_sol if pos.buy_amount_sol > 0 else 0,
                'status': pos.status
            })
        
        positions.sort(key=lambda x: x['pnl'])
        return positions[:limit]
    
    def _get_best_position(self, positions: List[Position]) -> Optional[Dict]:
        """获取最佳持仓"""
        if not positions:
            return None
        
        best_pos = max(positions, key=lambda pos: (pos.realized_pnl or 0) + self._calculate_unrealized_pnl(pos))
        total_pnl = (best_pos.realized_pnl or 0) + self._calculate_unrealized_pnl(best_pos)
        
        return {
            'symbol': best_pos.symbol,
            'pnl': total_pnl,
            'pnl_percentage': total_pnl / best_pos.buy_amount_sol if best_pos.buy_amount_sol > 0 else 0
        }
    
    def _get_worst_position(self, positions: List[Position]) -> Optional[Dict]:
        """获取最差持仓"""
        if not positions:
            return None
        
        worst_pos = min(positions, key=lambda pos: (pos.realized_pnl or 0) + self._calculate_unrealized_pnl(pos))
        total_pnl = (worst_pos.realized_pnl or 0) + self._calculate_unrealized_pnl(worst_pos)
        
        return {
            'symbol': worst_pos.symbol,
            'pnl': total_pnl,
            'pnl_percentage': total_pnl / worst_pos.buy_amount_sol if worst_pos.buy_amount_sol > 0 else 0
        }

