import json
import time
import asyncio
from typing import List, Dict, Optional, Any
from src.models.user import db, Token, Transaction, Wallet
from src.services.ai_service import AIService
from src.services.blockchain_service import BlockchainService
from src.services.metadata_service import MetadataService
from src.utils.logger import logger
from src.utils.solana_client import SolanaClient

class TokenService:
    """代币管理服务"""
    
    def __init__(self):
        self.ai_service = AIService()
        self.blockchain_service = BlockchainService()
        self.metadata_service = MetadataService()
        self.solana_client = SolanaClient()
        
    def create_token(self, name: str, symbol: str, description: str = "", 
                    image_uri: str = "", buy_amount: float = 0.01) -> Dict:
        """创建单个代币"""
        try:
            logger.info(f"开始创建代币: {name} ({symbol})", "TokenService")
            
            # 获取主钱包
            main_wallet = self._get_main_wallet()
            if not main_wallet:
                raise Exception("未找到主钱包")
            
            # 生成元数据URI
            if not image_uri:
                # 使用AI生成图片
                image_uri = self.ai_service.generate_token_image(name, description)
            
            metadata_uri = self.metadata_service.create_metadata(
                name=name,
                symbol=symbol,
                description=description,
                image_uri=image_uri
            )
            
            # 调用区块链服务创建代币
            result = self.blockchain_service.create_token(
                name=name,
                symbol=symbol,
                uri=metadata_uri,
                creator_wallet=main_wallet,
                buy_amount=buy_amount
            )
            
            if result['success']:
                # 保存到数据库
                token = Token(
                    mint_address=result['mint_address'],
                    name=name,
                    symbol=symbol,
                    description=description,
                    image_uri=image_uri,
                    metadata_uri=metadata_uri,
                    creator_wallet=main_wallet['public_key'],
                    initial_buy_amount=buy_amount
                )
                
                db.session.add(token)
                
                # 记录交易
                if result.get('transaction_signature'):
                    transaction = Transaction(
                        signature=result['transaction_signature'],
                        transaction_type='create',
                        wallet_address=main_wallet['public_key'],
                        token_mint=result['mint_address'],
                        sol_amount=buy_amount,
                        status='confirmed'
                    )
                    db.session.add(transaction)
                
                db.session.commit()
                
                logger.info(f"代币创建成功: {result['mint_address']}", "TokenService")
                
                return {
                    'success': True,
                    'mint_address': result['mint_address'],
                    'name': name,
                    'symbol': symbol,
                    'metadata_uri': metadata_uri,
                    'image_uri': image_uri,
                    'transaction_signature': result.get('transaction_signature'),
                    'buy_amount': buy_amount
                }
            else:
                raise Exception(result.get('error', '代币创建失败'))
                
        except Exception as e:
            logger.error(f"创建代币失败: {str(e)}", "TokenService", exc_info=True)
            return {
                'success': False,
                'error': str(e)
            }
    
    def create_and_buy_token(self, name: str = None, symbol: str = None, 
                           description: str = None, use_ai: bool = False,
                           buy_amount: float = 0.01, theme: str = "") -> Dict:
        """一键发币并购买"""
        try:
            logger.info("开始一键发币并购买", "TokenService")
            
            # 如果启用AI，生成代币信息
            if use_ai:
                ai_metadata = self.ai_service.generate_token_metadata(theme)
                name = name or ai_metadata['name']
                symbol = symbol or ai_metadata['symbol']
                description = description or ai_metadata['description']
                image_uri = ai_metadata.get('image_uri', '')
            else:
                # 使用随机生成
                if not name or not symbol:
                    random_metadata = self._generate_random_metadata()
                    name = name or random_metadata['name']
                    symbol = symbol or random_metadata['symbol']
                    description = description or random_metadata['description']
                image_uri = ''
            
            # 创建代币
            result = self.create_token(
                name=name,
                symbol=symbol,
                description=description,
                image_uri=image_uri,
                buy_amount=buy_amount
            )
            
            if result['success']:
                logger.info(f"一键发币成功: {result['mint_address']}", "TokenService")
            
            return result
            
        except Exception as e:
            logger.error(f"一键发币失败: {str(e)}", "TokenService", exc_info=True)
            return {
                'success': False,
                'error': str(e)
            }
    
    def batch_create_tokens(self, count: int, use_ai: bool = False, 
                          buy_amount: float = 0.01, theme: str = "",
                          delay_ms: int = 2000) -> Dict:
        """批量创建代币"""
        try:
            logger.info(f"开始批量创建 {count} 个代币", "TokenService")
            
            results = []
            success_count = 0
            failed_count = 0
            
            for i in range(count):
                try:
                    logger.info(f"创建代币 {i+1}/{count}", "TokenService")
                    
                    # 创建代币
                    result = self.create_and_buy_token(
                        use_ai=use_ai,
                        buy_amount=buy_amount,
                        theme=theme
                    )
                    
                    results.append(result)
                    
                    if result['success']:
                        success_count += 1
                        logger.info(f"代币 {i+1} 创建成功: {result['mint_address']}", "TokenService")
                    else:
                        failed_count += 1
                        logger.error(f"代币 {i+1} 创建失败: {result.get('error')}", "TokenService")
                    
                    # 延迟避免过于频繁的请求
                    if i < count - 1:
                        time.sleep(delay_ms / 1000)
                        
                except Exception as e:
                    failed_count += 1
                    error_result = {'success': False, 'error': str(e)}
                    results.append(error_result)
                    logger.error(f"代币 {i+1} 创建异常: {str(e)}", "TokenService")
            
            summary = {
                'success': True,
                'total_count': count,
                'success_count': success_count,
                'failed_count': failed_count,
                'results': results,
                'summary': f"批量创建完成: {success_count} 成功, {failed_count} 失败"
            }
            
            logger.info(f"批量创建完成: {success_count}/{count} 成功", "TokenService")
            return summary
            
        except Exception as e:
            logger.error(f"批量创建代币失败: {str(e)}", "TokenService", exc_info=True)
            return {
                'success': False,
                'error': str(e)
            }
    
    def buy_token(self, token_mint: str, amount: float) -> Dict:
        """购买代币"""
        try:
            logger.info(f"开始购买代币: {token_mint}, 金额: {amount} SOL", "TokenService")
            
            # 获取主钱包
            main_wallet = self._get_main_wallet()
            if not main_wallet:
                raise Exception("未找到主钱包")
            
            # 调用区块链服务购买代币
            result = self.blockchain_service.buy_token(
                mint_address=token_mint,
                buyer_wallet=main_wallet,
                sol_amount=amount
            )
            
            if result['success']:
                # 记录交易
                transaction = Transaction(
                    signature=result['transaction_signature'],
                    transaction_type='buy',
                    wallet_address=main_wallet['public_key'],
                    token_mint=token_mint,
                    sol_amount=amount,
                    amount=result.get('token_amount', 0),
                    status='confirmed'
                )
                
                db.session.add(transaction)
                db.session.commit()
                
                logger.info(f"代币购买成功: {result['transaction_signature']}", "TokenService")
            
            return result
            
        except Exception as e:
            logger.error(f"购买代币失败: {str(e)}", "TokenService", exc_info=True)
            return {
                'success': False,
                'error': str(e)
            }
    
    def sell_token(self, token_mint: str, percentage: float = 100) -> Dict:
        """出售代币"""
        try:
            logger.info(f"开始出售代币: {token_mint}, 比例: {percentage}%", "TokenService")
            
            # 获取主钱包
            main_wallet = self._get_main_wallet()
            if not main_wallet:
                raise Exception("未找到主钱包")
            
            # 获取代币余额
            token_balance = self.solana_client.get_token_balance(
                main_wallet['public_key'], 
                token_mint
            )
            
            if token_balance <= 0:
                raise Exception("代币余额不足")
            
            # 计算出售数量
            sell_amount = token_balance * (percentage / 100)
            
            # 调用区块链服务出售代币
            result = self.blockchain_service.sell_token(
                mint_address=token_mint,
                seller_wallet=main_wallet,
                token_amount=sell_amount
            )
            
            if result['success']:
                # 记录交易
                transaction = Transaction(
                    signature=result['transaction_signature'],
                    transaction_type='sell',
                    wallet_address=main_wallet['public_key'],
                    token_mint=token_mint,
                    amount=sell_amount,
                    sol_amount=result.get('sol_received', 0),
                    status='confirmed'
                )
                
                db.session.add(transaction)
                db.session.commit()
                
                logger.info(f"代币出售成功: {result['transaction_signature']}", "TokenService")
            
            return result
            
        except Exception as e:
            logger.error(f"出售代币失败: {str(e)}", "TokenService", exc_info=True)
            return {
                'success': False,
                'error': str(e)
            }
    
    def get_all_tokens(self) -> List[Dict]:
        """获取所有代币"""
        try:
            tokens = Token.query.order_by(Token.created_at.desc()).all()
            result = []
            
            for token in tokens:
                # 获取当前价格和市值（如果可能）
                current_price = self._get_token_price(token.mint_address)
                market_cap = self._get_token_market_cap(token.mint_address)
                
                result.append({
                    'id': token.id,
                    'mint_address': token.mint_address,
                    'name': token.name,
                    'symbol': token.symbol,
                    'description': token.description,
                    'image_uri': token.image_uri,
                    'metadata_uri': token.metadata_uri,
                    'creator_wallet': token.creator_wallet,
                    'initial_buy_amount': token.initial_buy_amount,
                    'current_price': current_price,
                    'market_cap': market_cap,
                    'is_graduated': token.is_graduated,
                    'created_at': token.created_at.isoformat(),
                    'updated_at': token.updated_at.isoformat()
                })
            
            return result
            
        except Exception as e:
            logger.error(f"获取代币列表失败: {str(e)}", "TokenService")
            return []
    
    def get_token_by_mint(self, mint_address: str) -> Optional[Dict]:
        """根据mint地址获取代币"""
        try:
            token = Token.query.filter_by(mint_address=mint_address).first()
            if not token:
                return None
            
            current_price = self._get_token_price(token.mint_address)
            market_cap = self._get_token_market_cap(token.mint_address)
            
            return {
                'id': token.id,
                'mint_address': token.mint_address,
                'name': token.name,
                'symbol': token.symbol,
                'description': token.description,
                'image_uri': token.image_uri,
                'metadata_uri': token.metadata_uri,
                'creator_wallet': token.creator_wallet,
                'initial_buy_amount': token.initial_buy_amount,
                'current_price': current_price,
                'market_cap': market_cap,
                'is_graduated': token.is_graduated,
                'created_at': token.created_at.isoformat(),
                'updated_at': token.updated_at.isoformat()
            }
            
        except Exception as e:
            logger.error(f"获取代币信息失败: {str(e)}", "TokenService")
            return None
    
    def generate_ai_metadata(self, theme: str = "") -> Dict:
        """AI生成代币元数据"""
        try:
            return self.ai_service.generate_token_metadata(theme)
        except Exception as e:
            logger.error(f"AI生成元数据失败: {str(e)}", "TokenService")
            return self._generate_random_metadata()
    
    def _get_main_wallet(self) -> Optional[Dict]:
        """获取主钱包"""
        from src.services.wallet_service import WalletService
        wallet_service = WalletService()
        return wallet_service.get_main_wallet_info()
    
    def _generate_random_metadata(self) -> Dict:
        """生成随机代币元数据"""
        import random
        
        adjectives = ["Super", "Mega", "Ultra", "Hyper", "Cosmic", "Quantum", "Cyber", "Digital"]
        nouns = ["Cat", "Dog", "Moon", "Sun", "Star", "Coin", "Token", "Gem", "Diamond", "Gold"]
        suffixes = ["Coin", "Token", "Inu", "Shiba", "Pepe", "Doge", "Meme", "Fun"]
        
        adj = random.choice(adjectives)
        noun = random.choice(nouns)
        suffix = random.choice(suffixes)
        
        name = f"{adj} {noun} {suffix}"
        symbol = f"{adj[:2]}{noun[:2]}{suffix[:2]}".upper()
        
        descriptions = [
            f"The ultimate {noun.lower()} token for the future!",
            f"Join the {adj.lower()} {noun.lower()} revolution!",
            f"The most {adj.lower()} {noun.lower()} in the crypto space!",
            f"Experience the power of {adj.lower()} {noun.lower()} technology!"
        ]
        
        description = random.choice(descriptions)
        
        return {
            'name': name,
            'symbol': symbol,
            'description': description
        }
    
    def _get_token_price(self, mint_address: str) -> float:
        """获取代币价格（模拟实现）"""
        # 这里应该调用实际的价格API
        # 现在返回模拟价格
        import random
        return round(random.uniform(0.0001, 0.01), 6)
    
    def _get_token_market_cap(self, mint_address: str) -> float:
        """获取代币市值（模拟实现）"""
        # 这里应该调用实际的市值API
        # 现在返回模拟市值
        import random
        return round(random.uniform(1000, 100000), 2)
    
    def update_token_prices(self) -> Dict:
        """更新所有代币价格"""
        try:
            tokens = Token.query.all()
            updated_count = 0
            
            for token in tokens:
                try:
                    current_price = self._get_token_price(token.mint_address)
                    market_cap = self._get_token_market_cap(token.mint_address)
                    
                    token.current_price = current_price
                    token.market_cap = market_cap
                    updated_count += 1
                    
                except Exception as e:
                    logger.error(f"更新代币 {token.mint_address} 价格失败: {str(e)}", "TokenService")
            
            db.session.commit()
            
            return {
                'success': True,
                'updated_count': updated_count,
                'total_tokens': len(tokens)
            }
            
        except Exception as e:
            logger.error(f"更新代币价格失败: {str(e)}", "TokenService")
            return {
                'success': False,
                'error': str(e)
            }
    
    def get_token_statistics(self) -> Dict:
        """获取代币统计信息"""
        try:
            total_tokens = Token.query.count()
            graduated_tokens = Token.query.filter_by(is_graduated=True).count()
            
            # 获取最近24小时创建的代币
            from datetime import datetime, timedelta
            yesterday = datetime.utcnow() - timedelta(days=1)
            recent_tokens = Token.query.filter(Token.created_at >= yesterday).count()
            
            # 计算总投资金额
            total_investment = db.session.query(db.func.sum(Token.initial_buy_amount)).scalar() or 0
            
            return {
                'total_tokens': total_tokens,
                'graduated_tokens': graduated_tokens,
                'active_tokens': total_tokens - graduated_tokens,
                'recent_24h': recent_tokens,
                'total_investment': total_investment,
                'graduation_rate': round((graduated_tokens / total_tokens * 100), 2) if total_tokens > 0 else 0
            }
            
        except Exception as e:
            logger.error(f"获取代币统计失败: {str(e)}", "TokenService")
            return {
                'total_tokens': 0,
                'graduated_tokens': 0,
                'active_tokens': 0,
                'recent_24h': 0,
                'total_investment': 0,
                'graduation_rate': 0
            }

