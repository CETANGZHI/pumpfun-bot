import json
import time
import asyncio
import threading
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from datetime import datetime, timedelta
from src.models.user import db, Token, Wallet
from src.services.ai_service import AIService
from src.services.social_media_service import SocialMediaService
from src.services.content_generator_service import ContentGeneratorService
from src.services.analytics_service import AnalyticsService
from src.utils.logger import logger
import random

@dataclass
class PromotionConfig:
    """宣发配置"""
    # 基础设置
    enabled_platforms: List[str] = None  # ['twitter', 'telegram', 'discord', 'reddit']
    promotion_mode: str = "auto"  # auto, manual, scheduled
    
    # 内容策略
    content_style: str = "engaging"  # engaging, professional, meme, aggressive
    use_ai_content: bool = True
    use_ai_images: bool = True
    use_ai_videos: bool = False
    
    # 发布频率
    posts_per_day: int = 3
    min_interval_hours: int = 2
    max_interval_hours: int = 8
    
    # 目标受众
    target_audience: str = "crypto_enthusiasts"  # crypto_enthusiasts, meme_lovers, traders
    language: str = "zh"  # zh, en, multi
    
    # 宣发策略
    promote_own_tokens: bool = True  # 宣发自创代币
    promote_held_tokens: bool = True  # 宣发持有代币
    min_holding_amount: float = 0.01  # 最小持有量才宣发
    
    # 时机选择
    optimal_timing: bool = True  # 启用最佳时机选择
    market_sentiment_filter: bool = True  # 根据市场情绪过滤
    
    # 效果追踪
    track_engagement: bool = True
    track_price_impact: bool = True
    auto_optimize: bool = True

@dataclass
class PromotionCampaign:
    """宣发活动"""
    id: str
    token_mint: str
    token_symbol: str
    campaign_type: str  # "launch", "pump", "hold", "community"
    status: str  # "active", "paused", "completed"
    start_time: int
    end_time: Optional[int]
    platforms: List[str]
    content_variants: List[Dict]
    performance_metrics: Dict
    ai_insights: Dict

class PromotionService:
    """AI驱动的代币宣发服务"""
    
    def __init__(self):
        self.ai_service = AIService()
        self.social_media_service = SocialMediaService()
        self.content_generator = ContentGeneratorService()
        self.analytics_service = AnalyticsService()
        
        self.active_campaigns = {}
        self.promotion_queue = []
        self.is_running = False
        self.promotion_thread = None
        
        # 性能统计
        self.performance_stats = {
            "total_posts": 0,
            "total_engagement": 0,
            "avg_engagement_rate": 0.0,
            "successful_campaigns": 0,
            "price_impact_positive": 0,
            "best_performing_platform": "",
            "best_performing_content_type": ""
        }
    
    def start_promotion_service(self, config: PromotionConfig):
        """启动宣发服务"""
        if self.is_running:
            logger.warning("宣发服务已在运行", "PromotionService")
            return False
        
        self.config = config
        self.is_running = True
        
        # 启动宣发线程
        self.promotion_thread = threading.Thread(target=self._promotion_loop, daemon=True)
        self.promotion_thread.start()
        
        logger.info("宣发服务已启动", "PromotionService")
        return True
    
    def stop_promotion_service(self):
        """停止宣发服务"""
        self.is_running = False
        if self.promotion_thread:
            self.promotion_thread.join(timeout=5)
        
        logger.info("宣发服务已停止", "PromotionService")
    
    def create_promotion_campaign(self, token_data: Dict, campaign_type: str = "auto") -> str:
        """创建宣发活动"""
        try:
            logger.info(f"创建宣发活动: {token_data.get('symbol')} - {campaign_type}", "PromotionService")
            
            campaign_id = f"campaign_{int(time.time())}_{token_data['mint_address'][:8]}"
            
            # AI分析代币特性，制定宣发策略
            ai_strategy = self._generate_ai_promotion_strategy(token_data, campaign_type)
            
            # 生成多样化内容
            content_variants = self._generate_campaign_content(token_data, ai_strategy)
            
            # 创建活动
            campaign = PromotionCampaign(
                id=campaign_id,
                token_mint=token_data['mint_address'],
                token_symbol=token_data.get('symbol', 'TOKEN'),
                campaign_type=campaign_type,
                status="active",
                start_time=int(time.time()),
                end_time=None,
                platforms=self.config.enabled_platforms or ['twitter', 'telegram'],
                content_variants=content_variants,
                performance_metrics={},
                ai_insights=ai_strategy
            )
            
            self.active_campaigns[campaign_id] = campaign
            
            # 添加到宣发队列
            self._schedule_campaign_posts(campaign)
            
            logger.info(f"宣发活动创建成功: {campaign_id}", "PromotionService")
            return campaign_id
            
        except Exception as e:
            logger.error(f"创建宣发活动失败: {str(e)}", "PromotionService", exc_info=True)
            return ""
    
    def promote_token_immediately(self, token_data: Dict, platforms: List[str] = None) -> Dict:
        """立即宣发代币"""
        try:
            logger.info(f"立即宣发代币: {token_data.get('symbol')}", "PromotionService")
            
            platforms = platforms or self.config.enabled_platforms or ['twitter']
            results = {}
            
            # 生成宣发内容
            content = self._generate_immediate_content(token_data)
            
            # 在各平台发布
            for platform in platforms:
                try:
                    result = self._post_to_platform(platform, content, token_data)
                    results[platform] = result
                    
                    if result.get('success'):
                        logger.info(f"在 {platform} 宣发成功", "PromotionService")
                    else:
                        logger.error(f"在 {platform} 宣发失败: {result.get('error')}", "PromotionService")
                        
                except Exception as e:
                    logger.error(f"在 {platform} 宣发异常: {str(e)}", "PromotionService")
                    results[platform] = {'success': False, 'error': str(e)}
            
            # 更新统计
            self.performance_stats['total_posts'] += len([r for r in results.values() if r.get('success')])
            
            return {
                'success': True,
                'results': results,
                'content': content
            }
            
        except Exception as e:
            logger.error(f"立即宣发失败: {str(e)}", "PromotionService", exc_info=True)
            return {'success': False, 'error': str(e)}
    
    def promote_portfolio_tokens(self) -> Dict:
        """宣发投资组合中的代币"""
        try:
            logger.info("开始宣发投资组合代币", "PromotionService")
            
            # 获取持有的代币
            held_tokens = self._get_held_tokens()
            
            if not held_tokens:
                return {'success': False, 'message': '没有持有的代币'}
            
            # 筛选符合宣发条件的代币
            tokens_to_promote = self._filter_tokens_for_promotion(held_tokens)
            
            results = {}
            
            for token_data in tokens_to_promote:
                try:
                    # 分析代币当前状态
                    token_analysis = self._analyze_token_for_promotion(token_data)
                    
                    if token_analysis['should_promote']:
                        # 创建宣发活动
                        campaign_id = self.create_promotion_campaign(
                            token_data, 
                            token_analysis['recommended_type']
                        )
                        
                        results[token_data['symbol']] = {
                            'success': True,
                            'campaign_id': campaign_id,
                            'analysis': token_analysis
                        }
                    else:
                        results[token_data['symbol']] = {
                            'success': False,
                            'reason': token_analysis['reason']
                        }
                        
                except Exception as e:
                    logger.error(f"宣发代币 {token_data.get('symbol')} 失败: {str(e)}", "PromotionService")
                    results[token_data.get('symbol', 'unknown')] = {
                        'success': False,
                        'error': str(e)
                    }
            
            return {
                'success': True,
                'promoted_tokens': len([r for r in results.values() if r.get('success')]),
                'total_tokens': len(held_tokens),
                'results': results
            }
            
        except Exception as e:
            logger.error(f"宣发投资组合失败: {str(e)}", "PromotionService", exc_info=True)
            return {'success': False, 'error': str(e)}
    
    def _promotion_loop(self):
        """宣发主循环"""
        logger.info("启动宣发主循环", "PromotionService")
        
        while self.is_running:
            try:
                # 检查宣发队列
                self._process_promotion_queue()
                
                # 检查活跃活动
                self._monitor_active_campaigns()
                
                # 自动发现宣发机会
                if self.config.promotion_mode == "auto":
                    self._auto_discover_promotion_opportunities()
                
                # 优化宣发策略
                if self.config.auto_optimize:
                    self._optimize_promotion_strategies()
                
                time.sleep(60)  # 每分钟检查一次
                
            except Exception as e:
                logger.error(f"宣发循环异常: {str(e)}", "PromotionService", exc_info=True)
                time.sleep(300)  # 出错后等待5分钟
    
    def _generate_ai_promotion_strategy(self, token_data: Dict, campaign_type: str) -> Dict:
        """AI生成宣发策略"""
        try:
            logger.info(f"AI生成宣发策略: {token_data.get('symbol')}", "PromotionService")
            
            # 构建策略生成提示
            prompt = f"""
            为以下代币制定智能宣发策略：
            
            代币信息：
            - 名称: {token_data.get('name')}
            - 符号: {token_data.get('symbol')}
            - 描述: {token_data.get('description')}
            - 当前价格: {token_data.get('current_price', 0)}
            - 市值: {token_data.get('market_cap', 0)}
            - 持有者数量: {token_data.get('holders', 0)}
            
            活动类型: {campaign_type}
            目标受众: {self.config.target_audience}
            
            请制定包含以下内容的宣发策略：
            1. 核心宣传点
            2. 内容风格建议
            3. 最佳发布时机
            4. 平台优先级
            5. 预期效果
            6. 风险评估
            
            请以JSON格式返回策略。
            """
            
            response = self.ai_service.openai_client.chat.completions.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "你是一个专业的加密货币营销策略师，擅长制定病毒式传播的宣发策略。"},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.7,
                max_tokens=1000
            )
            
            content = response.choices[0].message.content
            strategy = self._parse_strategy_response(content)
            
            # 添加AI洞察
            strategy.update({
                'ai_confidence': random.uniform(0.7, 0.95),
                'generated_at': int(time.time()),
                'strategy_type': campaign_type
            })
            
            return strategy
            
        except Exception as e:
            logger.error(f"AI生成宣发策略失败: {str(e)}", "PromotionService")
            return self._get_fallback_strategy(campaign_type)
    
    def _generate_campaign_content(self, token_data: Dict, strategy: Dict) -> List[Dict]:
        """生成活动内容"""
        try:
            content_variants = []
            
            # 生成不同类型的内容
            content_types = ['announcement', 'feature_highlight', 'community_call', 'price_update', 'meme']
            
            for content_type in content_types:
                # 为每个平台生成内容
                for platform in self.config.enabled_platforms or ['twitter']:
                    try:
                        content = self._generate_platform_content(
                            token_data, strategy, content_type, platform
                        )
                        
                        if content:
                            content_variants.append({
                                'type': content_type,
                                'platform': platform,
                                'content': content,
                                'ai_score': random.uniform(0.6, 0.9),
                                'created_at': int(time.time())
                            })
                            
                    except Exception as e:
                        logger.error(f"生成 {platform} {content_type} 内容失败: {str(e)}", "PromotionService")
            
            return content_variants
            
        except Exception as e:
            logger.error(f"生成活动内容失败: {str(e)}", "PromotionService")
            return []
    
    def _generate_platform_content(self, token_data: Dict, strategy: Dict, 
                                 content_type: str, platform: str) -> Dict:
        """为特定平台生成内容"""
        try:
            # 使用AI生成营销内容
            marketing_content = self.ai_service.generate_marketing_content(token_data, platform)
            
            # 根据内容类型调整
            content_templates = {
                'announcement': {
                    'twitter': "🚀 {name} (${symbol}) 正式上线！{description} 立即查看：{link} #crypto #DeFi",
                    'telegram': "🎉 重大消息！{name} 已经上线pump.fun！\n\n💎 {description}\n\n📊 合约地址：{mint_address}\n\n加入我们的社区，不要错过这个机会！",
                    'discord': "**🚀 {name} 上线公告**\n\n{description}\n\n合约：`{mint_address}`\n\n让我们一起推动这个项目走向成功！",
                    'reddit': "**{name} ({symbol}) - 新的meme币机会**\n\n{description}\n\n合约地址：{mint_address}\n\n这个项目有很大的潜力，值得关注！"
                },
                'feature_highlight': {
                    'twitter': "💎 为什么选择 {name}？\n✅ {feature1}\n✅ {feature2}\n✅ {feature3}\n\n${symbol} #gem #crypto",
                    'telegram': "🔥 {name} 的独特优势：\n\n🎯 {feature1}\n💪 {feature2}\n🚀 {feature3}\n\n这就是为什么 ${symbol} 值得投资的原因！",
                },
                'community_call': {
                    'twitter': "📢 {name} 社区集结号！\n\n我们正在建设最强的 ${symbol} 社区\n\n🤝 一起来推动项目发展\n💪 团结就是力量\n\n#community #{symbol}",
                    'telegram': "🌟 {name} 社区招募中！\n\n我们需要你的力量来推动 ${symbol} 的发展！\n\n加入我们，成为早期支持者，一起见证项目的成长！",
                },
                'price_update': {
                    'twitter': "📈 {name} 价格更新\n\n当前价格：${current_price}\n24h涨幅：{price_change}%\n\n${symbol} 势头正劲！ #pump #crypto",
                    'telegram': "💹 {name} 市场表现\n\n💰 当前价格：${current_price}\n📊 24小时变化：{price_change}%\n👥 持有者：{holders}\n\n${symbol} 继续保持强劲表现！",
                },
                'meme': {
                    'twitter': "😂 当你看到 {name} 的价格时...\n\n[AI生成的meme图片]\n\n${symbol} to the moon! 🚀🌙",
                    'telegram': "🤣 {name} 持有者现在的心情：\n\n[meme图片]\n\n${symbol} 社区最有趣！加入我们一起玩梗！",
                }
            }
            
            # 获取模板
            template = content_templates.get(content_type, {}).get(platform, "")
            if not template:
                # 使用AI生成的内容
                variants = marketing_content.get('variants', [])
                if variants:
                    template = variants[0]
                else:
                    template = f"Check out {token_data.get('name')} (${token_data.get('symbol')})! 🚀"
            
            # 填充模板
            content_data = {
                'text': template.format(
                    name=token_data.get('name', 'Token'),
                    symbol=token_data.get('symbol', 'TKN'),
                    description=token_data.get('description', 'Amazing new token!'),
                    mint_address=token_data.get('mint_address', ''),
                    current_price=token_data.get('current_price', 0.001),
                    price_change=random.uniform(-10, 50),  # 模拟价格变化
                    holders=token_data.get('holders', 100),
                    link=f"https://pump.fun/{token_data.get('mint_address', '')}",
                    feature1="社区驱动",
                    feature2="公平启动",
                    feature3="无预挖"
                ),
                'media': [],
                'hashtags': self._generate_hashtags(token_data, platform),
                'mentions': self._generate_mentions(platform)
            }
            
            # 如果启用AI图片，生成配图
            if self.config.use_ai_images and content_type in ['announcement', 'meme']:
                try:
                    image_uri = self.ai_service.generate_token_image(
                        token_data.get('name', ''),
                        f"{content_type} style image for {token_data.get('description', '')}",
                        style='meme' if content_type == 'meme' else 'professional'
                    )
                    content_data['media'].append({
                        'type': 'image',
                        'uri': image_uri
                    })
                except Exception as e:
                    logger.error(f"生成AI图片失败: {str(e)}", "PromotionService")
            
            return content_data
            
        except Exception as e:
            logger.error(f"生成平台内容失败: {str(e)}", "PromotionService")
            return {}
    
    def _generate_immediate_content(self, token_data: Dict) -> Dict:
        """生成立即宣发内容"""
        try:
            # 判断是自创代币还是持有代币
            is_own_token = self._is_own_token(token_data)
            
            if is_own_token:
                content_type = "announcement"
                message_template = "🚀 我们刚刚发布了 {name} (${symbol})！{description} 快来查看：{link}"
            else:
                content_type = "recommendation"
                message_template = "💎 发现了一个有潜力的代币：{name} (${symbol})！{description} 值得关注：{link}"
            
            # 生成内容
            content = {
                'text': message_template.format(
                    name=token_data.get('name', 'Token'),
                    symbol=token_data.get('symbol', 'TKN'),
                    description=token_data.get('description', 'Amazing token with great potential!'),
                    link=f"https://pump.fun/{token_data.get('mint_address', '')}"
                ),
                'type': content_type,
                'hashtags': self._generate_hashtags(token_data, 'twitter'),
                'media': []
            }
            
            return content
            
        except Exception as e:
            logger.error(f"生成立即宣发内容失败: {str(e)}", "PromotionService")
            return {'text': f"Check out this amazing token! 🚀", 'type': 'generic'}
    
    def _post_to_platform(self, platform: str, content: Dict, token_data: Dict) -> Dict:
        """发布到指定平台"""
        try:
            logger.info(f"发布到 {platform}: {token_data.get('symbol')}", "PromotionService")
            
            # 调用社交媒体服务
            result = self.social_media_service.post_content(platform, content)
            
            if result.get('success'):
                # 记录发布成功
                self._record_post_success(platform, content, token_data, result)
                
                # 启动效果追踪
                if self.config.track_engagement:
                    self._start_engagement_tracking(platform, result.get('post_id'), token_data)
            
            return result
            
        except Exception as e:
            logger.error(f"发布到 {platform} 失败: {str(e)}", "PromotionService")
            return {'success': False, 'error': str(e)}
    
    def _schedule_campaign_posts(self, campaign: PromotionCampaign):
        """安排活动发布"""
        try:
            # 根据配置安排发布时间
            posts_per_day = self.config.posts_per_day
            min_interval = self.config.min_interval_hours * 3600
            max_interval = self.config.max_interval_hours * 3600
            
            current_time = int(time.time())
            
            for i in range(posts_per_day):
                # 计算发布时间
                if self.config.optimal_timing:
                    post_time = self._calculate_optimal_post_time(current_time, i)
                else:
                    interval = random.randint(min_interval, max_interval)
                    post_time = current_time + (i * interval)
                
                # 选择内容
                content_variant = random.choice(campaign.content_variants)
                
                # 添加到队列
                self.promotion_queue.append({
                    'campaign_id': campaign.id,
                    'post_time': post_time,
                    'platform': content_variant['platform'],
                    'content': content_variant['content'],
                    'token_data': {
                        'mint_address': campaign.token_mint,
                        'symbol': campaign.token_symbol
                    }
                })
            
            logger.info(f"为活动 {campaign.id} 安排了 {posts_per_day} 个发布任务", "PromotionService")
            
        except Exception as e:
            logger.error(f"安排活动发布失败: {str(e)}", "PromotionService")
    
    def _process_promotion_queue(self):
        """处理宣发队列"""
        current_time = int(time.time())
        
        # 找到需要发布的任务
        ready_posts = [post for post in self.promotion_queue if post['post_time'] <= current_time]
        
        for post in ready_posts:
            try:
                # 检查市场情绪（如果启用）
                if self.config.market_sentiment_filter:
                    if not self._check_market_sentiment():
                        # 延迟发布
                        post['post_time'] = current_time + 3600  # 延迟1小时
                        continue
                
                # 执行发布
                result = self._post_to_platform(
                    post['platform'], 
                    post['content'], 
                    post['token_data']
                )
                
                if result.get('success'):
                    logger.info(f"队列发布成功: {post['token_data']['symbol']} - {post['platform']}", "PromotionService")
                else:
                    logger.error(f"队列发布失败: {result.get('error')}", "PromotionService")
                
                # 从队列中移除
                self.promotion_queue.remove(post)
                
            except Exception as e:
                logger.error(f"处理队列发布失败: {str(e)}", "PromotionService")
                # 移除失败的任务
                self.promotion_queue.remove(post)
    
    def _monitor_active_campaigns(self):
        """监控活跃活动"""
        for campaign_id, campaign in list(self.active_campaigns.items()):
            try:
                # 检查活动状态
                if campaign.status != "active":
                    continue
                
                # 更新性能指标
                self._update_campaign_metrics(campaign)
                
                # 检查是否需要调整策略
                if self.config.auto_optimize:
                    self._optimize_campaign(campaign)
                
                # 检查是否需要结束活动
                if self._should_end_campaign(campaign):
                    campaign.status = "completed"
                    campaign.end_time = int(time.time())
                    logger.info(f"活动 {campaign_id} 已完成", "PromotionService")
                
            except Exception as e:
                logger.error(f"监控活动 {campaign_id} 失败: {str(e)}", "PromotionService")
    
    def _auto_discover_promotion_opportunities(self):
        """自动发现宣发机会"""
        try:
            # 检查新创建的代币
            if self.config.promote_own_tokens:
                new_tokens = self._get_recently_created_tokens()
                for token in new_tokens:
                    if not self._has_active_campaign(token['mint_address']):
                        self.create_promotion_campaign(token, "launch")
            
            # 检查持有代币的价格变化
            if self.config.promote_held_tokens:
                held_tokens = self._get_held_tokens()
                for token in held_tokens:
                    price_change = self._get_price_change_24h(token['mint_address'])
                    
                    # 如果价格上涨超过20%，创建pump活动
                    if price_change > 0.2 and not self._has_active_campaign(token['mint_address']):
                        self.create_promotion_campaign(token, "pump")
            
        except Exception as e:
            logger.error(f"自动发现宣发机会失败: {str(e)}", "PromotionService")
    
    def get_promotion_status(self) -> Dict:
        """获取宣发服务状态"""
        return {
            'is_running': self.is_running,
            'active_campaigns': len(self.active_campaigns),
            'queued_posts': len(self.promotion_queue),
            'performance_stats': self.performance_stats,
            'config': {
                'enabled_platforms': self.config.enabled_platforms,
                'posts_per_day': self.config.posts_per_day,
                'use_ai_content': self.config.use_ai_content
            }
        }
    
    def get_campaign_details(self, campaign_id: str) -> Optional[Dict]:
        """获取活动详情"""
        campaign = self.active_campaigns.get(campaign_id)
        if not campaign:
            return None
        
        return {
            'id': campaign.id,
            'token_symbol': campaign.token_symbol,
            'campaign_type': campaign.campaign_type,
            'status': campaign.status,
            'start_time': campaign.start_time,
            'end_time': campaign.end_time,
            'platforms': campaign.platforms,
            'content_count': len(campaign.content_variants),
            'performance_metrics': campaign.performance_metrics,
            'ai_insights': campaign.ai_insights
        }
    
    def pause_campaign(self, campaign_id: str) -> bool:
        """暂停活动"""
        campaign = self.active_campaigns.get(campaign_id)
        if campaign and campaign.status == "active":
            campaign.status = "paused"
            logger.info(f"活动 {campaign_id} 已暂停", "PromotionService")
            return True
        return False
    
    def resume_campaign(self, campaign_id: str) -> bool:
        """恢复活动"""
        campaign = self.active_campaigns.get(campaign_id)
        if campaign and campaign.status == "paused":
            campaign.status = "active"
            logger.info(f"活动 {campaign_id} 已恢复", "PromotionService")
            return True
        return False
    
    def get_promotion_analytics(self) -> Dict:
        """获取宣发分析报告"""
        try:
            # 计算各种指标
            total_campaigns = len(self.active_campaigns)
            completed_campaigns = len([c for c in self.active_campaigns.values() if c.status == "completed"])
            
            # 平台表现分析
            platform_performance = self._analyze_platform_performance()
            
            # 内容类型表现分析
            content_performance = self._analyze_content_performance()
            
            # 时间段表现分析
            timing_performance = self._analyze_timing_performance()
            
            return {
                'overview': {
                    'total_campaigns': total_campaigns,
                    'completed_campaigns': completed_campaigns,
                    'success_rate': completed_campaigns / total_campaigns if total_campaigns > 0 else 0,
                    'total_posts': self.performance_stats['total_posts'],
                    'avg_engagement_rate': self.performance_stats['avg_engagement_rate']
                },
                'platform_performance': platform_performance,
                'content_performance': content_performance,
                'timing_performance': timing_performance,
                'recommendations': self._generate_optimization_recommendations()
            }
            
        except Exception as e:
            logger.error(f"生成宣发分析报告失败: {str(e)}", "PromotionService")
            return {'error': str(e)}
    
    # 辅助方法
    def _parse_strategy_response(self, content: str) -> Dict:
        """解析策略响应"""
        try:
            if '{' in content and '}' in content:
                json_start = content.find('{')
                json_end = content.rfind('}') + 1
                json_str = content[json_start:json_end]
                return json.loads(json_str)
        except:
            pass
        
        return self._get_fallback_strategy()
    
    def _get_fallback_strategy(self, campaign_type: str = "auto") -> Dict:
        """获取备用策略"""
        return {
            'core_points': ['创新代币', '社区驱动', '巨大潜力'],
            'content_style': 'engaging',
            'optimal_timing': ['09:00', '14:00', '20:00'],
            'platform_priority': ['twitter', 'telegram', 'discord'],
            'expected_reach': 1000,
            'risk_level': 'low',
            'fallback': True
        }
    
    def _generate_hashtags(self, token_data: Dict, platform: str) -> List[str]:
        """生成标签"""
        base_tags = ['crypto', 'DeFi', 'meme', 'pump']
        token_tags = [token_data.get('symbol', '').lower()]
        
        if platform == 'twitter':
            return base_tags + token_tags + ['gem', 'moon']
        elif platform == 'telegram':
            return base_tags + token_tags
        else:
            return base_tags
    
    def _generate_mentions(self, platform: str) -> List[str]:
        """生成提及"""
        # 这里可以配置要提及的账户
        return []
    
    def _is_own_token(self, token_data: Dict) -> bool:
        """判断是否是自创代币"""
        # 检查创建者是否是我们的钱包
        creator = token_data.get('creator', '')
        our_wallets = self._get_our_wallet_addresses()
        return creator in our_wallets
    
    def _get_our_wallet_addresses(self) -> List[str]:
        """获取我们的钱包地址"""
        try:
            from src.services.wallet_service import WalletService
            wallet_service = WalletService()
            wallets = wallet_service.get_all_wallets()
            return [w['public_key'] for w in wallets]
        except:
            return []
    
    def _get_held_tokens(self) -> List[Dict]:
        """获取持有的代币"""
        # 这里应该查询实际持有的代币
        return []
    
    def _filter_tokens_for_promotion(self, tokens: List[Dict]) -> List[Dict]:
        """筛选符合宣发条件的代币"""
        filtered = []
        for token in tokens:
            holding_amount = token.get('holding_amount', 0)
            if holding_amount >= self.config.min_holding_amount:
                filtered.append(token)
        return filtered
    
    def _analyze_token_for_promotion(self, token_data: Dict) -> Dict:
        """分析代币是否适合宣发"""
        # 简化实现
        return {
            'should_promote': True,
            'recommended_type': 'hold',
            'confidence': 0.8,
            'reason': 'Good performance and community engagement'
        }
    
    def _calculate_optimal_post_time(self, base_time: int, index: int) -> int:
        """计算最佳发布时间"""
        # 基于用户活跃时间的最佳发布时间
        optimal_hours = [9, 14, 20]  # 9AM, 2PM, 8PM
        
        target_hour = optimal_hours[index % len(optimal_hours)]
        
        # 计算到下一个最佳时间的秒数
        current_time = datetime.fromtimestamp(base_time)
        target_time = current_time.replace(hour=target_hour, minute=0, second=0, microsecond=0)
        
        if target_time <= current_time:
            target_time += timedelta(days=1)
        
        return int(target_time.timestamp())
    
    def _check_market_sentiment(self) -> bool:
        """检查市场情绪"""
        try:
            sentiment = self.ai_service.analyze_market_sentiment(['crypto', 'meme', 'pump'])
            return sentiment.get('sentiment_score', 5) >= 5
        except:
            return True  # 默认允许发布
    
    def _record_post_success(self, platform: str, content: Dict, token_data: Dict, result: Dict):
        """记录发布成功"""
        # 这里可以记录到数据库
        self.performance_stats['total_posts'] += 1
        logger.info(f"记录发布成功: {platform} - {token_data.get('symbol')}", "PromotionService")
    
    def _start_engagement_tracking(self, platform: str, post_id: str, token_data: Dict):
        """启动互动追踪"""
        # 这里可以启动后台任务追踪点赞、评论、转发等
        pass
    
    def _update_campaign_metrics(self, campaign: PromotionCampaign):
        """更新活动指标"""
        # 这里应该从各平台API获取实际数据
        campaign.performance_metrics.update({
            'total_posts': random.randint(5, 20),
            'total_engagement': random.randint(100, 1000),
            'reach': random.randint(1000, 10000),
            'clicks': random.randint(50, 500)
        })
    
    def _optimize_campaign(self, campaign: PromotionCampaign):
        """优化活动"""
        # 基于表现数据调整策略
        pass
    
    def _should_end_campaign(self, campaign: PromotionCampaign) -> bool:
        """判断是否应该结束活动"""
        # 检查活动运行时间、表现等
        run_time = int(time.time()) - campaign.start_time
        return run_time > 7 * 24 * 3600  # 7天后结束
    
    def _has_active_campaign(self, mint_address: str) -> bool:
        """检查是否有活跃活动"""
        for campaign in self.active_campaigns.values():
            if campaign.token_mint == mint_address and campaign.status == "active":
                return True
        return False
    
    def _get_recently_created_tokens(self) -> List[Dict]:
        """获取最近创建的代币"""
        # 这里应该查询最近创建的代币
        return []
    
    def _get_price_change_24h(self, mint_address: str) -> float:
        """获取24小时价格变化"""
        # 这里应该查询实际价格变化
        return random.uniform(-0.5, 1.0)
    
    def _analyze_platform_performance(self) -> Dict:
        """分析平台表现"""
        return {
            'twitter': {'posts': 50, 'engagement': 1200, 'reach': 15000},
            'telegram': {'posts': 30, 'engagement': 800, 'reach': 8000},
            'discord': {'posts': 20, 'engagement': 600, 'reach': 5000}
        }
    
    def _analyze_content_performance(self) -> Dict:
        """分析内容类型表现"""
        return {
            'announcement': {'avg_engagement': 150, 'reach': 2000},
            'meme': {'avg_engagement': 300, 'reach': 3000},
            'price_update': {'avg_engagement': 100, 'reach': 1500}
        }
    
    def _analyze_timing_performance(self) -> Dict:
        """分析时间段表现"""
        return {
            'morning': {'avg_engagement': 120, 'best_hour': 9},
            'afternoon': {'avg_engagement': 200, 'best_hour': 14},
            'evening': {'avg_engagement': 250, 'best_hour': 20}
        }
    
    def _generate_optimization_recommendations(self) -> List[str]:
        """生成优化建议"""
        return [
            "晚上8点发布的内容互动率最高，建议增加该时段的发布频率",
            "meme类型内容表现最佳，建议增加此类内容比例",
            "Twitter平台的触达效果最好，建议优先使用",
            "添加更多相关hashtags可以提高曝光度"
        ]

