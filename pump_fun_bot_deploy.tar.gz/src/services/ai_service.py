import os
import json
import time
import random
import requests
from typing import Dict, List, Optional, Any
from src.utils.logger import logger
import openai

class AIService:
    """增强的AI服务 - 支持多种AI功能"""
    
    def __init__(self):
        self.openai_client = openai.OpenAI(
            api_key=os.getenv('OPENAI_API_KEY'),
            base_url=os.getenv('OPENAI_API_BASE', 'https://api.openai.com/v1')
        )
        self.backup_themes = self._load_backup_themes()
        
    def _load_backup_themes(self) -> List[Dict]:
        """加载备用主题库"""
        return [
            {
                "category": "动物",
                "themes": ["可爱小猫", "忠诚狗狗", "聪明海豚", "威猛老虎", "优雅天鹅", "神秘猫头鹰"]
            },
            {
                "category": "太空",
                "themes": ["火星探索", "银河系", "黑洞", "星际旅行", "外星文明", "宇宙奥秘"]
            },
            {
                "category": "科技",
                "themes": ["人工智能", "区块链", "量子计算", "虚拟现实", "机器人", "未来科技"]
            },
            {
                "category": "自然",
                "themes": ["森林", "海洋", "山脉", "沙漠", "极光", "彩虹"]
            },
            {
                "category": "文化",
                "themes": ["古代文明", "神话传说", "艺术创作", "音乐节拍", "诗歌韵律", "哲学思考"]
            },
            {
                "category": "情感",
                "themes": ["快乐", "希望", "勇气", "友谊", "爱情", "梦想"]
            },
            {
                "category": "游戏",
                "themes": ["冒险", "竞技", "策略", "角色扮演", "解谜", "模拟"]
            },
            {
                "category": "食物",
                "themes": ["美味披萨", "香甜蛋糕", "新鲜水果", "精致寿司", "浓郁咖啡", "清香茶叶"]
            }
        ]
    
    def generate_token_metadata(self, theme: str = "", style: str = "meme", 
                              language: str = "zh", creativity_level: float = 0.8) -> Dict:
        """生成代币元数据（增强版）"""
        try:
            logger.info(f"开始AI生成代币元数据，主题: {theme}, 风格: {style}", "AIService")
            
            # 如果没有提供主题，随机选择一个
            if not theme:
                theme = self._get_random_theme()
            
            # 构建提示词
            prompt = self._build_metadata_prompt(theme, style, language, creativity_level)
            
            # 调用GPT生成元数据
            response = self.openai_client.chat.completions.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "你是一个专业的加密货币代币创建专家，擅长创造有趣、吸引人的meme币概念。"},
                    {"role": "user", "content": prompt}
                ],
                temperature=creativity_level,
                max_tokens=500
            )
            
            # 解析响应
            content = response.choices[0].message.content
            metadata = self._parse_metadata_response(content)
            
            # 生成代币图片
            if metadata.get('name'):
                image_uri = self.generate_token_image(
                    metadata['name'], 
                    metadata.get('description', ''),
                    style=style
                )
                metadata['image_uri'] = image_uri
            
            # 添加额外的AI生成属性
            metadata.update({
                'ai_generated': True,
                'theme': theme,
                'style': style,
                'creativity_score': creativity_level,
                'generation_timestamp': int(time.time())
            })
            
            logger.info(f"AI元数据生成成功: {metadata['name']} ({metadata['symbol']})", "AIService")
            return metadata
            
        except Exception as e:
            logger.error(f"AI生成元数据失败: {str(e)}", "AIService")
            return self._generate_fallback_metadata(theme, style)
    
    def generate_token_image(self, name: str, description: str, 
                           style: str = "meme", size: str = "1024x1024") -> str:
        """生成代币图片"""
        try:
            logger.info(f"开始AI生成代币图片: {name}", "AIService")
            
            # 构建图片生成提示词
            image_prompt = self._build_image_prompt(name, description, style)
            
            # 调用DALL-E生成图片
            response = self.openai_client.images.generate(
                model="dall-e-3",
                prompt=image_prompt,
                size=size,
                quality="standard",
                n=1
            )
            
            image_url = response.data[0].url
            
            # 下载并上传到去中心化存储
            uploaded_uri = self._upload_image_to_storage(image_url, name)
            
            logger.info(f"代币图片生成成功: {uploaded_uri}", "AIService")
            return uploaded_uri
            
        except Exception as e:
            logger.error(f"生成代币图片失败: {str(e)}", "AIService")
            return self._get_default_image_uri()
    
    def analyze_token_potential(self, token_data: Dict) -> Dict:
        """AI分析代币潜力"""
        try:
            logger.info(f"开始AI分析代币潜力: {token_data.get('symbol')}", "AIService")
            
            # 构建分析提示词
            analysis_prompt = f"""
            请分析以下代币的潜力：
            
            代币信息：
            - 名称: {token_data.get('name')}
            - 符号: {token_data.get('symbol')}
            - 描述: {token_data.get('description')}
            - 当前价格: {token_data.get('current_price', 0)}
            - 市值: {token_data.get('market_cap', 0)}
            - 持有者数量: {token_data.get('holders', 0)}
            - 24h交易量: {token_data.get('volume_24h', 0)}
            
            请从以下维度进行评分（1-10分）：
            1. 概念创新性
            2. 市场接受度
            3. 社区潜力
            4. 技术基础
            5. 风险评估
            
            请以JSON格式返回分析结果。
            """
            
            response = self.openai_client.chat.completions.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "你是一个专业的加密货币分析师，擅长评估meme币和新兴代币的投资潜力。"},
                    {"role": "user", "content": analysis_prompt}
                ],
                temperature=0.3,
                max_tokens=800
            )
            
            # 解析分析结果
            content = response.choices[0].message.content
            analysis = self._parse_analysis_response(content)
            
            logger.info(f"代币潜力分析完成，总分: {analysis.get('total_score', 0)}", "AIService")
            return analysis
            
        except Exception as e:
            logger.error(f"AI分析代币潜力失败: {str(e)}", "AIService")
            return self._generate_fallback_analysis()
    
    def generate_marketing_content(self, token_data: Dict, platform: str = "twitter") -> Dict:
        """生成营销内容"""
        try:
            logger.info(f"开始生成营销内容: {token_data.get('symbol')} - {platform}", "AIService")
            
            platform_configs = {
                "twitter": {"max_length": 280, "hashtags": True, "emojis": True},
                "telegram": {"max_length": 4096, "hashtags": True, "emojis": True},
                "discord": {"max_length": 2000, "hashtags": False, "emojis": True},
                "reddit": {"max_length": 10000, "hashtags": False, "emojis": False}
            }
            
            config = platform_configs.get(platform, platform_configs["twitter"])
            
            prompt = f"""
            为以下代币创建{platform}营销内容：
            
            代币信息：
            - 名称: {token_data.get('name')}
            - 符号: {token_data.get('symbol')}
            - 描述: {token_data.get('description')}
            - 合约地址: {token_data.get('mint_address')}
            
            要求：
            - 最大长度: {config['max_length']}字符
            - {'包含相关hashtags' if config['hashtags'] else '不使用hashtags'}
            - {'使用适当的emoji' if config['emojis'] else '不使用emoji'}
            - 语调要有趣、吸引人
            - 突出代币的独特性
            
            请生成3个不同风格的营销文案。
            """
            
            response = self.openai_client.chat.completions.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": f"你是一个专业的{platform}营销专家，擅长创造病毒式传播的加密货币内容。"},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.9,
                max_tokens=1000
            )
            
            content = response.choices[0].message.content
            marketing_content = self._parse_marketing_response(content, platform)
            
            logger.info(f"营销内容生成成功: {len(marketing_content.get('variants', []))} 个版本", "AIService")
            return marketing_content
            
        except Exception as e:
            logger.error(f"生成营销内容失败: {str(e)}", "AIService")
            return self._generate_fallback_marketing(token_data, platform)
    
    def generate_batch_themes(self, count: int, category: str = "") -> List[str]:
        """批量生成主题"""
        try:
            logger.info(f"开始批量生成 {count} 个主题，类别: {category}", "AIService")
            
            prompt = f"""
            请生成 {count} 个适合创建meme币的创意主题。
            {'类别限制: ' + category if category else ''}
            
            要求：
            - 每个主题要有趣、独特
            - 适合制作成meme币
            - 具有社区传播潜力
            - 避免敏感或争议性内容
            
            请以简洁的列表形式返回，每行一个主题。
            """
            
            response = self.openai_client.chat.completions.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "你是一个创意专家，擅长生成有趣的meme币主题概念。"},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.8,
                max_tokens=500
            )
            
            content = response.choices[0].message.content
            themes = [line.strip() for line in content.split('\n') if line.strip()]
            
            # 确保返回指定数量的主题
            while len(themes) < count:
                themes.extend(self._get_backup_themes(count - len(themes)))
            
            return themes[:count]
            
        except Exception as e:
            logger.error(f"批量生成主题失败: {str(e)}", "AIService")
            return self._get_backup_themes(count)
    
    def analyze_market_sentiment(self, keywords: List[str]) -> Dict:
        """分析市场情绪"""
        try:
            logger.info(f"开始分析市场情绪，关键词: {keywords}", "AIService")
            
            # 这里可以集成社交媒体API获取实时数据
            # 现在使用模拟数据进行AI分析
            
            prompt = f"""
            基于以下关键词分析当前加密货币市场情绪：
            关键词: {', '.join(keywords)}
            
            请分析：
            1. 整体市场情绪（乐观/中性/悲观）
            2. 热门趋势和话题
            3. 投资者关注点
            4. 风险因素
            5. 机会点
            
            请以JSON格式返回分析结果，包含情绪评分（1-10）。
            """
            
            response = self.openai_client.chat.completions.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "你是一个专业的市场情绪分析师，擅长解读加密货币市场动态。"},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.3,
                max_tokens=800
            )
            
            content = response.choices[0].message.content
            sentiment = self._parse_sentiment_response(content)
            
            logger.info(f"市场情绪分析完成，情绪评分: {sentiment.get('sentiment_score', 0)}", "AIService")
            return sentiment
            
        except Exception as e:
            logger.error(f"分析市场情绪失败: {str(e)}", "AIService")
            return self._generate_fallback_sentiment()
    
    def generate_trading_strategy(self, market_data: Dict, risk_level: str = "medium") -> Dict:
        """AI生成交易策略"""
        try:
            logger.info(f"开始生成交易策略，风险级别: {risk_level}", "AIService")
            
            prompt = f"""
            基于以下市场数据生成交易策略：
            
            市场数据：
            - 当前市场趋势: {market_data.get('trend', 'unknown')}
            - 波动率: {market_data.get('volatility', 0)}
            - 交易量: {market_data.get('volume', 0)}
            - 支撑位: {market_data.get('support', 0)}
            - 阻力位: {market_data.get('resistance', 0)}
            
            风险偏好: {risk_level}
            
            请生成包含以下内容的交易策略：
            1. 入场策略
            2. 止盈策略
            3. 止损策略
            4. 仓位管理
            5. 风险控制
            
            请以JSON格式返回策略配置。
            """
            
            response = self.openai_client.chat.completions.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "你是一个专业的量化交易策略师，擅长设计风险可控的交易策略。"},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.2,
                max_tokens=1000
            )
            
            content = response.choices[0].message.content
            strategy = self._parse_strategy_response(content)
            
            logger.info(f"交易策略生成完成: {strategy.get('strategy_name', 'Unknown')}", "AIService")
            return strategy
            
        except Exception as e:
            logger.error(f"生成交易策略失败: {str(e)}", "AIService")
            return self._generate_fallback_strategy(risk_level)
    
    def _build_metadata_prompt(self, theme: str, style: str, language: str, creativity: float) -> str:
        """构建元数据生成提示词"""
        creativity_desc = "非常创新" if creativity > 0.8 else "适度创新" if creativity > 0.5 else "保守稳妥"
        
        return f"""
        请为一个{style}风格的加密货币代币生成元数据，主题是"{theme}"。
        
        要求：
        - 语言: {language}
        - 创意水平: {creativity_desc}
        - 代币名称: 有趣、朗朗上口，与主题相关
        - 代币符号: 3-6个字符，简洁有力
        - 描述: 50-100字，吸引人且有趣
        
        请以以下JSON格式返回：
        {{
            "name": "代币名称",
            "symbol": "代币符号",
            "description": "代币描述"
        }}
        """
    
    def _build_image_prompt(self, name: str, description: str, style: str) -> str:
        """构建图片生成提示词"""
        style_prompts = {
            "meme": "cute, funny, meme-style, cartoon, vibrant colors, playful",
            "professional": "clean, modern, professional, minimalist, high-quality",
            "artistic": "artistic, creative, unique, abstract, colorful",
            "retro": "retro, vintage, 80s style, neon colors, nostalgic",
            "futuristic": "futuristic, sci-fi, high-tech, glowing, cyberpunk"
        }
        
        style_desc = style_prompts.get(style, style_prompts["meme"])
        
        return f"""
        Create a logo for a cryptocurrency token called "{name}". 
        Description: {description}
        Style: {style_desc}
        Requirements: suitable for crypto token, memorable, clean design, works well as small icon
        """
    
    def _get_random_theme(self) -> str:
        """获取随机主题"""
        category = random.choice(self.backup_themes)
        return random.choice(category["themes"])
    
    def _get_backup_themes(self, count: int) -> List[str]:
        """获取备用主题"""
        all_themes = []
        for category in self.backup_themes:
            all_themes.extend(category["themes"])
        
        return random.sample(all_themes, min(count, len(all_themes)))
    
    def _parse_metadata_response(self, content: str) -> Dict:
        """解析元数据响应"""
        try:
            # 尝试解析JSON
            if '{' in content and '}' in content:
                json_start = content.find('{')
                json_end = content.rfind('}') + 1
                json_str = content[json_start:json_end]
                return json.loads(json_str)
        except:
            pass
        
        # 如果JSON解析失败，使用文本解析
        return self._extract_metadata_from_text(content)
    
    def _extract_metadata_from_text(self, content: str) -> Dict:
        """从文本中提取元数据"""
        lines = content.split('\n')
        metadata = {}
        
        for line in lines:
            if '名称' in line or 'name' in line.lower():
                metadata['name'] = line.split(':')[-1].strip().strip('"')
            elif '符号' in line or 'symbol' in line.lower():
                metadata['symbol'] = line.split(':')[-1].strip().strip('"')
            elif '描述' in line or 'description' in line.lower():
                metadata['description'] = line.split(':')[-1].strip().strip('"')
        
        # 如果解析失败，返回默认值
        if not metadata.get('name'):
            metadata = self._generate_fallback_metadata()
        
        return metadata
    
    def _generate_fallback_metadata(self, theme: str = "", style: str = "meme") -> Dict:
        """生成备用元数据"""
        fallback_names = [
            "MoonCat", "RocketDog", "DiamondPaws", "GoldenShiba", "CosmicPepe",
            "SuperMeme", "CryptoKitty", "BlockchainBear", "DigitalDoge", "MetaMonkey"
        ]
        
        name = random.choice(fallback_names)
        symbol = name[:4].upper() + str(random.randint(10, 99))
        
        return {
            'name': name,
            'symbol': symbol,
            'description': f"The ultimate {name.lower()} token for the crypto community! Join the revolution!",
            'ai_generated': False,
            'fallback': True
        }
    
    def _upload_image_to_storage(self, image_url: str, name: str) -> str:
        """上传图片到去中心化存储"""
        try:
            # 下载图片
            response = requests.get(image_url, timeout=30)
            if response.status_code == 200:
                # 这里应该上传到Arweave或IPFS
                # 现在返回原始URL作为占位符
                logger.info(f"图片下载成功: {name}", "AIService")
                return image_url
            else:
                raise Exception(f"下载图片失败: {response.status_code}")
        except Exception as e:
            logger.error(f"上传图片到存储失败: {str(e)}", "AIService")
            return self._get_default_image_uri()
    
    def _get_default_image_uri(self) -> str:
        """获取默认图片URI"""
        return "https://via.placeholder.com/512x512/FF6B6B/FFFFFF?text=TOKEN"
    
    def _parse_analysis_response(self, content: str) -> Dict:
        """解析分析响应"""
        try:
            if '{' in content and '}' in content:
                json_start = content.find('{')
                json_end = content.rfind('}') + 1
                json_str = content[json_start:json_end]
                return json.loads(json_str)
        except:
            pass
        
        return self._generate_fallback_analysis()
    
    def _generate_fallback_analysis(self) -> Dict:
        """生成备用分析"""
        return {
            'concept_innovation': random.randint(5, 8),
            'market_acceptance': random.randint(4, 7),
            'community_potential': random.randint(5, 9),
            'technical_foundation': random.randint(6, 8),
            'risk_assessment': random.randint(3, 6),
            'total_score': random.randint(25, 35),
            'recommendation': 'moderate_buy',
            'fallback': True
        }
    
    def _parse_marketing_response(self, content: str, platform: str) -> Dict:
        """解析营销内容响应"""
        lines = content.split('\n')
        variants = []
        
        for line in lines:
            line = line.strip()
            if line and not line.startswith('#') and len(line) > 10:
                variants.append(line)
        
        if not variants:
            variants = [f"Check out this amazing new token! 🚀 #{platform}"]
        
        return {
            'platform': platform,
            'variants': variants[:3],  # 最多3个版本
            'generated_at': int(time.time())
        }
    
    def _generate_fallback_marketing(self, token_data: Dict, platform: str) -> Dict:
        """生成备用营销内容"""
        name = token_data.get('name', 'Token')
        symbol = token_data.get('symbol', 'TKN')
        
        templates = [
            f"🚀 Introducing {name} (${symbol})! The next big thing in crypto! #crypto #{platform}",
            f"💎 {name} is here! Don't miss out on this gem! ${symbol} #meme #crypto",
            f"🌙 {name} to the moon! Join the community! ${symbol} #DeFi #crypto"
        ]
        
        return {
            'platform': platform,
            'variants': templates,
            'generated_at': int(time.time()),
            'fallback': True
        }
    
    def _parse_sentiment_response(self, content: str) -> Dict:
        """解析情绪分析响应"""
        try:
            if '{' in content and '}' in content:
                json_start = content.find('{')
                json_end = content.rfind('}') + 1
                json_str = content[json_start:json_end]
                return json.loads(json_str)
        except:
            pass
        
        return self._generate_fallback_sentiment()
    
    def _generate_fallback_sentiment(self) -> Dict:
        """生成备用情绪分析"""
        return {
            'sentiment_score': random.randint(4, 7),
            'overall_sentiment': 'neutral',
            'trends': ['DeFi', 'Meme coins', 'AI tokens'],
            'risk_factors': ['Market volatility', 'Regulatory uncertainty'],
            'opportunities': ['New project launches', 'Community growth'],
            'fallback': True
        }
    
    def _parse_strategy_response(self, content: str) -> Dict:
        """解析策略响应"""
        try:
            if '{' in content and '}' in content:
                json_start = content.find('{')
                json_end = content.rfind('}') + 1
                json_str = content[json_start:json_end]
                return json.loads(json_str)
        except:
            pass
        
        return self._generate_fallback_strategy()
    
    def _generate_fallback_strategy(self, risk_level: str = "medium") -> Dict:
        """生成备用策略"""
        risk_configs = {
            "low": {"max_position": 0.05, "stop_loss": 0.05, "take_profit": 0.15},
            "medium": {"max_position": 0.10, "stop_loss": 0.10, "take_profit": 0.25},
            "high": {"max_position": 0.20, "stop_loss": 0.15, "take_profit": 0.50}
        }
        
        config = risk_configs.get(risk_level, risk_configs["medium"])
        
        return {
            'strategy_name': f'{risk_level.title()} Risk Strategy',
            'entry_strategy': 'DCA on dips',
            'max_position_size': config["max_position"],
            'stop_loss_percentage': config["stop_loss"],
            'take_profit_percentage': config["take_profit"],
            'risk_level': risk_level,
            'fallback': True
        }

