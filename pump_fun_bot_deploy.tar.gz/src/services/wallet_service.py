import json
import os
import time
from typing import List, Dict, Optional, Tuple
from cryptography.fernet import Fernet
from src.models.user import db, Wallet
from src.utils.solana_client import SolanaClient
from src.utils.logger import logger
import base58
import secrets

class WalletService:
    """增强的钱包管理服务"""
    
    def __init__(self):
        self.solana_client = SolanaClient()
        self.encryption_key = self._get_or_create_encryption_key()
        self.cipher_suite = Fernet(self.encryption_key)
        
    def _get_or_create_encryption_key(self) -> bytes:
        """获取或创建加密密钥"""
        key_file = os.path.join(os.path.dirname(__file__), '..', 'database', 'wallet.key')
        
        if os.path.exists(key_file):
            with open(key_file, 'rb') as f:
                return f.read()
        else:
            key = Fernet.generate_key()
            os.makedirs(os.path.dirname(key_file), exist_ok=True)
            with open(key_file, 'wb') as f:
                f.write(key)
            return key
    
    def _encrypt_private_key(self, private_key: str) -> str:
        """加密私钥"""
        return self.cipher_suite.encrypt(private_key.encode()).decode()
    
    def _decrypt_private_key(self, encrypted_key: str) -> str:
        """解密私钥"""
        return self.cipher_suite.decrypt(encrypted_key.encode()).decode()
    
    def generate_wallets(self, count: int, tags: List[str] = None) -> List[Dict]:
        """生成多个钱包"""
        wallets = []
        tags = tags or []
        
        logger.info(f"开始生成 {count} 个钱包", "WalletService")
        
        for i in range(count):
            try:
                # 生成新的密钥对
                private_key_bytes = secrets.token_bytes(32)
                private_key_array = list(private_key_bytes)
                private_key_json = json.dumps(private_key_array)
                
                # 使用Solana客户端生成公钥
                public_key = self.solana_client.get_public_key_from_private_key(private_key_array)
                
                # 加密私钥
                encrypted_private_key = self._encrypt_private_key(private_key_json)
                
                # 创建钱包记录
                wallet = Wallet(
                    public_key=public_key,
                    private_key_encrypted=encrypted_private_key,
                    tags=json.dumps(tags + [f"batch_{int(time.time())}"]),
                    is_active=True
                )
                
                db.session.add(wallet)
                db.session.commit()
                
                wallets.append({
                    'id': wallet.id,
                    'public_key': wallet.public_key,
                    'balance': 0.0,
                    'tags': tags,
                    'created_at': wallet.created_at.isoformat()
                })
                
                logger.info(f"生成钱包 {i+1}/{count}: {public_key}", "WalletService")
                
            except Exception as e:
                logger.error(f"生成钱包 {i+1} 失败: {str(e)}", "WalletService")
                continue
        
        logger.info(f"成功生成 {len(wallets)} 个钱包", "WalletService")
        return wallets
    
    def get_all_wallets(self, include_inactive: bool = False) -> List[Dict]:
        """获取所有钱包"""
        query = Wallet.query
        if not include_inactive:
            query = query.filter_by(is_active=True)
        
        wallets = query.all()
        result = []
        
        for wallet in wallets:
            result.append({
                'id': wallet.id,
                'public_key': wallet.public_key,
                'balance': wallet.balance,
                'is_main': wallet.is_main,
                'is_active': wallet.is_active,
                'tags': json.loads(wallet.tags) if wallet.tags else [],
                'created_at': wallet.created_at.isoformat(),
                'updated_at': wallet.updated_at.isoformat()
            })
        
        return result
    
    def get_wallet_by_id(self, wallet_id: int) -> Optional[Dict]:
        """根据ID获取钱包"""
        wallet = Wallet.query.get(wallet_id)
        if not wallet:
            return None
        
        return {
            'id': wallet.id,
            'public_key': wallet.public_key,
            'balance': wallet.balance,
            'is_main': wallet.is_main,
            'is_active': wallet.is_active,
            'tags': json.loads(wallet.tags) if wallet.tags else [],
            'created_at': wallet.created_at.isoformat(),
            'updated_at': wallet.updated_at.isoformat()
        }
    
    def get_wallet_private_key(self, wallet_id: int) -> Optional[List[int]]:
        """获取钱包私钥（解密后）"""
        wallet = Wallet.query.get(wallet_id)
        if not wallet:
            return None
        
        try:
            decrypted_key = self._decrypt_private_key(wallet.private_key_encrypted)
            return json.loads(decrypted_key)
        except Exception as e:
            logger.error(f"解密钱包 {wallet_id} 私钥失败: {str(e)}", "WalletService")
            return None
    
    def get_main_wallet_info(self) -> Optional[Dict]:
        """获取主钱包信息"""
        main_wallet = Wallet.query.filter_by(is_main=True, is_active=True).first()
        if not main_wallet:
            # 如果没有主钱包，尝试从环境变量创建
            return self._create_main_wallet_from_env()
        
        return {
            'id': main_wallet.id,
            'public_key': main_wallet.public_key,
            'balance': main_wallet.balance,
            'is_main': True,
            'created_at': main_wallet.created_at.isoformat()
        }
    
    def _create_main_wallet_from_env(self) -> Optional[Dict]:
        """从环境变量创建主钱包"""
        private_key_env = os.getenv('PRIVATE_KEY')
        if not private_key_env:
            return None
        
        try:
            private_key_array = json.loads(private_key_env)
            public_key = self.solana_client.get_public_key_from_private_key(private_key_array)
            
            # 检查是否已存在
            existing_wallet = Wallet.query.filter_by(public_key=public_key).first()
            if existing_wallet:
                existing_wallet.is_main = True
                db.session.commit()
                return {
                    'id': existing_wallet.id,
                    'public_key': existing_wallet.public_key,
                    'balance': existing_wallet.balance,
                    'is_main': True
                }
            
            # 创建新的主钱包
            encrypted_private_key = self._encrypt_private_key(private_key_env)
            
            main_wallet = Wallet(
                public_key=public_key,
                private_key_encrypted=encrypted_private_key,
                is_main=True,
                is_active=True,
                tags=json.dumps(['main', 'env_imported'])
            )
            
            db.session.add(main_wallet)
            db.session.commit()
            
            logger.info(f"从环境变量创建主钱包: {public_key}", "WalletService")
            
            return {
                'id': main_wallet.id,
                'public_key': main_wallet.public_key,
                'balance': 0.0,
                'is_main': True,
                'created_at': main_wallet.created_at.isoformat()
            }
            
        except Exception as e:
            logger.error(f"从环境变量创建主钱包失败: {str(e)}", "WalletService")
            return None
    
    def get_wallet_balance(self, wallet_id: int) -> float:
        """获取钱包余额"""
        wallet = Wallet.query.get(wallet_id)
        if not wallet:
            raise ValueError(f"钱包 {wallet_id} 不存在")
        
        try:
            balance = self.solana_client.get_balance(wallet.public_key)
            
            # 更新数据库中的余额
            wallet.balance = balance
            db.session.commit()
            
            return balance
        except Exception as e:
            logger.error(f"获取钱包 {wallet_id} 余额失败: {str(e)}", "WalletService")
            return wallet.balance  # 返回数据库中的余额
    
    def update_all_balances(self) -> Dict:
        """更新所有钱包余额"""
        wallets = Wallet.query.filter_by(is_active=True).all()
        updated_count = 0
        failed_count = 0
        total_balance = 0.0
        
        logger.info(f"开始更新 {len(wallets)} 个钱包余额", "WalletService")
        
        for wallet in wallets:
            try:
                balance = self.solana_client.get_balance(wallet.public_key)
                wallet.balance = balance
                total_balance += balance
                updated_count += 1
                
                logger.debug(f"更新钱包 {wallet.public_key} 余额: {balance} SOL", "WalletService")
                
            except Exception as e:
                logger.error(f"更新钱包 {wallet.public_key} 余额失败: {str(e)}", "WalletService")
                failed_count += 1
        
        db.session.commit()
        
        result = {
            'updated_count': updated_count,
            'failed_count': failed_count,
            'total_wallets': len(wallets),
            'total_balance': total_balance
        }
        
        logger.info(f"余额更新完成: {updated_count} 成功, {failed_count} 失败", "WalletService")
        return result
    
    def get_wallet_count(self) -> Dict:
        """获取钱包统计"""
        total = Wallet.query.count()
        active = Wallet.query.filter_by(is_active=True).count()
        main = Wallet.query.filter_by(is_main=True, is_active=True).count()
        
        return {
            'total': total,
            'active': active,
            'inactive': total - active,
            'main_wallets': main
        }
    
    def set_main_wallet(self, wallet_id: int) -> bool:
        """设置主钱包"""
        # 清除所有主钱包标记
        Wallet.query.filter_by(is_main=True).update({'is_main': False})
        
        # 设置新的主钱包
        wallet = Wallet.query.get(wallet_id)
        if not wallet:
            return False
        
        wallet.is_main = True
        db.session.commit()
        
        logger.info(f"设置主钱包: {wallet.public_key}", "WalletService")
        return True
    
    def deactivate_wallet(self, wallet_id: int) -> bool:
        """停用钱包"""
        wallet = Wallet.query.get(wallet_id)
        if not wallet:
            return False
        
        wallet.is_active = False
        db.session.commit()
        
        logger.info(f"停用钱包: {wallet.public_key}", "WalletService")
        return True
    
    def activate_wallet(self, wallet_id: int) -> bool:
        """激活钱包"""
        wallet = Wallet.query.get(wallet_id)
        if not wallet:
            return False
        
        wallet.is_active = True
        db.session.commit()
        
        logger.info(f"激活钱包: {wallet.public_key}", "WalletService")
        return True
    
    def add_wallet_tags(self, wallet_id: int, new_tags: List[str]) -> bool:
        """添加钱包标签"""
        wallet = Wallet.query.get(wallet_id)
        if not wallet:
            return False
        
        current_tags = json.loads(wallet.tags) if wallet.tags else []
        updated_tags = list(set(current_tags + new_tags))
        
        wallet.tags = json.dumps(updated_tags)
        db.session.commit()
        
        logger.info(f"为钱包 {wallet.public_key} 添加标签: {new_tags}", "WalletService")
        return True
    
    def remove_wallet_tags(self, wallet_id: int, tags_to_remove: List[str]) -> bool:
        """移除钱包标签"""
        wallet = Wallet.query.get(wallet_id)
        if not wallet:
            return False
        
        current_tags = json.loads(wallet.tags) if wallet.tags else []
        updated_tags = [tag for tag in current_tags if tag not in tags_to_remove]
        
        wallet.tags = json.dumps(updated_tags)
        db.session.commit()
        
        logger.info(f"为钱包 {wallet.public_key} 移除标签: {tags_to_remove}", "WalletService")
        return True
    
    def get_wallets_by_tags(self, tags: List[str], match_all: bool = False) -> List[Dict]:
        """根据标签获取钱包"""
        wallets = Wallet.query.filter_by(is_active=True).all()
        result = []
        
        for wallet in wallets:
            wallet_tags = json.loads(wallet.tags) if wallet.tags else []
            
            if match_all:
                # 必须包含所有标签
                if all(tag in wallet_tags for tag in tags):
                    result.append(self._wallet_to_dict(wallet))
            else:
                # 包含任意一个标签
                if any(tag in wallet_tags for tag in tags):
                    result.append(self._wallet_to_dict(wallet))
        
        return result
    
    def _wallet_to_dict(self, wallet: Wallet) -> Dict:
        """将钱包对象转换为字典"""
        return {
            'id': wallet.id,
            'public_key': wallet.public_key,
            'balance': wallet.balance,
            'is_main': wallet.is_main,
            'is_active': wallet.is_active,
            'tags': json.loads(wallet.tags) if wallet.tags else [],
            'created_at': wallet.created_at.isoformat(),
            'updated_at': wallet.updated_at.isoformat()
        }
    
    def export_wallets(self, wallet_ids: List[int] = None, include_private_keys: bool = False) -> Dict:
        """导出钱包数据"""
        if wallet_ids:
            wallets = Wallet.query.filter(Wallet.id.in_(wallet_ids)).all()
        else:
            wallets = Wallet.query.filter_by(is_active=True).all()
        
        exported_wallets = []
        
        for wallet in wallets:
            wallet_data = self._wallet_to_dict(wallet)
            
            if include_private_keys:
                try:
                    private_key = self._decrypt_private_key(wallet.private_key_encrypted)
                    wallet_data['private_key'] = private_key
                except Exception as e:
                    logger.error(f"导出钱包 {wallet.id} 私钥失败: {str(e)}", "WalletService")
                    wallet_data['private_key'] = None
            
            exported_wallets.append(wallet_data)
        
        return {
            'wallets': exported_wallets,
            'export_time': time.time(),
            'total_count': len(exported_wallets)
        }
    
    def import_wallets(self, wallet_data: List[Dict]) -> Dict:
        """导入钱包数据"""
        imported_count = 0
        failed_count = 0
        errors = []
        
        for wallet_info in wallet_data:
            try:
                # 检查是否已存在
                existing_wallet = Wallet.query.filter_by(
                    public_key=wallet_info['public_key']
                ).first()
                
                if existing_wallet:
                    logger.warning(f"钱包 {wallet_info['public_key']} 已存在，跳过", "WalletService")
                    continue
                
                # 加密私钥
                if 'private_key' in wallet_info:
                    encrypted_private_key = self._encrypt_private_key(wallet_info['private_key'])
                else:
                    # 如果没有私钥，生成新的
                    private_key_bytes = secrets.token_bytes(32)
                    private_key_array = list(private_key_bytes)
                    private_key_json = json.dumps(private_key_array)
                    encrypted_private_key = self._encrypt_private_key(private_key_json)
                
                # 创建钱包
                wallet = Wallet(
                    public_key=wallet_info['public_key'],
                    private_key_encrypted=encrypted_private_key,
                    balance=wallet_info.get('balance', 0.0),
                    is_main=wallet_info.get('is_main', False),
                    is_active=wallet_info.get('is_active', True),
                    tags=json.dumps(wallet_info.get('tags', []))
                )
                
                db.session.add(wallet)
                imported_count += 1
                
            except Exception as e:
                error_msg = f"导入钱包失败: {str(e)}"
                errors.append(error_msg)
                logger.error(error_msg, "WalletService")
                failed_count += 1
        
        db.session.commit()
        
        return {
            'imported_count': imported_count,
            'failed_count': failed_count,
            'errors': errors
        }

