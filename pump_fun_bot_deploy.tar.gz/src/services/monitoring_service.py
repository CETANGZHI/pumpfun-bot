import os
import json
import time
import psutil
import threading
import requests
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta
from src.models.user import db
from src.utils.logger import logger
from src.utils.solana_client import SolanaClient
import smtplib
from email.mime.text import MimeText
from email.mime.multipart import MimeMultipart

@dataclass
class SystemMetrics:
    """系统指标"""
    timestamp: int
    cpu_percent: float
    memory_percent: float
    disk_percent: float
    network_io: Dict[str, int]
    process_count: int
    load_average: List[float]

@dataclass
class BusinessMetrics:
    """业务指标"""
    timestamp: int
    total_wallets: int
    active_positions: int
    daily_trades: int
    daily_profit_loss: float
    success_rate: float
    avg_response_time: float
    error_count: int

@dataclass
class BlockchainMetrics:
    """区块链指标"""
    timestamp: int
    rpc_latency: float
    block_height: int
    gas_price: float
    network_status: str
    transaction_pool_size: int
    confirmed_transactions: int
    failed_transactions: int

@dataclass
class AlertRule:
    """告警规则"""
    id: str
    name: str
    metric_type: str  # system, business, blockchain
    metric_name: str
    operator: str  # >, <, >=, <=, ==, !=
    threshold: float
    duration: int  # 持续时间（秒）
    severity: str  # critical, warning, info
    enabled: bool
    channels: List[str]  # email, telegram, discord, webhook

class MonitoringService:
    """全面的系统监控服务"""
    
    def __init__(self):
        self.solana_client = SolanaClient()
        self.is_running = False
        self.monitoring_thread = None
        self.alert_thread = None
        
        # 数据存储
        self.system_metrics_history = []
        self.business_metrics_history = []
        self.blockchain_metrics_history = []
        self.alert_history = []
        
        # 告警规则
        self.alert_rules = {}
        self.alert_states = {}  # 跟踪告警状态
        
        # 配置
        self.config = {
            'collection_interval': 30,  # 数据收集间隔（秒）
            'retention_days': 30,  # 数据保留天数
            'alert_cooldown': 300,  # 告警冷却时间（秒）
            'max_history_size': 10000,  # 最大历史记录数
            'enable_auto_recovery': True,  # 启用自动恢复
            'health_check_interval': 60,  # 健康检查间隔
        }
        
        # 通知配置
        self.notification_config = {
            'email': {
                'smtp_server': os.getenv('SMTP_SERVER', 'smtp.gmail.com'),
                'smtp_port': int(os.getenv('SMTP_PORT', '587')),
                'username': os.getenv('EMAIL_USERNAME', ''),
                'password': os.getenv('EMAIL_PASSWORD', ''),
                'from_email': os.getenv('FROM_EMAIL', ''),
                'to_emails': os.getenv('TO_EMAILS', '').split(',')
            },
            'telegram': {
                'bot_token': os.getenv('TELEGRAM_BOT_TOKEN', ''),
                'chat_ids': os.getenv('TELEGRAM_CHAT_IDS', '').split(',')
            },
            'webhook': {
                'urls': os.getenv('WEBHOOK_URLS', '').split(',')
            }
        }
        
        # 初始化默认告警规则
        self._init_default_alert_rules()
    
    def start_monitoring(self):
        """启动监控服务"""
        if self.is_running:
            logger.warning("监控服务已在运行", "MonitoringService")
            return False
        
        self.is_running = True
        
        # 启动数据收集线程
        self.monitoring_thread = threading.Thread(target=self._monitoring_loop, daemon=True)
        self.monitoring_thread.start()
        
        # 启动告警检查线程
        self.alert_thread = threading.Thread(target=self._alert_loop, daemon=True)
        self.alert_thread.start()
        
        logger.info("监控服务已启动", "MonitoringService")
        return True
    
    def stop_monitoring(self):
        """停止监控服务"""
        self.is_running = False
        if self.monitoring_thread:
            self.monitoring_thread.join(timeout=5)
        if self.alert_thread:
            self.alert_thread.join(timeout=5)
        
        logger.info("监控服务已停止", "MonitoringService")
    
    def _monitoring_loop(self):
        """监控主循环"""
        logger.info("启动监控数据收集", "MonitoringService")
        
        while self.is_running:
            try:
                # 收集系统指标
                system_metrics = self._collect_system_metrics()
                self.system_metrics_history.append(system_metrics)
                
                # 收集业务指标
                business_metrics = self._collect_business_metrics()
                self.business_metrics_history.append(business_metrics)
                
                # 收集区块链指标
                blockchain_metrics = self._collect_blockchain_metrics()
                self.blockchain_metrics_history.append(blockchain_metrics)
                
                # 清理历史数据
                self._cleanup_history()
                
                # 执行健康检查
                self._perform_health_checks()
                
                time.sleep(self.config['collection_interval'])
                
            except Exception as e:
                logger.error(f"监控数据收集异常: {str(e)}", "MonitoringService", exc_info=True)
                time.sleep(60)
    
    def _alert_loop(self):
        """告警检查循环"""
        logger.info("启动告警检查", "MonitoringService")
        
        while self.is_running:
            try:
                # 检查所有告警规则
                for rule_id, rule in self.alert_rules.items():
                    if rule.enabled:
                        self._check_alert_rule(rule)
                
                time.sleep(10)  # 每10秒检查一次告警
                
            except Exception as e:
                logger.error(f"告警检查异常: {str(e)}", "MonitoringService", exc_info=True)
                time.sleep(30)
    
    def _collect_system_metrics(self) -> SystemMetrics:
        """收集系统指标"""
        try:
            # CPU使用率
            cpu_percent = psutil.cpu_percent(interval=1)
            
            # 内存使用率
            memory = psutil.virtual_memory()
            memory_percent = memory.percent
            
            # 磁盘使用率
            disk = psutil.disk_usage('/')
            disk_percent = disk.percent
            
            # 网络IO
            network_io = psutil.net_io_counters()._asdict()
            
            # 进程数量
            process_count = len(psutil.pids())
            
            # 系统负载
            load_average = list(psutil.getloadavg()) if hasattr(psutil, 'getloadavg') else [0, 0, 0]
            
            return SystemMetrics(
                timestamp=int(time.time()),
                cpu_percent=cpu_percent,
                memory_percent=memory_percent,
                disk_percent=disk_percent,
                network_io=network_io,
                process_count=process_count,
                load_average=load_average
            )
            
        except Exception as e:
            logger.error(f"收集系统指标失败: {str(e)}", "MonitoringService")
            return SystemMetrics(
                timestamp=int(time.time()),
                cpu_percent=0, memory_percent=0, disk_percent=0,
                network_io={}, process_count=0, load_average=[0, 0, 0]
            )
    
    def _collect_business_metrics(self) -> BusinessMetrics:
        """收集业务指标"""
        try:
            # 获取钱包数量
            from src.services.wallet_service import WalletService
            wallet_service = WalletService()
            total_wallets = len(wallet_service.get_all_wallets())
            
            # 获取活跃持仓
            from src.services.sniper_service import SniperService
            sniper_service = SniperService()
            active_positions = len(sniper_service.get_active_positions())
            
            # 获取今日交易统计
            daily_stats = self._get_daily_trading_stats()
            
            # 计算成功率
            success_rate = self._calculate_success_rate()
            
            # 计算平均响应时间
            avg_response_time = self._calculate_avg_response_time()
            
            # 获取错误计数
            error_count = self._get_error_count()
            
            return BusinessMetrics(
                timestamp=int(time.time()),
                total_wallets=total_wallets,
                active_positions=active_positions,
                daily_trades=daily_stats.get('trades', 0),
                daily_profit_loss=daily_stats.get('profit_loss', 0.0),
                success_rate=success_rate,
                avg_response_time=avg_response_time,
                error_count=error_count
            )
            
        except Exception as e:
            logger.error(f"收集业务指标失败: {str(e)}", "MonitoringService")
            return BusinessMetrics(
                timestamp=int(time.time()),
                total_wallets=0, active_positions=0, daily_trades=0,
                daily_profit_loss=0.0, success_rate=0.0,
                avg_response_time=0.0, error_count=0
            )
    
    def _collect_blockchain_metrics(self) -> BlockchainMetrics:
        """收集区块链指标"""
        try:
            # 测试RPC延迟
            start_time = time.time()
            try:
                block_height = self.solana_client.get_slot()
                rpc_latency = (time.time() - start_time) * 1000  # 毫秒
                network_status = "healthy"
            except Exception as e:
                rpc_latency = 9999
                block_height = 0
                network_status = f"error: {str(e)}"
            
            # 获取Gas价格（Solana中是优先费）
            try:
                recent_fees = self.solana_client.get_recent_prioritization_fees()
                gas_price = sum(fee['prioritization_fee'] for fee in recent_fees) / len(recent_fees) if recent_fees else 0
            except:
                gas_price = 0
            
            # 获取交易池大小（模拟）
            transaction_pool_size = self._estimate_transaction_pool_size()
            
            # 获取交易统计
            tx_stats = self._get_transaction_stats()
            
            return BlockchainMetrics(
                timestamp=int(time.time()),
                rpc_latency=rpc_latency,
                block_height=block_height,
                gas_price=gas_price,
                network_status=network_status,
                transaction_pool_size=transaction_pool_size,
                confirmed_transactions=tx_stats.get('confirmed', 0),
                failed_transactions=tx_stats.get('failed', 0)
            )
            
        except Exception as e:
            logger.error(f"收集区块链指标失败: {str(e)}", "MonitoringService")
            return BlockchainMetrics(
                timestamp=int(time.time()),
                rpc_latency=9999, block_height=0, gas_price=0,
                network_status="error", transaction_pool_size=0,
                confirmed_transactions=0, failed_transactions=0
            )
    
    def _check_alert_rule(self, rule: AlertRule):
        """检查告警规则"""
        try:
            # 获取当前指标值
            current_value = self._get_metric_value(rule.metric_type, rule.metric_name)
            if current_value is None:
                return
            
            # 检查条件
            condition_met = self._evaluate_condition(current_value, rule.operator, rule.threshold)
            
            # 获取告警状态
            alert_state = self.alert_states.get(rule.id, {
                'triggered': False,
                'trigger_time': 0,
                'last_alert_time': 0
            })
            
            current_time = int(time.time())
            
            if condition_met:
                if not alert_state['triggered']:
                    # 首次触发
                    alert_state['triggered'] = True
                    alert_state['trigger_time'] = current_time
                elif current_time - alert_state['trigger_time'] >= rule.duration:
                    # 持续时间满足，发送告警
                    if current_time - alert_state['last_alert_time'] >= self.config['alert_cooldown']:
                        self._send_alert(rule, current_value)
                        alert_state['last_alert_time'] = current_time
            else:
                # 条件不满足，重置状态
                if alert_state['triggered']:
                    alert_state['triggered'] = False
                    alert_state['trigger_time'] = 0
                    # 发送恢复通知
                    self._send_recovery_notification(rule, current_value)
            
            self.alert_states[rule.id] = alert_state
            
        except Exception as e:
            logger.error(f"检查告警规则失败 {rule.id}: {str(e)}", "MonitoringService")
    
    def _send_alert(self, rule: AlertRule, current_value: float):
        """发送告警"""
        try:
            alert_data = {
                'rule_id': rule.id,
                'rule_name': rule.name,
                'severity': rule.severity,
                'metric_type': rule.metric_type,
                'metric_name': rule.metric_name,
                'current_value': current_value,
                'threshold': rule.threshold,
                'operator': rule.operator,
                'timestamp': int(time.time()),
                'message': f"告警: {rule.name} - {rule.metric_name} {rule.operator} {rule.threshold}, 当前值: {current_value}"
            }
            
            # 记录告警历史
            self.alert_history.append(alert_data)
            
            # 发送到各个通道
            for channel in rule.channels:
                try:
                    if channel == 'email':
                        self._send_email_alert(alert_data)
                    elif channel == 'telegram':
                        self._send_telegram_alert(alert_data)
                    elif channel == 'webhook':
                        self._send_webhook_alert(alert_data)
                except Exception as e:
                    logger.error(f"发送告警到 {channel} 失败: {str(e)}", "MonitoringService")
            
            logger.warning(f"告警触发: {alert_data['message']}", "MonitoringService")
            
        except Exception as e:
            logger.error(f"发送告警失败: {str(e)}", "MonitoringService")
    
    def _send_email_alert(self, alert_data: Dict):
        """发送邮件告警"""
        config = self.notification_config['email']
        if not config['username'] or not config['to_emails']:
            return
        
        try:
            msg = MimeMultipart()
            msg['From'] = config['from_email'] or config['username']
            msg['To'] = ', '.join(config['to_emails'])
            msg['Subject'] = f"[{alert_data['severity'].upper()}] {alert_data['rule_name']}"
            
            body = f"""
            告警详情:
            
            规则名称: {alert_data['rule_name']}
            严重级别: {alert_data['severity']}
            指标类型: {alert_data['metric_type']}
            指标名称: {alert_data['metric_name']}
            当前值: {alert_data['current_value']}
            阈值: {alert_data['threshold']}
            条件: {alert_data['operator']}
            触发时间: {datetime.fromtimestamp(alert_data['timestamp']).strftime('%Y-%m-%d %H:%M:%S')}
            
            请及时处理！
            """
            
            msg.attach(MimeText(body, 'plain', 'utf-8'))
            
            server = smtplib.SMTP(config['smtp_server'], config['smtp_port'])
            server.starttls()
            server.login(config['username'], config['password'])
            server.send_message(msg)
            server.quit()
            
            logger.info("邮件告警发送成功", "MonitoringService")
            
        except Exception as e:
            logger.error(f"发送邮件告警失败: {str(e)}", "MonitoringService")
    
    def _send_telegram_alert(self, alert_data: Dict):
        """发送Telegram告警"""
        config = self.notification_config['telegram']
        if not config['bot_token'] or not config['chat_ids']:
            return
        
        try:
            message = f"""
🚨 *{alert_data['severity'].upper()} 告警*

📋 规则: {alert_data['rule_name']}
📊 指标: {alert_data['metric_name']}
📈 当前值: {alert_data['current_value']}
⚠️ 阈值: {alert_data['operator']} {alert_data['threshold']}
🕐 时间: {datetime.fromtimestamp(alert_data['timestamp']).strftime('%H:%M:%S')}

请及时处理！
            """
            
            for chat_id in config['chat_ids']:
                if chat_id.strip():
                    url = f"https://api.telegram.org/bot{config['bot_token']}/sendMessage"
                    data = {
                        'chat_id': chat_id.strip(),
                        'text': message,
                        'parse_mode': 'Markdown'
                    }
                    response = requests.post(url, data=data, timeout=10)
                    if response.status_code == 200:
                        logger.info(f"Telegram告警发送成功: {chat_id}", "MonitoringService")
                    else:
                        logger.error(f"Telegram告警发送失败: {response.text}", "MonitoringService")
            
        except Exception as e:
            logger.error(f"发送Telegram告警失败: {str(e)}", "MonitoringService")
    
    def _send_webhook_alert(self, alert_data: Dict):
        """发送Webhook告警"""
        config = self.notification_config['webhook']
        if not config['urls']:
            return
        
        try:
            for url in config['urls']:
                if url.strip():
                    response = requests.post(
                        url.strip(),
                        json=alert_data,
                        timeout=10,
                        headers={'Content-Type': 'application/json'}
                    )
                    if response.status_code == 200:
                        logger.info(f"Webhook告警发送成功: {url}", "MonitoringService")
                    else:
                        logger.error(f"Webhook告警发送失败: {response.text}", "MonitoringService")
            
        except Exception as e:
            logger.error(f"发送Webhook告警失败: {str(e)}", "MonitoringService")
    
    def _perform_health_checks(self):
        """执行健康检查"""
        try:
            health_status = {
                'timestamp': int(time.time()),
                'overall_status': 'healthy',
                'services': {}
            }
            
            # 检查数据库连接
            try:
                db.session.execute('SELECT 1')
                health_status['services']['database'] = 'healthy'
            except Exception as e:
                health_status['services']['database'] = f'error: {str(e)}'
                health_status['overall_status'] = 'unhealthy'
            
            # 检查Solana RPC连接
            try:
                self.solana_client.get_slot()
                health_status['services']['solana_rpc'] = 'healthy'
            except Exception as e:
                health_status['services']['solana_rpc'] = f'error: {str(e)}'
                health_status['overall_status'] = 'degraded'
            
            # 检查关键服务
            services_to_check = ['wallet_service', 'sniper_service', 'promotion_service']
            for service_name in services_to_check:
                try:
                    # 这里可以添加具体的服务健康检查逻辑
                    health_status['services'][service_name] = 'healthy'
                except Exception as e:
                    health_status['services'][service_name] = f'error: {str(e)}'
                    health_status['overall_status'] = 'degraded'
            
            # 如果启用自动恢复，尝试修复问题
            if self.config['enable_auto_recovery'] and health_status['overall_status'] != 'healthy':
                self._attempt_auto_recovery(health_status)
            
            logger.debug(f"健康检查完成: {health_status['overall_status']}", "MonitoringService")
            
        except Exception as e:
            logger.error(f"健康检查失败: {str(e)}", "MonitoringService")
    
    def get_monitoring_dashboard(self) -> Dict:
        """获取监控仪表板数据"""
        try:
            # 获取最新指标
            latest_system = self.system_metrics_history[-1] if self.system_metrics_history else None
            latest_business = self.business_metrics_history[-1] if self.business_metrics_history else None
            latest_blockchain = self.blockchain_metrics_history[-1] if self.blockchain_metrics_history else None
            
            # 计算趋势
            system_trend = self._calculate_trend(self.system_metrics_history, 'cpu_percent')
            business_trend = self._calculate_trend(self.business_metrics_history, 'daily_profit_loss')
            
            # 获取活跃告警
            active_alerts = [alert for alert in self.alert_history[-10:] if alert['timestamp'] > time.time() - 3600]
            
            return {
                'status': 'running' if self.is_running else 'stopped',
                'last_update': int(time.time()),
                'system_metrics': asdict(latest_system) if latest_system else {},
                'business_metrics': asdict(latest_business) if latest_business else {},
                'blockchain_metrics': asdict(latest_blockchain) if latest_blockchain else {},
                'trends': {
                    'system_cpu': system_trend,
                    'business_profit': business_trend
                },
                'active_alerts': active_alerts,
                'alert_rules_count': len(self.alert_rules),
                'data_points': {
                    'system': len(self.system_metrics_history),
                    'business': len(self.business_metrics_history),
                    'blockchain': len(self.blockchain_metrics_history)
                }
            }
            
        except Exception as e:
            logger.error(f"获取监控仪表板失败: {str(e)}", "MonitoringService")
            return {'error': str(e)}
    
    def get_metrics_history(self, metric_type: str, hours: int = 24) -> List[Dict]:
        """获取指标历史数据"""
        try:
            cutoff_time = int(time.time()) - (hours * 3600)
            
            if metric_type == 'system':
                history = self.system_metrics_history
            elif metric_type == 'business':
                history = self.business_metrics_history
            elif metric_type == 'blockchain':
                history = self.blockchain_metrics_history
            else:
                return []
            
            # 过滤时间范围
            filtered_history = [
                asdict(metric) for metric in history 
                if metric.timestamp >= cutoff_time
            ]
            
            return filtered_history
            
        except Exception as e:
            logger.error(f"获取指标历史失败: {str(e)}", "MonitoringService")
            return []
    
    def add_alert_rule(self, rule_data: Dict) -> str:
        """添加告警规则"""
        try:
            rule = AlertRule(
                id=rule_data.get('id', f"rule_{int(time.time())}"),
                name=rule_data['name'],
                metric_type=rule_data['metric_type'],
                metric_name=rule_data['metric_name'],
                operator=rule_data['operator'],
                threshold=float(rule_data['threshold']),
                duration=int(rule_data.get('duration', 60)),
                severity=rule_data.get('severity', 'warning'),
                enabled=rule_data.get('enabled', True),
                channels=rule_data.get('channels', ['email'])
            )
            
            self.alert_rules[rule.id] = rule
            logger.info(f"添加告警规则: {rule.name}", "MonitoringService")
            return rule.id
            
        except Exception as e:
            logger.error(f"添加告警规则失败: {str(e)}", "MonitoringService")
            return ""
    
    def update_alert_rule(self, rule_id: str, updates: Dict) -> bool:
        """更新告警规则"""
        try:
            if rule_id not in self.alert_rules:
                return False
            
            rule = self.alert_rules[rule_id]
            for key, value in updates.items():
                if hasattr(rule, key):
                    setattr(rule, key, value)
            
            logger.info(f"更新告警规则: {rule_id}", "MonitoringService")
            return True
            
        except Exception as e:
            logger.error(f"更新告警规则失败: {str(e)}", "MonitoringService")
            return False
    
    def delete_alert_rule(self, rule_id: str) -> bool:
        """删除告警规则"""
        try:
            if rule_id in self.alert_rules:
                del self.alert_rules[rule_id]
                if rule_id in self.alert_states:
                    del self.alert_states[rule_id]
                logger.info(f"删除告警规则: {rule_id}", "MonitoringService")
                return True
            return False
            
        except Exception as e:
            logger.error(f"删除告警规则失败: {str(e)}", "MonitoringService")
            return False
    
    def get_alert_rules(self) -> List[Dict]:
        """获取所有告警规则"""
        return [asdict(rule) for rule in self.alert_rules.values()]
    
    def get_alert_history(self, hours: int = 24) -> List[Dict]:
        """获取告警历史"""
        cutoff_time = int(time.time()) - (hours * 3600)
        return [alert for alert in self.alert_history if alert['timestamp'] >= cutoff_time]
    
    # 辅助方法
    def _init_default_alert_rules(self):
        """初始化默认告警规则"""
        default_rules = [
            {
                'id': 'cpu_high',
                'name': 'CPU使用率过高',
                'metric_type': 'system',
                'metric_name': 'cpu_percent',
                'operator': '>',
                'threshold': 80.0,
                'duration': 300,
                'severity': 'warning',
                'channels': ['email', 'telegram']
            },
            {
                'id': 'memory_high',
                'name': '内存使用率过高',
                'metric_type': 'system',
                'metric_name': 'memory_percent',
                'operator': '>',
                'threshold': 85.0,
                'duration': 300,
                'severity': 'warning',
                'channels': ['email', 'telegram']
            },
            {
                'id': 'disk_high',
                'name': '磁盘使用率过高',
                'metric_type': 'system',
                'metric_name': 'disk_percent',
                'operator': '>',
                'threshold': 90.0,
                'duration': 600,
                'severity': 'critical',
                'channels': ['email', 'telegram']
            },
            {
                'id': 'rpc_latency_high',
                'name': 'RPC延迟过高',
                'metric_type': 'blockchain',
                'metric_name': 'rpc_latency',
                'operator': '>',
                'threshold': 5000.0,
                'duration': 180,
                'severity': 'warning',
                'channels': ['telegram']
            },
            {
                'id': 'daily_loss_high',
                'name': '日亏损过大',
                'metric_type': 'business',
                'metric_name': 'daily_profit_loss',
                'operator': '<',
                'threshold': -1.0,
                'duration': 60,
                'severity': 'critical',
                'channels': ['email', 'telegram']
            }
        ]
        
        for rule_data in default_rules:
            rule = AlertRule(**rule_data, enabled=True)
            self.alert_rules[rule.id] = rule
    
    def _cleanup_history(self):
        """清理历史数据"""
        max_size = self.config['max_history_size']
        
        if len(self.system_metrics_history) > max_size:
            self.system_metrics_history = self.system_metrics_history[-max_size:]
        
        if len(self.business_metrics_history) > max_size:
            self.business_metrics_history = self.business_metrics_history[-max_size:]
        
        if len(self.blockchain_metrics_history) > max_size:
            self.blockchain_metrics_history = self.blockchain_metrics_history[-max_size:]
        
        if len(self.alert_history) > max_size:
            self.alert_history = self.alert_history[-max_size:]
    
    def _get_metric_value(self, metric_type: str, metric_name: str) -> Optional[float]:
        """获取指标值"""
        try:
            if metric_type == 'system' and self.system_metrics_history:
                latest = self.system_metrics_history[-1]
                return getattr(latest, metric_name, None)
            elif metric_type == 'business' and self.business_metrics_history:
                latest = self.business_metrics_history[-1]
                return getattr(latest, metric_name, None)
            elif metric_type == 'blockchain' and self.blockchain_metrics_history:
                latest = self.blockchain_metrics_history[-1]
                return getattr(latest, metric_name, None)
            return None
        except:
            return None
    
    def _evaluate_condition(self, value: float, operator: str, threshold: float) -> bool:
        """评估条件"""
        if operator == '>':
            return value > threshold
        elif operator == '<':
            return value < threshold
        elif operator == '>=':
            return value >= threshold
        elif operator == '<=':
            return value <= threshold
        elif operator == '==':
            return value == threshold
        elif operator == '!=':
            return value != threshold
        return False
    
    def _send_recovery_notification(self, rule: AlertRule, current_value: float):
        """发送恢复通知"""
        recovery_data = {
            'rule_name': rule.name,
            'metric_name': rule.metric_name,
            'current_value': current_value,
            'threshold': rule.threshold,
            'timestamp': int(time.time()),
            'message': f"恢复: {rule.name} - {rule.metric_name} 已恢复正常，当前值: {current_value}"
        }
        
        logger.info(f"告警恢复: {recovery_data['message']}", "MonitoringService")
    
    def _get_daily_trading_stats(self) -> Dict:
        """获取今日交易统计"""
        # 这里应该从数据库查询实际数据
        return {'trades': 10, 'profit_loss': 0.5}
    
    def _calculate_success_rate(self) -> float:
        """计算成功率"""
        # 这里应该计算实际成功率
        return 0.75
    
    def _calculate_avg_response_time(self) -> float:
        """计算平均响应时间"""
        # 这里应该计算实际响应时间
        return 150.0
    
    def _get_error_count(self) -> int:
        """获取错误计数"""
        # 这里应该从日志系统获取错误计数
        return 2
    
    def _estimate_transaction_pool_size(self) -> int:
        """估算交易池大小"""
        # Solana没有传统的mempool，这里返回模拟值
        return 1000
    
    def _get_transaction_stats(self) -> Dict:
        """获取交易统计"""
        # 这里应该查询实际交易统计
        return {'confirmed': 50, 'failed': 2}
    
    def _calculate_trend(self, history: List, field: str) -> str:
        """计算趋势"""
        if len(history) < 2:
            return 'stable'
        
        try:
            recent_values = [getattr(item, field) for item in history[-10:]]
            if len(recent_values) < 2:
                return 'stable'
            
            first_half = sum(recent_values[:len(recent_values)//2]) / (len(recent_values)//2)
            second_half = sum(recent_values[len(recent_values)//2:]) / (len(recent_values) - len(recent_values)//2)
            
            change_percent = (second_half - first_half) / first_half if first_half != 0 else 0
            
            if change_percent > 0.1:
                return 'increasing'
            elif change_percent < -0.1:
                return 'decreasing'
            else:
                return 'stable'
        except:
            return 'stable'
    
    def _attempt_auto_recovery(self, health_status: Dict):
        """尝试自动恢复"""
        try:
            for service, status in health_status['services'].items():
                if 'error' in status:
                    logger.info(f"尝试自动恢复服务: {service}", "MonitoringService")
                    # 这里可以添加具体的恢复逻辑
                    # 例如重启服务、重新连接等
        except Exception as e:
            logger.error(f"自动恢复失败: {str(e)}", "MonitoringService")

