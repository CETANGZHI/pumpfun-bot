import json
import time
import asyncio
import threading
from typing import Dict, List, Optional, Callable, Any
from dataclasses import dataclass
from datetime import datetime, timedelta
from src.models.user import db, Token, Transaction, Wallet
from src.services.ai_service import AIService
from src.services.blockchain_service import BlockchainService
from src.services.data_analysis_service import DataAnalysisService
from src.utils.logger import logger
from src.utils.solana_client import SolanaClient
import numpy as np

@dataclass
class SniperConfig:
    """狙击配置"""
    # 基础筛选条件
    min_liquidity: float = 1.0  # 最小流动性 (SOL)
    max_liquidity: float = 100.0  # 最大流动性 (SOL)
    min_market_cap: float = 1000.0  # 最小市值 (USD)
    max_market_cap: float = 50000.0  # 最大市值 (USD)
    min_holders: int = 5  # 最小持有者数量
    max_holders: int = 1000  # 最大持有者数量
    
    # 交易相关
    buy_amount: float = 0.01  # 购买金额 (SOL)
    max_slippage: float = 0.1  # 最大滑点 (10%)
    gas_priority: str = "medium"  # Gas优先级: low/medium/high
    
    # AI评分筛选
    min_ai_score: float = 6.0  # 最小AI评分 (1-10)
    enable_ai_filter: bool = True  # 启用AI筛选
    
    # 时间筛选
    snipe_window_start: int = 0  # 狙击时间窗口开始 (小时)
    snipe_window_end: int = 24  # 狙击时间窗口结束 (小时)
    
    # 风险控制
    max_daily_trades: int = 50  # 每日最大交易次数
    max_daily_loss: float = 1.0  # 每日最大亏损 (SOL)
    blacklist_creators: List[str] = None  # 创建者黑名单
    
    # 高级筛选
    require_verified_creator: bool = False  # 要求验证创建者
    min_social_score: float = 0.0  # 最小社交媒体评分
    max_dev_holding: float = 0.2  # 开发者最大持有比例
    require_locked_liquidity: bool = False  # 要求锁定流动性

@dataclass
class AutoTradeConfig:
    """自动交易配置"""
    # 止盈策略
    take_profit_enabled: bool = True
    take_profit_percentage: float = 0.5  # 50%止盈
    partial_take_profit: bool = True  # 分批止盈
    tp_levels: List[Dict] = None  # 多级止盈 [{"percentage": 0.3, "sell_ratio": 0.3}]
    
    # 止损策略
    stop_loss_enabled: bool = True
    stop_loss_percentage: float = 0.2  # 20%止损
    trailing_stop: bool = True  # 移动止损
    trailing_distance: float = 0.1  # 移动止损距离
    
    # 时间策略
    max_hold_time: int = 3600  # 最大持有时间 (秒)
    min_hold_time: int = 60  # 最小持有时间 (秒)
    
    # 市场条件
    sell_on_volume_drop: bool = True  # 交易量下降时卖出
    volume_drop_threshold: float = 0.5  # 交易量下降阈值
    sell_on_whale_dump: bool = True  # 巨鲸抛售时卖出
    whale_threshold: float = 0.05  # 巨鲸阈值 (5%供应量)

class SniperService:
    """智能狙击服务"""
    
    def __init__(self):
        self.ai_service = AIService()
        self.blockchain_service = BlockchainService()
        self.data_analysis_service = DataAnalysisService()
        self.solana_client = SolanaClient()
        
        self.is_running = False
        self.sniper_thread = None
        self.active_positions = {}  # 活跃持仓
        self.daily_stats = {"trades": 0, "profit_loss": 0.0}
        self.blacklisted_tokens = set()
        
        # 性能统计
        self.performance_stats = {
            "total_snipes": 0,
            "successful_snipes": 0,
            "total_profit": 0.0,
            "win_rate": 0.0,
            "avg_hold_time": 0.0
        }
        
    def start_sniping(self, config: SniperConfig, auto_trade_config: AutoTradeConfig):
        """启动狙击服务"""
        if self.is_running:
            logger.warning("狙击服务已在运行", "SniperService")
            return False
        
        self.sniper_config = config
        self.auto_trade_config = auto_trade_config
        self.is_running = True
        
        # 启动监听线程
        self.sniper_thread = threading.Thread(target=self._sniper_loop, daemon=True)
        self.sniper_thread.start()
        
        # 启动自动交易监控
        self.trade_monitor_thread = threading.Thread(target=self._trade_monitor_loop, daemon=True)
        self.trade_monitor_thread.start()
        
        logger.info("狙击服务已启动", "SniperService")
        return True
    
    def stop_sniping(self):
        """停止狙击服务"""
        self.is_running = False
        if self.sniper_thread:
            self.sniper_thread.join(timeout=5)
        
        logger.info("狙击服务已停止", "SniperService")
    
    def _sniper_loop(self):
        """狙击主循环"""
        logger.info("开始监听新代币创建事件", "SniperService")
        
        while self.is_running:
            try:
                # 检查时间窗口
                if not self._is_in_snipe_window():
                    time.sleep(60)  # 不在狙击时间窗口，等待1分钟
                    continue
                
                # 检查每日限制
                if not self._check_daily_limits():
                    time.sleep(300)  # 达到每日限制，等待5分钟
                    continue
                
                # 监听新代币
                new_tokens = self._listen_for_new_tokens()
                
                for token_data in new_tokens:
                    if self._should_snipe_token(token_data):
                        self._execute_snipe(token_data)
                
                time.sleep(1)  # 短暂休息避免过度消耗资源
                
            except Exception as e:
                logger.error(f"狙击循环异常: {str(e)}", "SniperService", exc_info=True)
                time.sleep(5)
    
    def _listen_for_new_tokens(self) -> List[Dict]:
        """监听新代币创建"""
        try:
            # 获取最新的pump.fun程序交易
            signatures = self.solana_client.get_signatures_for_address(
                "6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P",  # pump.fun程序ID
                limit=20
            )
            
            new_tokens = []
            
            for sig_info in signatures:
                try:
                    # 获取交易详情
                    tx_data = self.solana_client.get_transaction(sig_info['signature'])
                    if not tx_data:
                        continue
                    
                    # 解析交易，查找create指令
                    token_data = self._parse_create_transaction(tx_data)
                    if token_data:
                        # 检查是否已处理过
                        if not self._is_token_processed(token_data['mint_address']):
                            new_tokens.append(token_data)
                            self._mark_token_processed(token_data['mint_address'])
                
                except Exception as e:
                    logger.error(f"解析交易失败: {str(e)}", "SniperService")
                    continue
            
            return new_tokens
            
        except Exception as e:
            logger.error(f"监听新代币失败: {str(e)}", "SniperService")
            return []
    
    def _parse_create_transaction(self, tx_data: Dict) -> Optional[Dict]:
        """解析创建代币交易"""
        try:
            # 这里需要根据pump.fun的具体交易结构来解析
            # 简化实现，实际需要解析instruction data
            
            instructions = tx_data.get('transaction', {}).get('message', {}).get('instructions', [])
            
            for instruction in instructions:
                # 检查是否是pump.fun的create指令
                if self._is_create_instruction(instruction):
                    return self._extract_token_info(instruction, tx_data)
            
            return None
            
        except Exception as e:
            logger.error(f"解析创建交易失败: {str(e)}", "SniperService")
            return None
    
    def _is_create_instruction(self, instruction: Dict) -> bool:
        """检查是否是创建代币指令"""
        # 简化实现，实际需要检查instruction的program_id和data
        return True  # 占位符实现
    
    def _extract_token_info(self, instruction: Dict, tx_data: Dict) -> Dict:
        """提取代币信息"""
        # 简化实现，实际需要从instruction data中解析
        return {
            'mint_address': f"mock_mint_{int(time.time())}",
            'name': f"MockToken{int(time.time())}",
            'symbol': f"MOCK{int(time.time()) % 1000}",
            'creator': "mock_creator",
            'timestamp': int(time.time()),
            'signature': tx_data.get('signature', ''),
            'initial_liquidity': 1.0,
            'market_cap': 5000.0
        }
    
    def _should_snipe_token(self, token_data: Dict) -> bool:
        """判断是否应该狙击该代币"""
        try:
            logger.info(f"评估代币狙击条件: {token_data['symbol']}", "SniperService")
            
            # 基础筛选
            if not self._basic_filter(token_data):
                return False
            
            # 黑名单检查
            if self._is_blacklisted(token_data):
                return False
            
            # 获取详细数据
            detailed_data = self._get_detailed_token_data(token_data)
            
            # 高级筛选
            if not self._advanced_filter(detailed_data):
                return False
            
            # AI评分筛选
            if self.sniper_config.enable_ai_filter:
                ai_score = self._get_ai_score(detailed_data)
                if ai_score < self.sniper_config.min_ai_score:
                    logger.info(f"AI评分不足: {ai_score} < {self.sniper_config.min_ai_score}", "SniperService")
                    return False
            
            # 社交媒体筛选
            social_score = self._get_social_score(detailed_data)
            if social_score < self.sniper_config.min_social_score:
                logger.info(f"社交评分不足: {social_score}", "SniperService")
                return False
            
            logger.info(f"代币通过所有筛选条件: {token_data['symbol']}", "SniperService")
            return True
            
        except Exception as e:
            logger.error(f"评估狙击条件失败: {str(e)}", "SniperService")
            return False
    
    def _basic_filter(self, token_data: Dict) -> bool:
        """基础筛选"""
        config = self.sniper_config
        
        # 流动性检查
        liquidity = token_data.get('initial_liquidity', 0)
        if not (config.min_liquidity <= liquidity <= config.max_liquidity):
            logger.debug(f"流动性不符合条件: {liquidity}", "SniperService")
            return False
        
        # 市值检查
        market_cap = token_data.get('market_cap', 0)
        if not (config.min_market_cap <= market_cap <= config.max_market_cap):
            logger.debug(f"市值不符合条件: {market_cap}", "SniperService")
            return False
        
        return True
    
    def _advanced_filter(self, token_data: Dict) -> bool:
        """高级筛选"""
        config = self.sniper_config
        
        # 持有者数量检查
        holders = token_data.get('holders_count', 0)
        if not (config.min_holders <= holders <= config.max_holders):
            logger.debug(f"持有者数量不符合条件: {holders}", "SniperService")
            return False
        
        # 开发者持有比例检查
        dev_holding = token_data.get('dev_holding_percentage', 0)
        if dev_holding > config.max_dev_holding:
            logger.debug(f"开发者持有比例过高: {dev_holding}", "SniperService")
            return False
        
        # 流动性锁定检查
        if config.require_locked_liquidity:
            if not token_data.get('liquidity_locked', False):
                logger.debug("流动性未锁定", "SniperService")
                return False
        
        return True
    
    def _get_detailed_token_data(self, token_data: Dict) -> Dict:
        """获取详细代币数据"""
        try:
            # 获取链上数据
            mint_address = token_data['mint_address']
            
            # 获取持有者信息
            holders_data = self._get_holders_data(mint_address)
            
            # 获取交易历史
            trade_history = self._get_trade_history(mint_address)
            
            # 获取流动性信息
            liquidity_info = self._get_liquidity_info(mint_address)
            
            # 合并数据
            detailed_data = {
                **token_data,
                'holders_count': len(holders_data),
                'holders_data': holders_data,
                'trade_history': trade_history,
                'liquidity_info': liquidity_info,
                'dev_holding_percentage': self._calculate_dev_holding(holders_data, token_data['creator']),
                'liquidity_locked': liquidity_info.get('locked', False),
                'volume_24h': self._calculate_24h_volume(trade_history)
            }
            
            return detailed_data
            
        except Exception as e:
            logger.error(f"获取详细代币数据失败: {str(e)}", "SniperService")
            return token_data
    
    def _get_ai_score(self, token_data: Dict) -> float:
        """获取AI评分"""
        try:
            analysis = self.ai_service.analyze_token_potential(token_data)
            return analysis.get('total_score', 0) / 5.0  # 转换为1-10分制
        except Exception as e:
            logger.error(f"获取AI评分失败: {str(e)}", "SniperService")
            return 0.0
    
    def _get_social_score(self, token_data: Dict) -> float:
        """获取社交媒体评分"""
        try:
            # 这里可以集成Twitter、Telegram等API
            # 现在返回模拟评分
            name = token_data.get('name', '')
            symbol = token_data.get('symbol', '')
            
            # 简单的启发式评分
            score = 0.0
            
            # 名称长度评分
            if 3 <= len(name) <= 15:
                score += 2.0
            
            # 符号长度评分
            if 3 <= len(symbol) <= 6:
                score += 2.0
            
            # 描述质量评分
            description = token_data.get('description', '')
            if len(description) > 20:
                score += 2.0
            
            # 随机社交热度模拟
            import random
            score += random.uniform(0, 4.0)
            
            return min(score, 10.0)
            
        except Exception as e:
            logger.error(f"获取社交评分失败: {str(e)}", "SniperService")
            return 0.0
    
    def _execute_snipe(self, token_data: Dict):
        """执行狙击"""
        try:
            logger.info(f"开始狙击代币: {token_data['symbol']}", "SniperService")
            
            # 获取主钱包
            main_wallet = self._get_main_wallet()
            if not main_wallet:
                logger.error("未找到主钱包", "SniperService")
                return
            
            # 检查余额
            balance = self.solana_client.get_balance(main_wallet['public_key'])
            if balance < self.sniper_config.buy_amount:
                logger.error(f"余额不足: {balance} < {self.sniper_config.buy_amount}", "SniperService")
                return
            
            # 执行购买
            buy_result = self.blockchain_service.buy_token(
                mint_address=token_data['mint_address'],
                buyer_wallet=main_wallet,
                sol_amount=self.sniper_config.buy_amount,
                max_slippage=self.sniper_config.max_slippage,
                priority=self.sniper_config.gas_priority
            )
            
            if buy_result['success']:
                # 记录成功狙击
                position = {
                    'mint_address': token_data['mint_address'],
                    'symbol': token_data['symbol'],
                    'buy_price': buy_result.get('price', 0),
                    'buy_amount': self.sniper_config.buy_amount,
                    'token_amount': buy_result.get('token_amount', 0),
                    'buy_time': int(time.time()),
                    'signature': buy_result.get('transaction_signature'),
                    'status': 'holding'
                }
                
                self.active_positions[token_data['mint_address']] = position
                
                # 更新统计
                self.daily_stats['trades'] += 1
                self.performance_stats['total_snipes'] += 1
                self.performance_stats['successful_snipes'] += 1
                
                # 记录交易
                self._record_transaction(position, 'buy')
                
                logger.info(f"狙击成功: {token_data['symbol']} - {buy_result['transaction_signature']}", "SniperService")
                
            else:
                logger.error(f"狙击失败: {buy_result.get('error')}", "SniperService")
                
        except Exception as e:
            logger.error(f"执行狙击失败: {str(e)}", "SniperService", exc_info=True)
    
    def _trade_monitor_loop(self):
        """交易监控循环"""
        logger.info("启动自动交易监控", "SniperService")
        
        while self.is_running:
            try:
                # 检查所有活跃持仓
                for mint_address, position in list(self.active_positions.items()):
                    if self._should_sell_position(position):
                        self._execute_sell(position)
                
                time.sleep(5)  # 每5秒检查一次
                
            except Exception as e:
                logger.error(f"交易监控异常: {str(e)}", "SniperService", exc_info=True)
                time.sleep(10)
    
    def _should_sell_position(self, position: Dict) -> bool:
        """判断是否应该卖出持仓"""
        try:
            config = self.auto_trade_config
            mint_address = position['mint_address']
            
            # 获取当前价格
            current_price = self._get_current_price(mint_address)
            if current_price <= 0:
                return False
            
            buy_price = position['buy_price']
            price_change = (current_price - buy_price) / buy_price
            
            # 检查止盈条件
            if config.take_profit_enabled and price_change >= config.take_profit_percentage:
                logger.info(f"触发止盈: {position['symbol']} 涨幅 {price_change:.2%}", "SniperService")
                return True
            
            # 检查止损条件
            if config.stop_loss_enabled and price_change <= -config.stop_loss_percentage:
                logger.info(f"触发止损: {position['symbol']} 跌幅 {price_change:.2%}", "SniperService")
                return True
            
            # 检查持有时间
            hold_time = int(time.time()) - position['buy_time']
            if hold_time >= config.max_hold_time:
                logger.info(f"达到最大持有时间: {position['symbol']} 持有 {hold_time}秒", "SniperService")
                return True
            
            # 检查交易量下降
            if config.sell_on_volume_drop:
                volume_change = self._get_volume_change(mint_address)
                if volume_change <= -config.volume_drop_threshold:
                    logger.info(f"交易量大幅下降: {position['symbol']} 下降 {volume_change:.2%}", "SniperService")
                    return True
            
            # 检查巨鲸抛售
            if config.sell_on_whale_dump:
                if self._detect_whale_dump(mint_address):
                    logger.info(f"检测到巨鲸抛售: {position['symbol']}", "SniperService")
                    return True
            
            return False
            
        except Exception as e:
            logger.error(f"判断卖出条件失败: {str(e)}", "SniperService")
            return False
    
    def _execute_sell(self, position: Dict):
        """执行卖出"""
        try:
            logger.info(f"开始卖出持仓: {position['symbol']}", "SniperService")
            
            # 获取主钱包
            main_wallet = self._get_main_wallet()
            if not main_wallet:
                logger.error("未找到主钱包", "SniperService")
                return
            
            # 执行卖出
            sell_result = self.blockchain_service.sell_token(
                mint_address=position['mint_address'],
                seller_wallet=main_wallet,
                token_amount=position['token_amount']
            )
            
            if sell_result['success']:
                # 计算盈亏
                profit_loss = sell_result.get('sol_received', 0) - position['buy_amount']
                
                # 更新持仓状态
                position.update({
                    'sell_price': sell_result.get('price', 0),
                    'sell_amount': sell_result.get('sol_received', 0),
                    'sell_time': int(time.time()),
                    'profit_loss': profit_loss,
                    'status': 'sold',
                    'sell_signature': sell_result.get('transaction_signature')
                })
                
                # 更新统计
                self.daily_stats['profit_loss'] += profit_loss
                self.performance_stats['total_profit'] += profit_loss
                
                # 计算胜率
                if profit_loss > 0:
                    self.performance_stats['win_rate'] = (
                        self.performance_stats.get('wins', 0) + 1
                    ) / self.performance_stats['successful_snipes']
                    self.performance_stats['wins'] = self.performance_stats.get('wins', 0) + 1
                
                # 记录交易
                self._record_transaction(position, 'sell')
                
                # 从活跃持仓中移除
                del self.active_positions[position['mint_address']]
                
                logger.info(f"卖出成功: {position['symbol']} 盈亏: {profit_loss:.4f} SOL", "SniperService")
                
            else:
                logger.error(f"卖出失败: {sell_result.get('error')}", "SniperService")
                
        except Exception as e:
            logger.error(f"执行卖出失败: {str(e)}", "SniperService", exc_info=True)
    
    def get_sniper_status(self) -> Dict:
        """获取狙击服务状态"""
        return {
            'is_running': self.is_running,
            'active_positions': len(self.active_positions),
            'daily_stats': self.daily_stats,
            'performance_stats': self.performance_stats,
            'config': {
                'min_ai_score': getattr(self.sniper_config, 'min_ai_score', 0),
                'buy_amount': getattr(self.sniper_config, 'buy_amount', 0),
                'max_daily_trades': getattr(self.sniper_config, 'max_daily_trades', 0)
            }
        }
    
    def get_active_positions(self) -> List[Dict]:
        """获取活跃持仓"""
        positions = []
        for position in self.active_positions.values():
            # 添加当前价格和盈亏
            current_price = self._get_current_price(position['mint_address'])
            if current_price > 0:
                price_change = (current_price - position['buy_price']) / position['buy_price']
                unrealized_pnl = position['buy_amount'] * price_change
                
                position_info = {
                    **position,
                    'current_price': current_price,
                    'price_change': price_change,
                    'unrealized_pnl': unrealized_pnl,
                    'hold_time': int(time.time()) - position['buy_time']
                }
                positions.append(position_info)
        
        return positions
    
    def update_sniper_config(self, new_config: Dict) -> bool:
        """更新狙击配置"""
        try:
            # 验证配置
            if not self._validate_config(new_config):
                return False
            
            # 更新配置
            for key, value in new_config.items():
                if hasattr(self.sniper_config, key):
                    setattr(self.sniper_config, key, value)
            
            logger.info("狙击配置已更新", "SniperService")
            return True
            
        except Exception as e:
            logger.error(f"更新狙击配置失败: {str(e)}", "SniperService")
            return False
    
    def add_to_blacklist(self, identifier: str, reason: str = ""):
        """添加到黑名单"""
        self.blacklisted_tokens.add(identifier)
        logger.info(f"添加到黑名单: {identifier} - {reason}", "SniperService")
    
    def remove_from_blacklist(self, identifier: str):
        """从黑名单移除"""
        self.blacklisted_tokens.discard(identifier)
        logger.info(f"从黑名单移除: {identifier}", "SniperService")
    
    def get_performance_report(self) -> Dict:
        """获取性能报告"""
        try:
            # 计算详细统计
            total_trades = self.performance_stats['successful_snipes']
            if total_trades == 0:
                return {'message': '暂无交易数据'}
            
            # 获取历史交易数据
            transactions = self._get_historical_transactions()
            
            # 计算各种指标
            profits = [t['profit_loss'] for t in transactions if t.get('profit_loss', 0) > 0]
            losses = [abs(t['profit_loss']) for t in transactions if t.get('profit_loss', 0) < 0]
            
            report = {
                'total_trades': total_trades,
                'win_rate': self.performance_stats.get('win_rate', 0),
                'total_profit': self.performance_stats['total_profit'],
                'avg_profit': np.mean(profits) if profits else 0,
                'avg_loss': np.mean(losses) if losses else 0,
                'max_profit': max(profits) if profits else 0,
                'max_loss': max(losses) if losses else 0,
                'profit_factor': sum(profits) / sum(losses) if losses else float('inf'),
                'sharpe_ratio': self._calculate_sharpe_ratio(transactions),
                'max_drawdown': self._calculate_max_drawdown(transactions),
                'avg_hold_time': self._calculate_avg_hold_time(transactions)
            }
            
            return report
            
        except Exception as e:
            logger.error(f"生成性能报告失败: {str(e)}", "SniperService")
            return {'error': str(e)}
    
    # 辅助方法
    def _is_in_snipe_window(self) -> bool:
        """检查是否在狙击时间窗口内"""
        current_hour = datetime.now().hour
        start = self.sniper_config.snipe_window_start
        end = self.sniper_config.snipe_window_end
        
        if start <= end:
            return start <= current_hour < end
        else:  # 跨天的情况
            return current_hour >= start or current_hour < end
    
    def _check_daily_limits(self) -> bool:
        """检查每日限制"""
        # 检查交易次数限制
        if self.daily_stats['trades'] >= self.sniper_config.max_daily_trades:
            return False
        
        # 检查亏损限制
        if abs(self.daily_stats['profit_loss']) >= self.sniper_config.max_daily_loss:
            return False
        
        return True
    
    def _is_blacklisted(self, token_data: Dict) -> bool:
        """检查是否在黑名单中"""
        mint_address = token_data['mint_address']
        creator = token_data['creator']
        
        if mint_address in self.blacklisted_tokens:
            return True
        
        if creator in (self.sniper_config.blacklist_creators or []):
            return True
        
        return False
    
    def _is_token_processed(self, mint_address: str) -> bool:
        """检查代币是否已处理过"""
        # 这里可以使用缓存或数据库来跟踪已处理的代币
        return False  # 简化实现
    
    def _mark_token_processed(self, mint_address: str):
        """标记代币已处理"""
        # 这里可以将代币标记为已处理
        pass
    
    def _get_main_wallet(self) -> Optional[Dict]:
        """获取主钱包"""
        from src.services.wallet_service import WalletService
        wallet_service = WalletService()
        return wallet_service.get_main_wallet_info()
    
    def _get_current_price(self, mint_address: str) -> float:
        """获取当前价格"""
        # 这里应该调用实际的价格API
        import random
        return random.uniform(0.0001, 0.01)
    
    def _get_volume_change(self, mint_address: str) -> float:
        """获取交易量变化"""
        # 这里应该计算实际的交易量变化
        import random
        return random.uniform(-0.8, 0.5)
    
    def _detect_whale_dump(self, mint_address: str) -> bool:
        """检测巨鲸抛售"""
        # 这里应该分析大额交易
        import random
        return random.random() < 0.1  # 10%概率检测到巨鲸抛售
    
    def _record_transaction(self, position: Dict, tx_type: str):
        """记录交易"""
        try:
            transaction = Transaction(
                signature=position.get(f'{tx_type}_signature', ''),
                transaction_type=tx_type,
                wallet_address=self._get_main_wallet()['public_key'],
                token_mint=position['mint_address'],
                amount=position.get('token_amount', 0),
                sol_amount=position.get(f'{tx_type}_amount', 0),
                status='confirmed'
            )
            
            db.session.add(transaction)
            db.session.commit()
            
        except Exception as e:
            logger.error(f"记录交易失败: {str(e)}", "SniperService")
    
    def _validate_config(self, config: Dict) -> bool:
        """验证配置"""
        # 基本验证
        if config.get('buy_amount', 0) <= 0:
            return False
        
        if config.get('min_ai_score', 0) < 0 or config.get('min_ai_score', 0) > 10:
            return False
        
        return True
    
    def _get_historical_transactions(self) -> List[Dict]:
        """获取历史交易数据"""
        # 这里应该从数据库获取历史交易
        return []
    
    def _calculate_sharpe_ratio(self, transactions: List[Dict]) -> float:
        """计算夏普比率"""
        if not transactions:
            return 0.0
        
        returns = [t.get('profit_loss', 0) for t in transactions]
        if not returns:
            return 0.0
        
        mean_return = np.mean(returns)
        std_return = np.std(returns)
        
        return mean_return / std_return if std_return > 0 else 0.0
    
    def _calculate_max_drawdown(self, transactions: List[Dict]) -> float:
        """计算最大回撤"""
        if not transactions:
            return 0.0
        
        cumulative = np.cumsum([t.get('profit_loss', 0) for t in transactions])
        running_max = np.maximum.accumulate(cumulative)
        drawdown = (cumulative - running_max) / running_max
        
        return abs(np.min(drawdown)) if len(drawdown) > 0 else 0.0
    
    def _calculate_avg_hold_time(self, transactions: List[Dict]) -> float:
        """计算平均持有时间"""
        hold_times = []
        for t in transactions:
            if t.get('buy_time') and t.get('sell_time'):
                hold_times.append(t['sell_time'] - t['buy_time'])
        
        return np.mean(hold_times) if hold_times else 0.0
    
    def _get_holders_data(self, mint_address: str) -> List[Dict]:
        """获取持有者数据"""
        # 模拟实现
        return [{'address': f'holder_{i}', 'amount': 1000} for i in range(10)]
    
    def _get_trade_history(self, mint_address: str) -> List[Dict]:
        """获取交易历史"""
        # 模拟实现
        return [{'timestamp': int(time.time()), 'amount': 100, 'price': 0.001}]
    
    def _get_liquidity_info(self, mint_address: str) -> Dict:
        """获取流动性信息"""
        # 模拟实现
        return {'total': 10.0, 'locked': False, 'lock_time': 0}
    
    def _calculate_dev_holding(self, holders_data: List[Dict], creator: str) -> float:
        """计算开发者持有比例"""
        # 模拟实现
        return 0.1  # 10%
    
    def _calculate_24h_volume(self, trade_history: List[Dict]) -> float:
        """计算24小时交易量"""
        # 模拟实现
        return 1000.0

