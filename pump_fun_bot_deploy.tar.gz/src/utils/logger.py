import logging
import os
import sys
from datetime import datetime
from typing import Optional

class ColoredFormatter(logging.Formatter):
    """彩色日志格式化器"""
    
    # ANSI颜色代码
    COLORS = {
        'DEBUG': '\033[36m',    # 青色
        'INFO': '\033[32m',     # 绿色
        'WARNING': '\033[33m',  # 黄色
        'ERROR': '\033[31m',    # 红色
        'CRITICAL': '\033[35m', # 紫色
        'RESET': '\033[0m'      # 重置
    }
    
    def format(self, record):
        # 添加颜色
        color = self.COLORS.get(record.levelname, self.COLORS['RESET'])
        reset = self.COLORS['RESET']
        
        # 格式化时间
        record.asctime = datetime.fromtimestamp(record.created).strftime('%Y-%m-%d %H:%M:%S')
        
        # 添加模块信息
        if hasattr(record, 'module'):
            module_info = f"[{record.module}]"
        else:
            module_info = f"[{record.name}]"
        
        # 构建日志消息
        log_message = f"{color}[{record.levelname}]{reset} {record.asctime} {module_info} {record.getMessage()}"
        
        # 添加异常信息
        if record.exc_info:
            log_message += f"\n{self.formatException(record.exc_info)}"
        
        return log_message

class Logger:
    """增强的日志管理器"""
    
    def __init__(self):
        self.logger = logging.getLogger('PumpFunBot')
        self.logger.setLevel(logging.DEBUG)
        
        # 避免重复添加处理器
        if not self.logger.handlers:
            self._setup_handlers()
    
    def _setup_handlers(self):
        """设置日志处理器"""
        
        # 控制台处理器
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(logging.INFO)
        console_formatter = ColoredFormatter()
        console_handler.setFormatter(console_formatter)
        self.logger.addHandler(console_handler)
        
        # 文件处理器
        log_dir = os.path.join(os.path.dirname(__file__), '..', 'logs')
        os.makedirs(log_dir, exist_ok=True)
        
        # 主日志文件
        file_handler = logging.FileHandler(
            os.path.join(log_dir, 'pumpfun_bot.log'),
            encoding='utf-8'
        )
        file_handler.setLevel(logging.DEBUG)
        file_formatter = logging.Formatter(
            '%(asctime)s [%(levelname)s] [%(name)s] %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        file_handler.setFormatter(file_formatter)
        self.logger.addHandler(file_handler)
        
        # 错误日志文件
        error_handler = logging.FileHandler(
            os.path.join(log_dir, 'errors.log'),
            encoding='utf-8'
        )
        error_handler.setLevel(logging.ERROR)
        error_handler.setFormatter(file_formatter)
        self.logger.addHandler(error_handler)
        
        # 交易日志文件
        transaction_handler = logging.FileHandler(
            os.path.join(log_dir, 'transactions.log'),
            encoding='utf-8'
        )
        transaction_handler.setLevel(logging.INFO)
        transaction_handler.setFormatter(file_formatter)
        self.transaction_logger = logging.getLogger('PumpFunBot.Transactions')
        self.transaction_logger.addHandler(transaction_handler)
        self.transaction_logger.setLevel(logging.INFO)
    
    def debug(self, message: str, module: Optional[str] = None):
        """调试日志"""
        extra = {'module': module} if module else {}
        self.logger.debug(message, extra=extra)
    
    def info(self, message: str, module: Optional[str] = None):
        """信息日志"""
        extra = {'module': module} if module else {}
        self.logger.info(message, extra=extra)
    
    def warning(self, message: str, module: Optional[str] = None):
        """警告日志"""
        extra = {'module': module} if module else {}
        self.logger.warning(message, extra=extra)
    
    def error(self, message: str, module: Optional[str] = None, exc_info: bool = False):
        """错误日志"""
        extra = {'module': module} if module else {}
        self.logger.error(message, extra=extra, exc_info=exc_info)
    
    def critical(self, message: str, module: Optional[str] = None, exc_info: bool = False):
        """严重错误日志"""
        extra = {'module': module} if module else {}
        self.logger.critical(message, extra=extra, exc_info=exc_info)
    
    def transaction(self, message: str, signature: Optional[str] = None, 
                   transaction_type: Optional[str] = None, amount: Optional[float] = None):
        """交易日志"""
        log_message = message
        if signature:
            log_message += f" | 签名: {signature}"
        if transaction_type:
            log_message += f" | 类型: {transaction_type}"
        if amount is not None:
            log_message += f" | 金额: {amount}"
        
        self.transaction_logger.info(log_message)
    
    def set_level(self, level: str):
        """设置日志级别"""
        level_map = {
            'DEBUG': logging.DEBUG,
            'INFO': logging.INFO,
            'WARNING': logging.WARNING,
            'ERROR': logging.ERROR,
            'CRITICAL': logging.CRITICAL
        }
        
        if level.upper() in level_map:
            self.logger.setLevel(level_map[level.upper()])
            for handler in self.logger.handlers:
                if isinstance(handler, logging.StreamHandler) and handler.stream == sys.stdout:
                    handler.setLevel(level_map[level.upper()])
    
    def get_log_files(self) -> dict:
        """获取日志文件路径"""
        log_dir = os.path.join(os.path.dirname(__file__), '..', 'logs')
        return {
            'main_log': os.path.join(log_dir, 'pumpfun_bot.log'),
            'error_log': os.path.join(log_dir, 'errors.log'),
            'transaction_log': os.path.join(log_dir, 'transactions.log')
        }
    
    def clear_logs(self):
        """清空日志文件"""
        log_files = self.get_log_files()
        for log_file in log_files.values():
            if os.path.exists(log_file):
                open(log_file, 'w').close()
        self.info("日志文件已清空", "Logger")
    
    def get_recent_logs(self, log_type: str = 'main', lines: int = 100) -> list:
        """获取最近的日志"""
        log_files = self.get_log_files()
        
        if log_type == 'main':
            log_file = log_files['main_log']
        elif log_type == 'error':
            log_file = log_files['error_log']
        elif log_type == 'transaction':
            log_file = log_files['transaction_log']
        else:
            return []
        
        if not os.path.exists(log_file):
            return []
        
        try:
            with open(log_file, 'r', encoding='utf-8') as f:
                all_lines = f.readlines()
                return all_lines[-lines:] if len(all_lines) > lines else all_lines
        except Exception as e:
            self.error(f"读取日志文件失败: {str(e)}", "Logger")
            return []

# 创建全局日志实例
logger = Logger()

# 便捷函数
def debug(message: str, module: str = None):
    logger.debug(message, module)

def info(message: str, module: str = None):
    logger.info(message, module)

def warning(message: str, module: str = None):
    logger.warning(message, module)

def error(message: str, module: str = None, exc_info: bool = False):
    logger.error(message, module, exc_info)

def critical(message: str, module: str = None, exc_info: bool = False):
    logger.critical(message, module, exc_info)

def transaction(message: str, signature: str = None, transaction_type: str = None, amount: float = None):
    logger.transaction(message, signature, transaction_type, amount)

