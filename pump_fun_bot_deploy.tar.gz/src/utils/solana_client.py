import json
import os
import time
import requests
from typing import List, Dict, Optional, Any
from src.utils.logger import logger

class SolanaClient:
    """Solana区块链客户端"""
    
    def __init__(self):
        self.rpc_urls = [
            os.getenv('RPC_URL', 'https://api.mainnet-beta.solana.com'),
            'https://solana-api.projectserum.com',
            'https://api.mainnet-beta.solana.com',
            'https://rpc.ankr.com/solana'
        ]
        self.current_rpc_index = 0
        self.request_timeout = 30
        
    def get_current_rpc_url(self) -> str:
        """获取当前RPC URL"""
        return self.rpc_urls[self.current_rpc_index]
    
    def switch_rpc(self) -> bool:
        """切换到下一个RPC节点"""
        if len(self.rpc_urls) > 1:
            self.current_rpc_index = (self.current_rpc_index + 1) % len(self.rpc_urls)
            logger.info(f"切换RPC节点到: {self.get_current_rpc_url()}", "SolanaClient")
            return True
        return False
    
    def make_rpc_request(self, method: str, params: List[Any] = None, max_retries: int = 3) -> Dict:
        """发送RPC请求"""
        params = params or []
        
        for attempt in range(max_retries):
            try:
                payload = {
                    "jsonrpc": "2.0",
                    "id": int(time.time() * 1000),
                    "method": method,
                    "params": params
                }
                
                response = requests.post(
                    self.get_current_rpc_url(),
                    json=payload,
                    timeout=self.request_timeout,
                    headers={'Content-Type': 'application/json'}
                )
                
                if response.status_code == 200:
                    result = response.json()
                    if 'error' in result:
                        raise Exception(f"RPC错误: {result['error']}")
                    return result.get('result', {})
                else:
                    raise Exception(f"HTTP错误: {response.status_code}")
                    
            except Exception as e:
                logger.warning(f"RPC请求失败 (尝试 {attempt + 1}/{max_retries}): {str(e)}", "SolanaClient")
                
                if attempt < max_retries - 1:
                    # 尝试切换RPC节点
                    if self.switch_rpc():
                        time.sleep(1)
                        continue
                    else:
                        time.sleep(2 ** attempt)  # 指数退避
                else:
                    raise Exception(f"所有RPC请求尝试失败: {str(e)}")
    
    def get_balance(self, public_key: str) -> float:
        """获取账户余额（SOL）"""
        try:
            result = self.make_rpc_request("getBalance", [public_key])
            lamports = result.get('value', 0)
            return lamports / 1_000_000_000  # 转换为SOL
        except Exception as e:
            logger.error(f"获取余额失败 {public_key}: {str(e)}", "SolanaClient")
            return 0.0
    
    def get_token_balance(self, public_key: str, mint_address: str) -> float:
        """获取代币余额"""
        try:
            result = self.make_rpc_request("getTokenAccountsByOwner", [
                public_key,
                {"mint": mint_address},
                {"encoding": "jsonParsed"}
            ])
            
            accounts = result.get('value', [])
            if not accounts:
                return 0.0
            
            # 获取第一个代币账户的余额
            account_info = accounts[0]['account']['data']['parsed']['info']
            token_amount = account_info['tokenAmount']
            return float(token_amount['uiAmount'] or 0)
            
        except Exception as e:
            logger.error(f"获取代币余额失败 {public_key} {mint_address}: {str(e)}", "SolanaClient")
            return 0.0
    
    def get_account_info(self, public_key: str) -> Optional[Dict]:
        """获取账户信息"""
        try:
            result = self.make_rpc_request("getAccountInfo", [
                public_key,
                {"encoding": "jsonParsed"}
            ])
            return result.get('value')
        except Exception as e:
            logger.error(f"获取账户信息失败 {public_key}: {str(e)}", "SolanaClient")
            return None
    
    def get_transaction(self, signature: str) -> Optional[Dict]:
        """获取交易信息"""
        try:
            result = self.make_rpc_request("getTransaction", [
                signature,
                {"encoding": "jsonParsed", "maxSupportedTransactionVersion": 0}
            ])
            return result
        except Exception as e:
            logger.error(f"获取交易信息失败 {signature}: {str(e)}", "SolanaClient")
            return None
    
    def get_latest_blockhash(self) -> Optional[str]:
        """获取最新区块哈希"""
        try:
            result = self.make_rpc_request("getLatestBlockhash")
            return result.get('value', {}).get('blockhash')
        except Exception as e:
            logger.error(f"获取最新区块哈希失败: {str(e)}", "SolanaClient")
            return None
    
    def send_transaction(self, transaction_data: str) -> Optional[str]:
        """发送交易"""
        try:
            result = self.make_rpc_request("sendTransaction", [
                transaction_data,
                {"encoding": "base64", "skipPreflight": False, "preflightCommitment": "processed"}
            ])
            return result
        except Exception as e:
            logger.error(f"发送交易失败: {str(e)}", "SolanaClient")
            return None
    
    def confirm_transaction(self, signature: str, commitment: str = "confirmed") -> bool:
        """确认交易"""
        try:
            result = self.make_rpc_request("getSignatureStatuses", [[signature]])
            statuses = result.get('value', [])
            
            if not statuses or not statuses[0]:
                return False
            
            status = statuses[0]
            return status.get('confirmationStatus') == commitment and status.get('err') is None
            
        except Exception as e:
            logger.error(f"确认交易失败 {signature}: {str(e)}", "SolanaClient")
            return False
    
    def get_slot(self) -> Optional[int]:
        """获取当前slot"""
        try:
            result = self.make_rpc_request("getSlot")
            return result
        except Exception as e:
            logger.error(f"获取slot失败: {str(e)}", "SolanaClient")
            return None
    
    def get_block_height(self) -> Optional[int]:
        """获取当前区块高度"""
        try:
            result = self.make_rpc_request("getBlockHeight")
            return result
        except Exception as e:
            logger.error(f"获取区块高度失败: {str(e)}", "SolanaClient")
            return None
    
    def get_signatures_for_address(self, address: str, limit: int = 10) -> List[Dict]:
        """获取地址的交易签名"""
        try:
            result = self.make_rpc_request("getSignaturesForAddress", [
                address,
                {"limit": limit}
            ])
            return result or []
        except Exception as e:
            logger.error(f"获取地址交易签名失败 {address}: {str(e)}", "SolanaClient")
            return []
    
    def get_token_accounts_by_owner(self, owner: str, mint: str = None) -> List[Dict]:
        """获取用户的代币账户"""
        try:
            params = [owner]
            if mint:
                params.append({"mint": mint})
            else:
                params.append({"programId": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"})
            
            params.append({"encoding": "jsonParsed"})
            
            result = self.make_rpc_request("getTokenAccountsByOwner", params)
            return result.get('value', [])
        except Exception as e:
            logger.error(f"获取代币账户失败 {owner}: {str(e)}", "SolanaClient")
            return []
    
    def get_multiple_accounts(self, public_keys: List[str]) -> List[Dict]:
        """批量获取账户信息"""
        try:
            result = self.make_rpc_request("getMultipleAccounts", [
                public_keys,
                {"encoding": "jsonParsed"}
            ])
            return result.get('value', [])
        except Exception as e:
            logger.error(f"批量获取账户信息失败: {str(e)}", "SolanaClient")
            return []
    
    def get_public_key_from_private_key(self, private_key_array: List[int]) -> str:
        """从私钥数组生成公钥（模拟实现）"""
        # 这里应该使用真正的Solana密钥生成逻辑
        # 为了演示，我们使用一个简化的实现
        try:
            # 在实际实现中，这里应该使用 solana-py 或类似库
            # 现在我们生成一个模拟的公钥
            import hashlib
            import base58
            
            # 使用私钥的哈希作为公钥（仅用于演示）
            private_key_bytes = bytes(private_key_array)
            hash_object = hashlib.sha256(private_key_bytes)
            public_key_bytes = hash_object.digest()
            
            # 生成一个有效的Solana地址格式
            public_key = base58.b58encode(public_key_bytes).decode('utf-8')
            
            # 确保长度正确（Solana地址通常是32-44字符）
            if len(public_key) > 44:
                public_key = public_key[:44]
            elif len(public_key) < 32:
                public_key = public_key.ljust(32, '1')
            
            return public_key
            
        except Exception as e:
            logger.error(f"生成公钥失败: {str(e)}", "SolanaClient")
            # 返回一个默认的测试公钥
            return "11111111111111111111111111111111"
    
    def check_rpc_health(self) -> Dict:
        """检查RPC节点健康状态"""
        health_status = {}
        
        for i, rpc_url in enumerate(self.rpc_urls):
            try:
                start_time = time.time()
                
                # 临时切换到这个RPC
                original_index = self.current_rpc_index
                self.current_rpc_index = i
                
                # 测试基本请求
                result = self.make_rpc_request("getHealth", max_retries=1)
                
                response_time = (time.time() - start_time) * 1000  # 毫秒
                
                health_status[rpc_url] = {
                    'status': 'healthy',
                    'response_time_ms': round(response_time, 2),
                    'result': result
                }
                
                # 恢复原始RPC索引
                self.current_rpc_index = original_index
                
            except Exception as e:
                health_status[rpc_url] = {
                    'status': 'unhealthy',
                    'error': str(e),
                    'response_time_ms': None
                }
        
        return health_status
    
    def get_program_accounts(self, program_id: str, filters: List[Dict] = None) -> List[Dict]:
        """获取程序账户"""
        try:
            params = [program_id]
            if filters:
                params.append({"filters": filters, "encoding": "jsonParsed"})
            else:
                params.append({"encoding": "jsonParsed"})
            
            result = self.make_rpc_request("getProgramAccounts", params)
            return result or []
        except Exception as e:
            logger.error(f"获取程序账户失败 {program_id}: {str(e)}", "SolanaClient")
            return []

