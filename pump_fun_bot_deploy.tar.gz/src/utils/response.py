from flask import jsonify
from datetime import datetime

def success_response(data=None, message="操作成功", code=200):
    """成功响应格式"""
    response = {
        'success': True,
        'code': code,
        'message': message,
        'data': data,
        'timestamp': datetime.utcnow().isoformat()
    }
    return jsonify(response), code

def error_response(message="操作失败", code=400, error_code=None):
    """错误响应格式"""
    response = {
        'success': False,
        'code': code,
        'message': message,
        'error_code': error_code,
        'timestamp': datetime.utcnow().isoformat()
    }
    return jsonify(response), code

def paginated_response(data, page=1, per_page=20, total=0, message="获取成功"):
    """分页响应格式"""
    response = {
        'success': True,
        'message': message,
        'data': data,
        'pagination': {
            'page': page,
            'per_page': per_page,
            'total': total,
            'pages': (total + per_page - 1) // per_page
        },
        'timestamp': datetime.utcnow().isoformat()
    }
    return jsonify(response), 200

