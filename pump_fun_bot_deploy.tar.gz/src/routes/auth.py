from flask import Blueprint, request, jsonify, current_app
from werkzeug.security import check_password_hash, generate_password_hash
import jwt
import datetime
from functools import wraps
from src.models.user import db, User, UserSession, LoginLog
from src.utils.logger import logger
import uuid

auth_bp = Blueprint('auth', __name__, url_prefix='/api/auth')

def token_required(f):
    """JWT token验证装饰器"""
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        auth_header = request.headers.get('Authorization')
        
        if auth_header:
            try:
                token = auth_header.split(" ")[1]  # Bearer <token>
            except IndexError:
                return jsonify({'message': 'Token格式无效'}), 401
        
        if not token:
            return jsonify({'message': '缺少认证token'}), 401
        
        try:
            data = jwt.decode(token, current_app.config['SECRET_KEY'], algorithms=['HS256'])
            current_user_id = data['user_id']
            
            # 验证用户是否存在且活跃
            user = User.query.filter_by(id=current_user_id, is_active=True).first()
            if not user:
                return jsonify({'message': '用户不存在或已禁用'}), 401
            
            # 验证会话是否有效
            session = UserSession.query.filter_by(
                user_id=current_user_id,
                session_token=token,
                is_active=True
            ).first()
            
            if not session or session.expires_at < datetime.datetime.utcnow():
                return jsonify({'message': 'Token已过期'}), 401
            
            request.current_user = user
            
        except jwt.ExpiredSignatureError:
            return jsonify({'message': 'Token已过期'}), 401
        except jwt.InvalidTokenError:
            return jsonify({'message': 'Token无效'}), 401
        except Exception as e:
            logger.error(f"Token验证失败: {str(e)}", "AuthAPI")
            return jsonify({'message': '认证失败'}), 401
        
        return f(*args, **kwargs)
    
    return decorated

@auth_bp.route('/login', methods=['POST'])
def login():
    """用户登录"""
    try:
        data = request.get_json()
        
        if not data or not data.get('username') or not data.get('password'):
            return jsonify({
                'success': False,
                'message': '用户名和密码不能为空'
            }), 400
        
        username = data['username'].strip()
        password = data['password']
        
        # 查找用户
        user = User.query.filter_by(username=username, is_active=True).first()
        
        # 记录登录尝试
        client_ip = request.environ.get('HTTP_X_REAL_IP', request.remote_addr)
        user_agent = request.headers.get('User-Agent', '')
        
        if not user or not check_password_hash(user.password_hash, password):
            # 记录失败的登录尝试
            login_log = LoginLog(
                user_id=user.id if user else None,
                ip_address=client_ip,
                user_agent=user_agent,
                login_result='failed',
                failure_reason='invalid_credentials'
            )
            db.session.add(login_log)
            db.session.commit()
            
            logger.warning(f"登录失败: {username} from {client_ip}", "AuthAPI")
            return jsonify({
                'success': False,
                'message': '用户名或密码错误'
            }), 401
        
        # 生成JWT token
        token_payload = {
            'user_id': user.id,
            'username': user.username,
            'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=24),
            'iat': datetime.datetime.utcnow()
        }
        
        token = jwt.encode(token_payload, current_app.config['SECRET_KEY'], algorithm='HS256')
        
        # 创建用户会话
        session = UserSession(
            user_id=user.id,
            session_token=token,
            ip_address=client_ip,
            user_agent=user_agent,
            expires_at=datetime.datetime.utcnow() + datetime.timedelta(hours=24)
        )
        db.session.add(session)
        
        # 更新用户最后登录时间
        user.last_login = datetime.datetime.utcnow()
        
        # 记录成功的登录
        login_log = LoginLog(
            user_id=user.id,
            ip_address=client_ip,
            user_agent=user_agent,
            login_result='success'
        )
        db.session.add(login_log)
        
        db.session.commit()
        
        logger.info(f"用户登录成功: {username} from {client_ip}", "AuthAPI")
        
        return jsonify({
            'success': True,
            'message': '登录成功',
            'token': token,
            'user': {
                'id': user.id,
                'username': user.username,
                'email': user.email,
                'role': user.role
            }
        }), 200
        
    except Exception as e:
        logger.error(f"登录处理异常: {str(e)}", "AuthAPI", exc_info=True)
        return jsonify({
            'success': False,
            'message': '服务器内部错误'
        }), 500

@auth_bp.route('/validate', methods=['POST'])
def validate_token():
    """验证token有效性"""
    try:
        auth_header = request.headers.get('Authorization')
        
        if not auth_header:
            return jsonify({
                'success': False,
                'message': '缺少认证token'
            }), 401
        
        try:
            token = auth_header.split(" ")[1]
        except IndexError:
            return jsonify({
                'success': False,
                'message': 'Token格式无效'
            }), 401
        
        try:
            data = jwt.decode(token, current_app.config['SECRET_KEY'], algorithms=['HS256'])
            user_id = data['user_id']
            
            # 验证用户和会话
            user = User.query.filter_by(id=user_id, is_active=True).first()
            if not user:
                return jsonify({
                    'success': False,
                    'message': '用户不存在或已禁用'
                }), 401
            
            session = UserSession.query.filter_by(
                user_id=user_id,
                session_token=token,
                is_active=True
            ).first()
            
            if not session or session.expires_at < datetime.datetime.utcnow():
                return jsonify({
                    'success': False,
                    'message': 'Token已过期'
                }), 401
            
            return jsonify({
                'success': True,
                'message': 'Token有效',
                'user': {
                    'id': user.id,
                    'username': user.username,
                    'email': user.email,
                    'role': user.role
                }
            }), 200
            
        except jwt.ExpiredSignatureError:
            return jsonify({
                'success': False,
                'message': 'Token已过期'
            }), 401
        except jwt.InvalidTokenError:
            return jsonify({
                'success': False,
                'message': 'Token无效'
            }), 401
            
    except Exception as e:
        logger.error(f"Token验证异常: {str(e)}", "AuthAPI", exc_info=True)
        return jsonify({
            'success': False,
            'message': '服务器内部错误'
        }), 500

@auth_bp.route('/logout', methods=['POST'])
@token_required
def logout():
    """用户登出"""
    try:
        auth_header = request.headers.get('Authorization')
        token = auth_header.split(" ")[1]
        
        # 使会话失效
        session = UserSession.query.filter_by(
            user_id=request.current_user.id,
            session_token=token
        ).first()
        
        if session:
            session.is_active = False
            db.session.commit()
        
        logger.info(f"用户登出: {request.current_user.username}", "AuthAPI")
        
        return jsonify({
            'success': True,
            'message': '登出成功'
        }), 200
        
    except Exception as e:
        logger.error(f"登出处理异常: {str(e)}", "AuthAPI", exc_info=True)
        return jsonify({
            'success': False,
            'message': '服务器内部错误'
        }), 500

@auth_bp.route('/change-password', methods=['POST'])
@token_required
def change_password():
    """修改密码"""
    try:
        data = request.get_json()
        
        if not data or not data.get('old_password') or not data.get('new_password'):
            return jsonify({
                'success': False,
                'message': '旧密码和新密码不能为空'
            }), 400
        
        old_password = data['old_password']
        new_password = data['new_password']
        
        # 验证旧密码
        if not check_password_hash(request.current_user.password_hash, old_password):
            return jsonify({
                'success': False,
                'message': '旧密码错误'
            }), 400
        
        # 验证新密码强度
        if len(new_password) < 6:
            return jsonify({
                'success': False,
                'message': '新密码长度至少6位'
            }), 400
        
        # 更新密码
        request.current_user.password_hash = generate_password_hash(new_password)
        db.session.commit()
        
        logger.info(f"用户修改密码: {request.current_user.username}", "AuthAPI")
        
        return jsonify({
            'success': True,
            'message': '密码修改成功'
        }), 200
        
    except Exception as e:
        logger.error(f"修改密码异常: {str(e)}", "AuthAPI", exc_info=True)
        return jsonify({
            'success': False,
            'message': '服务器内部错误'
        }), 500

@auth_bp.route('/profile', methods=['GET'])
@token_required
def get_profile():
    """获取用户信息"""
    try:
        user = request.current_user
        
        return jsonify({
            'success': True,
            'user': {
                'id': user.id,
                'username': user.username,
                'email': user.email,
                'role': user.role,
                'created_at': user.created_at.isoformat() if user.created_at else None,
                'last_login': user.last_login.isoformat() if user.last_login else None
            }
        }), 200
        
    except Exception as e:
        logger.error(f"获取用户信息异常: {str(e)}", "AuthAPI", exc_info=True)
        return jsonify({
            'success': False,
            'message': '服务器内部错误'
        }), 500

@auth_bp.route('/sessions', methods=['GET'])
@token_required
def get_user_sessions():
    """获取用户会话列表"""
    try:
        sessions = UserSession.query.filter_by(
            user_id=request.current_user.id,
            is_active=True
        ).order_by(UserSession.created_at.desc()).all()
        
        session_list = []
        for session in sessions:
            session_list.append({
                'id': session.id,
                'ip_address': session.ip_address,
                'user_agent': session.user_agent,
                'created_at': session.created_at.isoformat(),
                'expires_at': session.expires_at.isoformat(),
                'is_current': session.session_token == request.headers.get('Authorization').split(" ")[1]
            })
        
        return jsonify({
            'success': True,
            'sessions': session_list
        }), 200
        
    except Exception as e:
        logger.error(f"获取会话列表异常: {str(e)}", "AuthAPI", exc_info=True)
        return jsonify({
            'success': False,
            'message': '服务器内部错误'
        }), 500

@auth_bp.route('/login-logs', methods=['GET'])
@token_required
def get_login_logs():
    """获取登录日志"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        
        logs = LoginLog.query.filter_by(
            user_id=request.current_user.id
        ).order_by(LoginLog.login_time.desc()).paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        log_list = []
        for log in logs.items:
            log_list.append({
                'id': log.id,
                'ip_address': log.ip_address,
                'user_agent': log.user_agent,
                'login_result': log.login_result,
                'failure_reason': log.failure_reason,
                'login_time': log.login_time.isoformat()
            })
        
        return jsonify({
            'success': True,
            'logs': log_list,
            'pagination': {
                'page': logs.page,
                'pages': logs.pages,
                'per_page': logs.per_page,
                'total': logs.total
            }
        }), 200
        
    except Exception as e:
        logger.error(f"获取登录日志异常: {str(e)}", "AuthAPI", exc_info=True)
        return jsonify({
            'success': False,
            'message': '服务器内部错误'
        }), 500

