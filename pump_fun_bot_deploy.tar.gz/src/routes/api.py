from flask import Blueprint, request, jsonify
from src.services.wallet_service import WalletService
from src.services.token_service import TokenService
from src.services.fund_service import FundService
from src.services.config_service import ConfigService
from src.utils.response import success_response, error_response
import traceback

api_bp = Blueprint('api', __name__)

# 初始化服务
wallet_service = WalletService()
token_service = TokenService()
fund_service = FundService()
config_service = ConfigService()

@api_bp.route('/status', methods=['GET'])
def get_status():
    """获取系统状态"""
    try:
        status = {
            'service': 'PUMP.FUN Bot API',
            'version': '1.0.0',
            'status': 'running',
            'wallets': wallet_service.get_wallet_count(),
            'main_wallet': wallet_service.get_main_wallet_info(),
            'rpc_status': config_service.check_rpc_status(),
            'features': [
                'wallet_management',
                'token_creation',
                'fund_management',
                'ai_metadata_generation',
                'chain_listening',
                'strategy_engine'
            ]
        }
        return success_response(status)
    except Exception as e:
        return error_response(f"获取状态失败: {str(e)}")

# ==================== 钱包管理 API ====================

@api_bp.route('/wallets', methods=['GET'])
def get_wallets():
    """获取所有钱包"""
    try:
        wallets = wallet_service.get_all_wallets()
        return success_response(wallets)
    except Exception as e:
        return error_response(f"获取钱包列表失败: {str(e)}")

@api_bp.route('/wallets/generate', methods=['POST'])
def generate_wallets():
    """生成新钱包"""
    try:
        data = request.get_json() or {}
        count = data.get('count', 1)
        tags = data.get('tags', [])
        
        if count > 100:
            return error_response("单次最多生成100个钱包")
        
        wallets = wallet_service.generate_wallets(count, tags)
        return success_response({
            'message': f'成功生成 {len(wallets)} 个钱包',
            'wallets': wallets
        })
    except Exception as e:
        return error_response(f"生成钱包失败: {str(e)}")

@api_bp.route('/wallets/<wallet_id>/balance', methods=['GET'])
def get_wallet_balance(wallet_id):
    """获取钱包余额"""
    try:
        balance = wallet_service.get_wallet_balance(wallet_id)
        return success_response({'balance': balance})
    except Exception as e:
        return error_response(f"获取钱包余额失败: {str(e)}")

@api_bp.route('/wallets/balances/update', methods=['POST'])
def update_all_balances():
    """更新所有钱包余额"""
    try:
        result = wallet_service.update_all_balances()
        return success_response(result)
    except Exception as e:
        return error_response(f"更新余额失败: {str(e)}")

# ==================== 代币管理 API ====================

@api_bp.route('/tokens', methods=['GET'])
def get_tokens():
    """获取所有代币"""
    try:
        tokens = token_service.get_all_tokens()
        return success_response(tokens)
    except Exception as e:
        return error_response(f"获取代币列表失败: {str(e)}")

@api_bp.route('/tokens/create', methods=['POST'])
def create_token():
    """创建单个代币"""
    try:
        data = request.get_json() or {}
        
        # 验证必需参数
        if not data.get('name') or not data.get('symbol'):
            return error_response("代币名称和符号不能为空")
        
        result = token_service.create_token(
            name=data['name'],
            symbol=data['symbol'],
            description=data.get('description', ''),
            image_uri=data.get('image_uri', ''),
            buy_amount=data.get('buy_amount', 0.01)
        )
        
        return success_response(result)
    except Exception as e:
        return error_response(f"创建代币失败: {str(e)}")

@api_bp.route('/tokens/create-and-buy', methods=['POST'])
def create_and_buy_token():
    """一键发币并购买"""
    try:
        data = request.get_json() or {}
        
        result = token_service.create_and_buy_token(
            name=data.get('name'),
            symbol=data.get('symbol'),
            description=data.get('description'),
            use_ai=data.get('use_ai', False),
            buy_amount=data.get('buy_amount', 0.01),
            theme=data.get('theme', '')
        )
        
        return success_response(result)
    except Exception as e:
        return error_response(f"一键发币失败: {str(e)}")

@api_bp.route('/tokens/batch-create', methods=['POST'])
def batch_create_tokens():
    """批量创建代币"""
    try:
        data = request.get_json() or {}
        count = data.get('count', 1)
        
        if count > 50:
            return error_response("单次最多创建50个代币")
        
        result = token_service.batch_create_tokens(
            count=count,
            use_ai=data.get('use_ai', False),
            buy_amount=data.get('buy_amount', 0.01),
            theme=data.get('theme', ''),
            delay_ms=data.get('delay_ms', 2000)
        )
        
        return success_response(result)
    except Exception as e:
        return error_response(f"批量创建代币失败: {str(e)}")

@api_bp.route('/tokens/<token_mint>/buy', methods=['POST'])
def buy_token(token_mint):
    """购买代币"""
    try:
        data = request.get_json() or {}
        amount = data.get('amount', 0.01)
        
        result = token_service.buy_token(token_mint, amount)
        return success_response(result)
    except Exception as e:
        return error_response(f"购买代币失败: {str(e)}")

@api_bp.route('/tokens/<token_mint>/sell', methods=['POST'])
def sell_token(token_mint):
    """出售代币"""
    try:
        data = request.get_json() or {}
        percentage = data.get('percentage', 100)  # 默认全部卖出
        
        result = token_service.sell_token(token_mint, percentage)
        return success_response(result)
    except Exception as e:
        return error_response(f"出售代币失败: {str(e)}")

# ==================== 资金管理 API ====================

@api_bp.route('/funds/distribute', methods=['POST'])
def distribute_funds():
    """分发资金"""
    try:
        data = request.get_json() or {}
        amount = data.get('amount', 0.01)
        target_wallets = data.get('target_wallets')  # 可选，指定目标钱包
        
        result = fund_service.distribute_funds(amount, target_wallets)
        return success_response(result)
    except Exception as e:
        return error_response(f"资金分发失败: {str(e)}")

@api_bp.route('/funds/collect', methods=['POST'])
def collect_funds():
    """归集资金"""
    try:
        data = request.get_json() or {}
        source_wallets = data.get('source_wallets')  # 可选，指定源钱包
        
        result = fund_service.collect_funds(source_wallets)
        return success_response(result)
    except Exception as e:
        return error_response(f"资金归集失败: {str(e)}")

@api_bp.route('/funds/status', methods=['GET'])
def get_fund_status():
    """获取资金状态"""
    try:
        status = fund_service.get_fund_status()
        return success_response(status)
    except Exception as e:
        return error_response(f"获取资金状态失败: {str(e)}")

# ==================== 配置管理 API ====================

@api_bp.route('/config', methods=['GET'])
def get_config():
    """获取配置"""
    try:
        config = config_service.get_config()
        return success_response(config)
    except Exception as e:
        return error_response(f"获取配置失败: {str(e)}")

@api_bp.route('/config', methods=['POST'])
def update_config():
    """更新配置"""
    try:
        data = request.get_json() or {}
        result = config_service.update_config(data)
        return success_response(result)
    except Exception as e:
        return error_response(f"更新配置失败: {str(e)}")

# ==================== AI 和策略 API ====================

@api_bp.route('/ai/generate-metadata', methods=['POST'])
def generate_ai_metadata():
    """AI生成代币元数据"""
    try:
        data = request.get_json() or {}
        theme = data.get('theme', '')
        
        result = token_service.generate_ai_metadata(theme)
        return success_response(result)
    except Exception as e:
        return error_response(f"AI生成元数据失败: {str(e)}")

@api_bp.route('/strategy/start', methods=['POST'])
def start_strategy():
    """启动策略引擎"""
    try:
        data = request.get_json() or {}
        strategy_type = data.get('strategy_type', 'snipe')
        config = data.get('config', {})
        
        # TODO: 实现策略引擎启动
        return success_response({
            'message': f'策略 {strategy_type} 启动成功',
            'strategy_id': 'strategy_001'
        })
    except Exception as e:
        return error_response(f"启动策略失败: {str(e)}")

@api_bp.route('/strategy/stop', methods=['POST'])
def stop_strategy():
    """停止策略引擎"""
    try:
        data = request.get_json() or {}
        strategy_id = data.get('strategy_id')
        
        # TODO: 实现策略引擎停止
        return success_response({
            'message': f'策略 {strategy_id} 停止成功'
        })
    except Exception as e:
        return error_response(f"停止策略失败: {str(e)}")

# ==================== 错误处理 ====================

@api_bp.errorhandler(404)
def not_found(error):
    return error_response("API端点不存在", 404)

@api_bp.errorhandler(500)
def internal_error(error):
    return error_response("服务器内部错误", 500)

