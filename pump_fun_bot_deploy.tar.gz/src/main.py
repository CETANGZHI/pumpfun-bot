import os
import sys
from datetime import datetime
# DON'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask, send_from_directory, jsonify
from flask_cors import CORS
from src.models.user import db, create_tables
from src.routes.api import api_bp
from src.routes.auth import auth_bp
from src.utils.logger import logger

app = Flask(__name__, static_folder=os.path.join(os.path.dirname(__file__), '..', 'frontend', 'dist'))
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'pumpfun-bot-secret-key-2025')

# 启用CORS支持前后端分离
CORS(app, origins=['http://localhost:5173', 'https://cfish.cc', 'https://www.cfish.cc'])

# 注册API蓝图
app.register_blueprint(api_bp, url_prefix='/api')
app.register_blueprint(auth_bp)

# 数据库配置
database_dir = os.path.join(os.path.dirname(__file__), 'database')
os.makedirs(database_dir, exist_ok=True)
app.config['SQLALCHEMY_DATABASE_URI'] = f"sqlite:///{os.path.join(database_dir, 'app.db')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
    'pool_pre_ping': True,
    'pool_recycle': 300,
}

db.init_app(app)

with app.app_context():
    create_tables()

@app.route('/health')
def health_check():
    """健康检查接口"""
    return jsonify({
        'status': 'healthy',
        'service': 'PUMP.FUN Bot API',
        'version': '1.0.0'
    })

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve(path):
    """服务前端静态文件"""
    static_folder_path = app.static_folder
    if static_folder_path is None:
        return "Static folder not configured", 404

    if path != "" and os.path.exists(os.path.join(static_folder_path, path)):
        return send_from_directory(static_folder_path, path)
    else:
        index_path = os.path.join(static_folder_path, 'index.html')
        if os.path.exists(index_path):
            return send_from_directory(static_folder_path, 'index.html')
        else:
            return jsonify({
                'message': 'PUMP.FUN Bot API Server',
                'status': 'running',
                'endpoints': [
                    '/api/wallets',
                    '/api/tokens',
                    '/api/funds',
                    '/api/config',
                    '/api/status'
                ]
            })

if __name__ == '__main__':
    print("🚀 启动 PUMP.FUN 批量发币机器人 API 服务器")
    print("📡 API 端点: http://0.0.0.0:5000/api")
    print("🌐 前端界面: http://0.0.0.0:5000")
    app.run(host='0.0.0.0', port=5000, debug=True)

