import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Wallet, Plus, Download, Upload, Copy, Eye, EyeOff } from 'lucide-react'

export default function WalletManager() {
  const [wallets, setWallets] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchWallets()
  }, [])

  const fetchWallets = async () => {
    try {
      // 模拟API调用
      setWallets([
        { id: 1, name: '主钱包', address: 'ABC...XYZ', balance: 1.2345, type: 'main' },
        { id: 2, name: '子钱包1', address: 'DEF...UVW', balance: 0.5678, type: 'sub' }
      ])
    } catch (error) {
      console.error('Failed to fetch wallets:', error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">钱包管理</h2>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          创建钱包
        </Button>
      </div>

      <div className="grid gap-4">
        {wallets.map((wallet) => (
          <Card key={wallet.id}>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Wallet className="h-5 w-5 mr-2" />
                {wallet.name}
              </CardTitle>
              <CardDescription>{wallet.address}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex justify-between items-center">
                <span className="text-lg font-semibold">{wallet.balance} SOL</span>
                <div className="space-x-2">
                  <Button variant="outline" size="sm">
                    <Copy className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="sm">
                    <Eye className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

