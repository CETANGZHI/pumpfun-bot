import { useState, useEffect } from 'react'
import { Routes, Route, useNavigate, useLocation } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { 
  Menu, 
  X, 
  Home, 
  Wallet, 
  Target, 
  TrendingUp, 
  Settings, 
  LogOut,
  Bell,
  User,
  Moon,
  Sun,
  Volume2,
  VolumeX
} from 'lucide-react'
import Overview from './Overview'
import WalletManager from '../Wallet/WalletManager'
import TradingPanel from '../Trading/TradingPanel'
import MonitoringPanel from '../Monitoring/MonitoringPanel'
import SettingsPanel from '../Settings/SettingsPanel'

export default function Dashboard({ onLogout }) {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [darkMode, setDarkMode] = useState(false)
  const [voiceEnabled, setVoiceEnabled] = useState(true)
  const [notifications, setNotifications] = useState([])
  const navigate = useNavigate()
  const location = useLocation()

  // 检查系统主题偏好
  useEffect(() => {
    const isDark = localStorage.getItem('darkMode') === 'true' || 
                   (!localStorage.getItem('darkMode') && window.matchMedia('(prefers-color-scheme: dark)').matches)
    setDarkMode(isDark)
    document.documentElement.classList.toggle('dark', isDark)
  }, [])

  // 检查语音设置
  useEffect(() => {
    const voiceSetting = localStorage.getItem('voiceEnabled')
    if (voiceSetting !== null) {
      setVoiceEnabled(voiceSetting === 'true')
    }
  }, [])

  const toggleDarkMode = () => {
    const newDarkMode = !darkMode
    setDarkMode(newDarkMode)
    localStorage.setItem('darkMode', newDarkMode.toString())
    document.documentElement.classList.toggle('dark', newDarkMode)
  }

  const toggleVoice = () => {
    const newVoiceEnabled = !voiceEnabled
    setVoiceEnabled(newVoiceEnabled)
    localStorage.setItem('voiceEnabled', newVoiceEnabled.toString())
    
    // 播放测试语音
    if (newVoiceEnabled && 'speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance('语音提示已开启')
      utterance.lang = 'zh-CN'
      speechSynthesis.speak(utterance)
    }
  }

  const menuItems = [
    { id: 'overview', label: '总览', icon: Home, path: '/dashboard' },
    { id: 'wallet', label: '钱包管理', icon: Wallet, path: '/dashboard/wallet' },
    { id: 'trading', label: '交易面板', icon: Target, path: '/dashboard/trading' },
    { id: 'monitoring', label: '监控中心', icon: TrendingUp, path: '/dashboard/monitoring' },
    { id: 'settings', label: '系统设置', icon: Settings, path: '/dashboard/settings' }
  ]

  const getCurrentPageTitle = () => {
    const currentPath = location.pathname
    const currentItem = menuItems.find(item => item.path === currentPath)
    return currentItem ? currentItem.label : 'PUMP.FUN 机器人'
  }

  return (
    <div className="min-h-screen bg-background">
      {/* 移动端顶部导航栏 */}
      <div className="lg:hidden bg-card border-b px-4 py-3 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setSidebarOpen(true)}
          >
            <Menu className="h-5 w-5" />
          </Button>
          <h1 className="font-semibold text-lg">{getCurrentPageTitle()}</h1>
        </div>
        
        <div className="flex items-center space-x-2">
          <Button variant="ghost" size="sm" onClick={toggleVoice}>
            {voiceEnabled ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
          </Button>
          <Button variant="ghost" size="sm" onClick={toggleDarkMode}>
            {darkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
          </Button>
        </div>
      </div>

      <div className="flex">
        {/* 侧边栏 */}
        <div className={`
          fixed inset-y-0 left-0 z-50 w-64 bg-card border-r transform transition-transform duration-200 ease-in-out
          lg:translate-x-0 lg:static lg:inset-0
          ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}
        `}>
          <div className="flex flex-col h-full">
            {/* 侧边栏头部 */}
            <div className="p-6 border-b">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                    <Target className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h2 className="font-bold text-lg">PUMP.FUN</h2>
                    <p className="text-xs text-muted-foreground">智能交易机器人</p>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  className="lg:hidden"
                  onClick={() => setSidebarOpen(false)}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* 导航菜单 */}
            <nav className="flex-1 p-4 space-y-2">
              {menuItems.map((item) => {
                const Icon = item.icon
                const isActive = location.pathname === item.path
                
                return (
                  <Button
                    key={item.id}
                    variant={isActive ? "default" : "ghost"}
                    className="w-full justify-start"
                    onClick={() => {
                      navigate(item.path)
                      setSidebarOpen(false)
                    }}
                  >
                    <Icon className="mr-3 h-4 w-4" />
                    {item.label}
                  </Button>
                )
              })}
            </nav>

            {/* 侧边栏底部 */}
            <div className="p-4 border-t space-y-2">
              {/* 桌面端控制按钮 */}
              <div className="hidden lg:flex space-x-2">
                <Button variant="ghost" size="sm" onClick={toggleVoice} className="flex-1">
                  {voiceEnabled ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
                </Button>
                <Button variant="ghost" size="sm" onClick={toggleDarkMode} className="flex-1">
                  {darkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
                </Button>
              </div>
              
              <Button
                variant="ghost"
                className="w-full justify-start text-destructive hover:text-destructive"
                onClick={onLogout}
              >
                <LogOut className="mr-3 h-4 w-4" />
                退出登录
              </Button>
            </div>
          </div>
        </div>

        {/* 主内容区域 */}
        <div className="flex-1 lg:ml-0">
          {/* 桌面端顶部导航栏 */}
          <div className="hidden lg:block bg-card border-b px-6 py-4">
            <div className="flex items-center justify-between">
              <h1 className="text-2xl font-bold">{getCurrentPageTitle()}</h1>
              
              <div className="flex items-center space-x-4">
                <Button variant="ghost" size="sm">
                  <Bell className="h-4 w-4" />
                  {notifications.length > 0 && (
                    <span className="ml-1 bg-red-500 text-white text-xs rounded-full px-1">
                      {notifications.length}
                    </span>
                  )}
                </Button>
                <Button variant="ghost" size="sm">
                  <User className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>

          {/* 页面内容 */}
          <main className="p-4 lg:p-6">
            <Routes>
              <Route path="/" element={<Overview />} />
              <Route path="/wallet" element={<WalletManager />} />
              <Route path="/trading" element={<TradingPanel />} />
              <Route path="/monitoring" element={<MonitoringPanel />} />
              <Route path="/settings" element={<SettingsPanel />} />
            </Routes>
          </main>
        </div>
      </div>

      {/* 移动端遮罩层 */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}
    </div>
  )
}

