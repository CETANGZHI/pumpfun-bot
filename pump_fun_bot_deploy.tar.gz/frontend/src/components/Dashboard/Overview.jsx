import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { 
  TrendingUp, 
  TrendingDown, 
  Wallet, 
  Target, 
  Activity,
  DollarSign,
  Users,
  Zap,
  AlertTriangle,
  CheckCircle,
  Clock,
  BarChart3
} from 'lucide-react'

export default function Overview() {
  const [stats, setStats] = useState({
    totalBalance: 0,
    totalProfit: 0,
    profitPercentage: 0,
    activePositions: 0,
    totalWallets: 0,
    todayTrades: 0,
    successRate: 0,
    systemStatus: 'running'
  })

  const [recentActivities, setRecentActivities] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchOverviewData()
    const interval = setInterval(fetchOverviewData, 30000) // 每30秒更新一次
    return () => clearInterval(interval)
  }, [])

  const fetchOverviewData = async () => {
    try {
      const response = await fetch('/api/dashboard/overview', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
        }
      })
      
      if (response.ok) {
        const data = await response.json()
        setStats(data.stats)
        setRecentActivities(data.recent_activities || [])
      }
    } catch (error) {
      console.error('Failed to fetch overview data:', error)
    } finally {
      setLoading(false)
    }
  }

  const StatCard = ({ title, value, change, icon: Icon, trend, description }) => (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        {change !== undefined && (
          <div className={`flex items-center text-xs ${trend === 'up' ? 'text-green-600' : trend === 'down' ? 'text-red-600' : 'text-muted-foreground'}`}>
            {trend === 'up' && <TrendingUp className="h-3 w-3 mr-1" />}
            {trend === 'down' && <TrendingDown className="h-3 w-3 mr-1" />}
            {change}
          </div>
        )}
        {description && (
          <p className="text-xs text-muted-foreground mt-1">{description}</p>
        )}
      </CardContent>
    </Card>
  )

  const ActivityItem = ({ activity }) => {
    const getActivityIcon = (type) => {
      switch (type) {
        case 'trade': return <Target className="h-4 w-4 text-blue-500" />
        case 'profit': return <TrendingUp className="h-4 w-4 text-green-500" />
        case 'loss': return <TrendingDown className="h-4 w-4 text-red-500" />
        case 'alert': return <AlertTriangle className="h-4 w-4 text-yellow-500" />
        case 'system': return <Activity className="h-4 w-4 text-purple-500" />
        default: return <Clock className="h-4 w-4 text-gray-500" />
      }
    }

    return (
      <div className="flex items-center space-x-3 p-3 hover:bg-muted/50 rounded-lg transition-colors">
        {getActivityIcon(activity.type)}
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium truncate">{activity.title}</p>
          <p className="text-xs text-muted-foreground">{activity.description}</p>
        </div>
        <div className="text-xs text-muted-foreground">
          {activity.time}
        </div>
      </div>
    )
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {[...Array(4)].map((_, i) => (
            <Card key={i}>
              <CardHeader className="space-y-0 pb-2">
                <div className="h-4 bg-muted rounded animate-pulse"></div>
              </CardHeader>
              <CardContent>
                <div className="h-8 bg-muted rounded animate-pulse mb-2"></div>
                <div className="h-3 bg-muted rounded animate-pulse w-1/2"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* 系统状态指示器 */}
      <Card className="border-l-4 border-l-green-500">
        <CardContent className="pt-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <CheckCircle className="h-5 w-5 text-green-500" />
              <div>
                <p className="font-medium">系统运行正常</p>
                <p className="text-sm text-muted-foreground">所有服务正常运行，监控系统活跃</p>
              </div>
            </div>
            <div className="flex space-x-2">
              <Button variant="outline" size="sm">
                <Activity className="h-4 w-4 mr-2" />
                查看详情
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 核心指标卡片 */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="总资产"
          value={`${stats.totalBalance.toFixed(4)} SOL`}
          change="+2.5%"
          trend="up"
          icon={Wallet}
          description="包含所有钱包余额"
        />
        <StatCard
          title="总盈亏"
          value={`${stats.totalProfit >= 0 ? '+' : ''}${stats.totalProfit.toFixed(4)} SOL`}
          change={`${stats.profitPercentage >= 0 ? '+' : ''}${stats.profitPercentage.toFixed(2)}%`}
          trend={stats.totalProfit >= 0 ? 'up' : 'down'}
          icon={DollarSign}
          description="累计盈亏统计"
        />
        <StatCard
          title="活跃持仓"
          value={stats.activePositions}
          icon={Target}
          description="当前持有的代币数量"
        />
        <StatCard
          title="成功率"
          value={`${stats.successRate.toFixed(1)}%`}
          change="+1.2%"
          trend="up"
          icon={BarChart3}
          description="交易成功率"
        />
      </div>

      {/* 详细统计 */}
      <div className="grid gap-4 md:grid-cols-3">
        <StatCard
          title="钱包数量"
          value={stats.totalWallets}
          icon={Users}
          description="管理的钱包总数"
        />
        <StatCard
          title="今日交易"
          value={stats.todayTrades}
          change="+5"
          trend="up"
          icon={Zap}
          description="今日完成的交易数"
        />
        <StatCard
          title="系统状态"
          value="运行中"
          icon={Activity}
          description="监控和交易系统状态"
        />
      </div>

      {/* 最近活动和快速操作 */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* 最近活动 */}
        <Card>
          <CardHeader>
            <CardTitle>最近活动</CardTitle>
            <CardDescription>系统最新的交易和事件记录</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            {recentActivities.length > 0 ? (
              recentActivities.slice(0, 5).map((activity, index) => (
                <ActivityItem key={index} activity={activity} />
              ))
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <Activity className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p>暂无最近活动</p>
              </div>
            )}
            {recentActivities.length > 5 && (
              <div className="pt-2">
                <Button variant="outline" className="w-full">
                  查看全部活动
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* 快速操作 */}
        <Card>
          <CardHeader>
            <CardTitle>快速操作</CardTitle>
            <CardDescription>常用功能的快速入口</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button className="w-full justify-start" variant="outline">
              <Wallet className="h-4 w-4 mr-2" />
              创建新钱包
            </Button>
            <Button className="w-full justify-start" variant="outline">
              <Target className="h-4 w-4 mr-2" />
              开始狙击
            </Button>
            <Button className="w-full justify-start" variant="outline">
              <Zap className="h-4 w-4 mr-2" />
              批量发币
            </Button>
            <Button className="w-full justify-start" variant="outline">
              <BarChart3 className="h-4 w-4 mr-2" />
              查看报告
            </Button>
            <Button className="w-full justify-start" variant="outline">
              <Activity className="h-4 w-4 mr-2" />
              系统监控
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* 性能图表区域 */}
      <Card>
        <CardHeader>
          <CardTitle>性能概览</CardTitle>
          <CardDescription>过去24小时的系统性能和交易统计</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-64 flex items-center justify-center text-muted-foreground">
            <div className="text-center">
              <BarChart3 className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>图表组件开发中...</p>
              <p className="text-sm">将显示盈亏趋势、交易量等数据</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

