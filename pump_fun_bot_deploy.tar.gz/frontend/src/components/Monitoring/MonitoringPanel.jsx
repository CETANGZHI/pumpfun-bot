import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Activity, TrendingUp, AlertTriangle } from 'lucide-react'

export default function MonitoringPanel() {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">监控中心</h2>
        <Button variant="outline">
          <Activity className="h-4 w-4 mr-2" />
          刷新数据
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <TrendingUp className="h-5 w-5 mr-2" />
            系统监控
          </CardTitle>
          <CardDescription>实时系统状态和性能指标</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-muted-foreground">
            <Activity className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>监控面板开发中...</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

