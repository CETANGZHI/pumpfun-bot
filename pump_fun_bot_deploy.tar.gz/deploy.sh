#!/bin/bash

# PUMP.FUN 批量发币机器人部署脚本
# 适用于 Ubuntu 22.04+ 系统

set -e

echo "🚀 开始部署 PUMP.FUN 批量发币机器人..."

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 项目配置
PROJECT_NAME="pump_fun_bot"
PROJECT_DIR="/opt/$PROJECT_NAME"
SERVICE_USER="pumpbot"
DOMAIN="cfish.cc"
PYTHON_VERSION="3.11"

# 日志函数
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 检查是否为root用户
check_root() {
    if [[ $EUID -ne 0 ]]; then
        log_error "此脚本需要root权限运行"
        exit 1
    fi
}

# 更新系统
update_system() {
    log_info "更新系统包..."
    apt update && apt upgrade -y
    log_success "系统更新完成"
}

# 安装基础依赖
install_dependencies() {
    log_info "安装基础依赖..."
    apt install -y \
        python3.11 \
        python3.11-venv \
        python3.11-dev \
        python3-pip \
        nginx \
        supervisor \
        git \
        curl \
        wget \
        unzip \
        build-essential \
        libssl-dev \
        libffi-dev \
        sqlite3 \
        certbot \
        python3-certbot-nginx
    
    log_success "基础依赖安装完成"
}

# 创建项目用户
create_user() {
    log_info "创建项目用户..."
    if ! id "$SERVICE_USER" &>/dev/null; then
        useradd -r -s /bin/bash -d $PROJECT_DIR $SERVICE_USER
        log_success "用户 $SERVICE_USER 创建成功"
    else
        log_warning "用户 $SERVICE_USER 已存在"
    fi
}

# 创建项目目录
create_directories() {
    log_info "创建项目目录..."
    mkdir -p $PROJECT_DIR
    mkdir -p $PROJECT_DIR/logs
    mkdir -p $PROJECT_DIR/data
    mkdir -p $PROJECT_DIR/backups
    mkdir -p /var/log/$PROJECT_NAME
    
    chown -R $SERVICE_USER:$SERVICE_USER $PROJECT_DIR
    chown -R $SERVICE_USER:$SERVICE_USER /var/log/$PROJECT_NAME
    
    log_success "项目目录创建完成"
}

# 部署应用代码
deploy_application() {
    log_info "部署应用代码..."
    
    # 复制源代码
    cp -r /home/ubuntu/pump_fun_bot_new/* $PROJECT_DIR/
    
    # 设置权限
    chown -R $SERVICE_USER:$SERVICE_USER $PROJECT_DIR
    chmod +x $PROJECT_DIR/deploy.sh
    
    log_success "应用代码部署完成"
}

# 创建Python虚拟环境
create_venv() {
    log_info "创建Python虚拟环境..."
    
    cd $PROJECT_DIR
    sudo -u $SERVICE_USER python3.11 -m venv venv
    sudo -u $SERVICE_USER $PROJECT_DIR/venv/bin/pip install --upgrade pip
    sudo -u $SERVICE_USER $PROJECT_DIR/venv/bin/pip install -r requirements.txt
    
    log_success "Python虚拟环境创建完成"
}

# 配置环境变量
setup_environment() {
    log_info "配置环境变量..."
    
    cat > $PROJECT_DIR/.env << EOF
# Flask配置
FLASK_ENV=production
SECRET_KEY=$(openssl rand -hex 32)
HOST=0.0.0.0
PORT=5000

# 数据库配置
DATABASE_URL=sqlite:///$PROJECT_DIR/data/app.db

# Solana配置
SOLANA_RPC_URL=https://api.mainnet-beta.solana.com
SOLANA_WS_URL=wss://api.mainnet-beta.solana.com

# AI配置
OPENAI_API_KEY=your_openai_api_key_here
OPENAI_API_BASE=https://api.openai.com/v1

# 日志配置
LOG_LEVEL=INFO
LOG_FILE=$PROJECT_DIR/logs/app.log

# 安全配置
CORS_ORIGINS=https://$DOMAIN,https://www.$DOMAIN
EOF

    chown $SERVICE_USER:$SERVICE_USER $PROJECT_DIR/.env
    chmod 600 $PROJECT_DIR/.env
    
    log_success "环境变量配置完成"
}

# 初始化数据库
init_database() {
    log_info "初始化数据库..."
    
    cd $PROJECT_DIR
    sudo -u $SERVICE_USER $PROJECT_DIR/venv/bin/python -c "
from src.main import app
from src.models.user import create_tables
with app.app_context():
    create_tables()
print('数据库初始化完成')
"
    
    log_success "数据库初始化完成"
}

# 配置Supervisor
setup_supervisor() {
    log_info "配置Supervisor..."
    
    cat > /etc/supervisor/conf.d/$PROJECT_NAME.conf << EOF
[program:$PROJECT_NAME]
command=$PROJECT_DIR/venv/bin/gunicorn --bind 0.0.0.0:5000 --workers 4 --timeout 120 --keep-alive 2 --max-requests 1000 --max-requests-jitter 100 src.main:app
directory=$PROJECT_DIR
user=$SERVICE_USER
autostart=true
autorestart=true
redirect_stderr=true
stdout_logfile=/var/log/$PROJECT_NAME/app.log
stdout_logfile_maxbytes=50MB
stdout_logfile_backups=5
environment=PATH="$PROJECT_DIR/venv/bin"
EOF

    supervisorctl reread
    supervisorctl update
    supervisorctl start $PROJECT_NAME
    
    log_success "Supervisor配置完成"
}

# 配置Nginx
setup_nginx() {
    log_info "配置Nginx..."
    
    # 备份默认配置
    if [ -f /etc/nginx/sites-enabled/default ]; then
        mv /etc/nginx/sites-enabled/default /etc/nginx/sites-enabled/default.backup
    fi
    
    cat > /etc/nginx/sites-available/$PROJECT_NAME << EOF
# HTTP重定向到HTTPS
server {
    listen 80;
    server_name $DOMAIN www.$DOMAIN;
    return 301 https://\$server_name\$request_uri;
}

# HTTPS配置
server {
    listen 443 ssl http2;
    server_name $DOMAIN www.$DOMAIN;
    
    # SSL证书配置
    ssl_certificate /etc/letsencrypt/live/$DOMAIN/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/$DOMAIN/privkey.pem;
    
    # SSL安全配置
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-RSA-AES128-GCM-SHA256:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-RSA-AES128-SHA256:ECDHE-RSA-AES256-SHA384;
    ssl_prefer_server_ciphers off;
    ssl_session_cache shared:SSL:10m;
    ssl_session_timeout 10m;
    
    # 安全头
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;
    add_header X-XSS-Protection "1; mode=block";
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    
    # 客户端最大上传大小
    client_max_body_size 10M;
    
    # 静态文件缓存
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
        try_files \$uri @backend;
    }
    
    # API请求
    location /api/ {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }
    
    # 健康检查
    location /health {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
    
    # 前端应用
    location / {
        try_files \$uri \$uri/ @backend;
    }
    
    # 后端代理
    location @backend {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
    
    # 日志配置
    access_log /var/log/nginx/$PROJECT_NAME.access.log;
    error_log /var/log/nginx/$PROJECT_NAME.error.log;
}
EOF

    # 启用站点
    ln -sf /etc/nginx/sites-available/$PROJECT_NAME /etc/nginx/sites-enabled/
    
    # 测试配置
    nginx -t
    systemctl reload nginx
    
    log_success "Nginx配置完成"
}

# 设置防火墙
setup_firewall() {
    log_info "配置防火墙..."
    
    ufw --force enable
    ufw default deny incoming
    ufw default allow outgoing
    ufw allow ssh
    ufw allow 'Nginx Full'
    
    log_success "防火墙配置完成"
}

# 创建备份脚本
create_backup_script() {
    log_info "创建备份脚本..."
    
    cat > $PROJECT_DIR/backup.sh << 'EOF'
#!/bin/bash

# 备份脚本
BACKUP_DIR="/opt/pump_fun_bot/backups"
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="backup_$DATE.tar.gz"

# 创建备份
cd /opt/pump_fun_bot
tar -czf "$BACKUP_DIR/$BACKUP_FILE" \
    --exclude='venv' \
    --exclude='logs' \
    --exclude='backups' \
    --exclude='__pycache__' \
    --exclude='*.pyc' \
    .

# 保留最近7天的备份
find $BACKUP_DIR -name "backup_*.tar.gz" -mtime +7 -delete

echo "备份完成: $BACKUP_FILE"
EOF

    chmod +x $PROJECT_DIR/backup.sh
    chown $SERVICE_USER:$SERVICE_USER $PROJECT_DIR/backup.sh
    
    # 添加到crontab
    (crontab -u $SERVICE_USER -l 2>/dev/null; echo "0 2 * * * $PROJECT_DIR/backup.sh") | crontab -u $SERVICE_USER -
    
    log_success "备份脚本创建完成"
}

# 创建监控脚本
create_monitoring() {
    log_info "创建监控脚本..."
    
    cat > $PROJECT_DIR/monitor.sh << 'EOF'
#!/bin/bash

# 监控脚本
PROJECT_NAME="pump_fun_bot"

# 检查服务状态
check_service() {
    if supervisorctl status $PROJECT_NAME | grep -q "RUNNING"; then
        echo "✅ 服务运行正常"
    else
        echo "❌ 服务异常，尝试重启..."
        supervisorctl restart $PROJECT_NAME
    fi
}

# 检查磁盘空间
check_disk() {
    DISK_USAGE=$(df / | awk 'NR==2 {print $5}' | sed 's/%//')
    if [ $DISK_USAGE -gt 80 ]; then
        echo "⚠️  磁盘使用率过高: ${DISK_USAGE}%"
    fi
}

# 检查内存使用
check_memory() {
    MEMORY_USAGE=$(free | awk 'NR==2{printf "%.0f", $3*100/$2}')
    if [ $MEMORY_USAGE -gt 80 ]; then
        echo "⚠️  内存使用率过高: ${MEMORY_USAGE}%"
    fi
}

# 执行检查
check_service
check_disk
check_memory
EOF

    chmod +x $PROJECT_DIR/monitor.sh
    chown $SERVICE_USER:$SERVICE_USER $PROJECT_DIR/monitor.sh
    
    # 添加到crontab (每5分钟检查一次)
    (crontab -u $SERVICE_USER -l 2>/dev/null; echo "*/5 * * * * $PROJECT_DIR/monitor.sh") | crontab -u $SERVICE_USER -
    
    log_success "监控脚本创建完成"
}

# 显示部署信息
show_deployment_info() {
    log_success "🎉 部署完成！"
    echo ""
    echo "📋 部署信息:"
    echo "   项目目录: $PROJECT_DIR"
    echo "   服务用户: $SERVICE_USER"
    echo "   网站地址: https://$DOMAIN"
    echo "   API地址: https://$DOMAIN/api"
    echo ""
    echo "🔧 管理命令:"
    echo "   查看服务状态: supervisorctl status $PROJECT_NAME"
    echo "   重启服务: supervisorctl restart $PROJECT_NAME"
    echo "   查看日志: tail -f /var/log/$PROJECT_NAME/app.log"
    echo "   手动备份: $PROJECT_DIR/backup.sh"
    echo "   系统监控: $PROJECT_DIR/monitor.sh"
    echo ""
    echo "🔑 默认登录信息:"
    echo "   用户名: admin"
    echo "   密码: admin123"
    echo "   (请登录后立即修改密码)"
    echo ""
    echo "📝 重要提醒:"
    echo "   1. 请在 $PROJECT_DIR/.env 中配置 OPENAI_API_KEY"
    echo "   2. 请及时修改默认管理员密码"
    echo "   3. 定期检查系统日志和备份"
    echo ""
}

# 主函数
main() {
    log_info "开始部署 PUMP.FUN 批量发币机器人..."
    
    check_root
    update_system
    install_dependencies
    create_user
    create_directories
    deploy_application
    create_venv
    setup_environment
    init_database
    setup_supervisor
    setup_nginx
    setup_firewall
    create_backup_script
    create_monitoring
    show_deployment_info
}

# 执行主函数
main "$@"

