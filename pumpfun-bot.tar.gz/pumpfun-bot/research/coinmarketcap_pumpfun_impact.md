# Pump.fun Dominates Solana Network, Responsible for 70% of Token Launches and 56% of Transactions

Pump.fun Dominates Solana Network, Responsible for 70% of Token Launches and 56% of Transactions

[Crypto News]()

# Pump.fun Dominates Solana Network, Responsible for 70% of Token Launches and 56% of Transactions

2m

Created 7mo ago, last updated 7mo ago

Pump.fun has recently been responsible for more than 70% of all token launches on the Solana network.

Pump.fun has recently been responsible for more than 70% of all token launches on the Solana network. This milestone was reached over the weekend, when the platform accounted for 71.1% of all tokens created on Solana, with 69.5% recorded the following day. Over the past week, Solana’s value rose by 12%, with the meme coin ecosystem playing a major role in this increase. Pump.fun, which has been active for a year, has been the primary platform for meme coin activity, with over 5.5 million tokens [created]() since its launch.

The platform’s impact extends beyond just token creation. Pump.fun has also been responsible for more than 56% of decentralized exchange trading on Solana so far this month, despite only a small percentage of tokens reaching significant market values. In the last 24 hours alone, the platform launched over 45,000 tokens. This dominance is attributed to Pump.fun’s ease of use and low entry barriers, allowing anyone, even those without technical or financial expertise, to create a token quickly.

Although its dominance has fluctuated, Pump.fun has remained a central player in the Solana ecosystem. In November, during the peak of its livestream feature, the platform’s share of token launches hit a high of 75.5%. However, this feature became controversial due to extreme stunts, such as shooting guns and other shocking behavior. As a result, Pump.fun removed livestreaming, which led to a decline in its market share, dropping to 53% by Dec. 17. Since then, the platform’s share has increased, now surpassing 70%.

Despite its controversial beginnings, Pump.fun has continued to see strong revenue growth, [reaching]() $79.94 million in December. This figure surpasses the earnings of major networks such as Tron and Bitcoin. A major reason for Pump.fun’s continued success is its ability to evolve. Recently, AI agents have started using the platform to create tokens, helping to reach a wider audience and raise funds. This shift into AI-driven projects has helped the platform maintain its dominance in the meme coin market.

The success of Pump.fun is also reflected in its overall performance, with the platform now being responsible for more than half of Solana’s decentralized exchange transactions. While only a small fraction of tokens created on the platform achieve significant market value, Pump.fun’s ability to dominate token issuance and drive engagement has made it a key player in the growing meme coin market.

This article contains links to third-party websites or other content for information purposes only (“Third-Party Sites”). The Third-Party Sites are not under the control of CoinMarketCap, and CoinMarketCap is not responsible for the content of any Third-Party Site, including without limitation any link contained in a Third-Party Site, or any changes or updates to a Third-Party Site. CoinMarketCap is providing these links to you only as a convenience, and the inclusion of any link does not imply endorsement, approval or recommendation by CoinMarketCap of the site or any association with its operators. This article is intended to be used and must be used for informational purposes only. It is important to do your own research and analysis before making any material decisions related to any of the products or services described. This article is not intended as, and shall not be construed as, financial advice. The views and opinions expressed in this article are the author’s \[company’s\] own and do not necessarily reflect those of CoinMarketCap.

0 people liked this article

[

### Decentralized Dog

]()

I\\'m just your average dog... Only decentralized; also... I\\'m not your average dog.

### Related Articles

Join the thousands already learning crypto!

### Join our free newsletter for daily crypto updates!

